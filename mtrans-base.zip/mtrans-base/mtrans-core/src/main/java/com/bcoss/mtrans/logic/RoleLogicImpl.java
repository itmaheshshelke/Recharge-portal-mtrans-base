package com.bcoss.mtrans.logic;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.Role;
import com.bcoss.mtrans.RoleDto;
import com.bcoss.mtrans.dao.RoleDao;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.mapper.RoleMapper;
import com.bcoss.mtrans.service.RoleServiceManagerImpl;

@Component
public class RoleLogicImpl implements RoleLogic {
	
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(RoleServiceManagerImpl.class);

	@Autowired
	private RoleDao roleDao;

	@Override
	public List<RoleDto> getAllRole() throws HelthwellExceptionHandler {

		List<RoleDto> roleDtoList = null;
		try {
			List<Role> roleList = roleDao.getAllRole();
			if (roleList != null && !roleList.isEmpty()) {
				roleDtoList = new ArrayList<RoleDto>();

				for (Role role : roleList) {
					RoleDto roleDto = RoleMapper._toDto(role);
					roleDtoList.add(roleDto);
				}
			}

		} catch (HibernateException he) {
			logger.error("HibernateException Error in RoleLogicImpl - > getAllRole ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in RoleLogicImpl - > getAllRole ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return roleDtoList;
	}
	
	@Override
	public RoleDto getRoleById(Integer roleId) throws HelthwellExceptionHandler {
		RoleDto roleDto = new RoleDto();
		try {
			
			Role role = roleDao.getRoleById(roleId);
			roleDto=RoleMapper._toDto(role);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in RoleLogicImpl - > getRoleById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in RoleLogicImpl - > getRoleById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return roleDto;
	}

	@Override
	public Boolean saveRole(RoleDto roleDto) throws HelthwellExceptionHandler {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean deleteRole(Integer roleId) throws HelthwellExceptionHandler {
		// TODO Auto-generated method stub
		return null;
	}


	}
