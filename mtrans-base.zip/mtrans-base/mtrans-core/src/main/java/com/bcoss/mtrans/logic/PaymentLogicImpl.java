package com.bcoss.mtrans.logic;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.dao.paymentDao;
import com.bcoss.mtrans.dto.PaymentDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;

@Component
public class PaymentLogicImpl implements PaymentLogic{
	
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(PaymentLogicImpl.class);


	@Autowired
	private paymentDao paymentDao;
	
	@Override
	public Boolean payment(PaymentDto paymentDto) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {
			result = paymentDao.payment(paymentDto);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in PaymentLogicImpl - > payment ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PaymentLogicImpl - > payment ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

}
