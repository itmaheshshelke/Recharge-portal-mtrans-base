package com.bcoss.mtrans.logic;

import java.util.List;

import com.bcoss.mtrans.dto.PlansDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface PlansLogic {
	List<PlansDto> getAllPlans() throws HelthwellExceptionHandler;

	PlansDto getPlansById(Integer plansId) throws HelthwellExceptionHandler;

}
