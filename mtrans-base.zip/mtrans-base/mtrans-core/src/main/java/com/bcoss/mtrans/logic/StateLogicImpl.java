package com.bcoss.mtrans.logic;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.District;
import com.bcoss.mtrans.DistrictDto;
import com.bcoss.mtrans.State;
import com.bcoss.mtrans.StateDto;
import com.bcoss.mtrans.dao.StateDao;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.mapper.DistrictMapper;
import com.bcoss.mtrans.mapper.StateMapper;


@Component
public class StateLogicImpl implements StateLogic {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(StateLogicImpl.class);

	@Autowired
	private StateDao stateDao;
	
	@Override
	public List<StateDto> getAllState() throws HelthwellExceptionHandler {

		List<StateDto> stateDtoList = null;
		try {
			List<State> stateList = stateDao.getAllState();
			if (stateList != null && !stateList.isEmpty()) {
				stateDtoList = new ArrayList<StateDto>();

				for (State state : stateList) {
					StateDto stateDto = StateMapper._toDto(state);
					stateDtoList.add(stateDto);
				}
			}

		} catch (HibernateException he) {
			logger.error("HibernateException Error in StateLogicImpl - > getAllState ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in StateLogicImpl - > getAllState ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return stateDtoList;
	}
	
	@Override
	public StateDto getStateById(Integer stateId) throws HelthwellExceptionHandler {
		StateDto stateDto = new StateDto();
		try {

			State state = stateDao.getStateById(stateId);
			stateDto = StateMapper._toDto(state);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in StateLogicImpl - > getStateById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in StateLogicImpl - > getStateById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return stateDto;
	}

	@Override
	public List<DistrictDto> getAllDistrict(Integer stateId) throws HelthwellExceptionHandler {

		List<DistrictDto> districtDtoList = null;
		try {
			List<District> districtList = stateDao.getAllDistrict(stateId);
			if (districtList != null && !districtList.isEmpty()) {
				districtDtoList = new ArrayList<DistrictDto>();

				for (District district : districtList) {
					DistrictDto districtDto = DistrictMapper._toDto(district);
					districtDtoList.add(districtDto);
				}
			}
			
			

		} catch (HibernateException he) {
			logger.error("HibernateException Error in StateLogicImpl - > getAllState ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in StateLogicImpl - > getAllState ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return districtDtoList;
	}
	
	
}
