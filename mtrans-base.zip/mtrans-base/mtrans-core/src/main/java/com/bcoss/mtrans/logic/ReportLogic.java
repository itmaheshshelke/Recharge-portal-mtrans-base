package com.bcoss.mtrans.logic;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Pageable;

import com.bcoss.mtrans.dto.DashbordDto;
import com.bcoss.mtrans.dto.LiveTransactionReportDto;
import com.bcoss.mtrans.dto.MoneyTransferResponseDto;
import com.bcoss.mtrans.dto.ServiceResponseDto;
import com.bcoss.mtrans.dto.WalletTransactionDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface ReportLogic {

	public Map<String, Object> showRechargeReportByDate(Integer serviceId, Date startDate, Date endDate, Integer companyId, Pageable pageable)throws HelthwellExceptionHandler;

	public List<WalletTransactionDto> showAllTransactionReport(Integer companyType)throws HelthwellExceptionHandler;

	public Map<String, Object> showRechargeHistory(Integer companyId, Pageable pageable)throws HelthwellExceptionHandler;

	public Map<String, Object> showReportByServiceId(Integer serviceId, Integer companyId, Pageable pageable)throws HelthwellExceptionHandler;

	public Map<String, Object> getLiveReport(Date startDate, Date endDate, Integer companyId, Pageable pageable)throws HelthwellExceptionHandler;

	Map<String, Object> showMoneyTransferHistory(Integer companyId, Pageable pageable)throws HelthwellExceptionHandler;

	Map<String, Object> showMoneyTransferHistoryByDate(Integer companyId, Date startDate, Date endDate, Pageable pageable)throws HelthwellExceptionHandler;

	public List<ServiceResponseDto> showAllReportByServiceId(Integer serviceId, Integer companyId)throws HelthwellExceptionHandler;

	public List<LiveTransactionReportDto> getAllLiveReport(Integer companyId)throws HelthwellExceptionHandler;

	public List<MoneyTransferResponseDto> showAllMoneyTransferHistory(Integer companyId)throws HelthwellExceptionHandler;

	public DashbordDto getDashbordData(Integer companyId)throws HelthwellExceptionHandler;



}
