package com.bcoss.mtrans.logic;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Pageable;

import com.bcoss.mtrans.PanCardDto;
import com.bcoss.mtrans.dto.CategoryDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface PancardLogic {

	Integer SaveNewPancard(PanCardDto panCardDto)throws HelthwellExceptionHandler;

	Map<String, Object> getAllPancardRequest(Integer companyId, Integer appType, Pageable pageable)throws HelthwellExceptionHandler;

	PanCardDto getPanCardById(Integer panId)throws HelthwellExceptionHandler;

	List<CategoryDto> getCategoryByApplicationTypeId(Integer applicationTypeId)throws HelthwellExceptionHandler;


}
