package com.bcoss.mtrans.logic;

import java.io.File;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.constant.EmailConstant;
import com.bcoss.mtrans.dao.EmailDao;
import com.bcoss.mtrans.email.EmailMessage;
import com.bcoss.mtrans.email.MessageAttributes;
import com.bcoss.mtrans.jpa.sms.EmailInbox;
import com.bcoss.mtrans.jpa.sms.EmailSetting;
import com.bcoss.mtrans.util.EmailUtil;
@Component
@Transactional
public class EmailLogicImpl implements EmailLogic {

	Logger logger = LoggerFactory.getLogger(EmailLogicImpl.class);

	@Autowired
	private  EmailDao emailDao;

	@Async
	@Override
	public void send(EmailMessage message,EmailSetting emailSetting) {
		Boolean result = false;
		EmailInbox emailInbox = new EmailInbox();
		try {
			// build email template ..

			final String EMAIL_TEMPLATE = "\\images\\document\\11_scancopy.html";
			String templateUrl = System.getProperty("user.dir");
			templateUrl = templateUrl + File.separator + EMAIL_TEMPLATE ;

			final String htmlEmailPath = templateUrl;
			String content = EmailUtil.getEmailHtmlFile(htmlEmailPath);

			// expected to send attributes in sequential manner ...
			for (MessageAttributes attributes : message.getMessageAttributes()) {
				System.out.println("Key  " + attributes.getId() + " , Value : " + attributes.getValue());
				content = content.replaceAll(attributes.getId(), attributes.getValue());
			}
			
			result = EmailUtil.sendEmail(emailSetting, message, content);

			emailInbox.setCompanyId(emailSetting.getCompanyId());
			emailInbox.setEmailTemplateType(message.getSubject());
			emailInbox.setService(EmailConstant.TRANS);
			if (result == true) {
				emailInbox.setStatus(EmailConstant.SENT);
			} else {
				emailInbox.setStatus(EmailConstant.FAILED);
			}
			emailDao.saveEmail(emailInbox);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ClinicEmailSettingLogicImpl - > sendEmail ", he);
		} catch (Exception e) {
			logger.error("Exception Error in ClinicEmailSettingLogicImpl - > sendEmail ", e);
		}
	}

}
