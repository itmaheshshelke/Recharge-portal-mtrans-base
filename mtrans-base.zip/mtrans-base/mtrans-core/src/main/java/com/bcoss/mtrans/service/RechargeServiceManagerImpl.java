package com.bcoss.mtrans.service;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bcoss.mtrans.RechargeDto;
import com.bcoss.mtrans.dto.ServiceResponseDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.logic.RechargeLogic;

@Service
public class RechargeServiceManagerImpl implements RechargeServiceManager {
	
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(RechargeServiceManagerImpl.class);

	@Autowired
	private RechargeLogic rechargeLogic;

	@Override
	public ServiceResponseDto recharge(ServiceResponseDto serviceResponseDto) throws HelthwellExceptionHandler {
		ServiceResponseDto result=null;
		try {
			 result = rechargeLogic.recharge(serviceResponseDto);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in RechargeServiceManagerImpl - > prepaidRecharge ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in RechargeServiceManagerImpl - > prepaidRecharge ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}
	
	@Override
	public ServiceResponseDto getBill(ServiceResponseDto serviceResponseDto) throws HelthwellExceptionHandler {
		ServiceResponseDto result=null;
		try {
			 result = rechargeLogic.getBill(serviceResponseDto);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in RechargeServiceManagerImpl - > prepaidRecharge ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in RechargeServiceManagerImpl - > prepaidRecharge ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public Boolean postpaidRecharge(ServiceResponseDto serviceResponseDto) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {
			result = rechargeLogic.postpaidRecharge(serviceResponseDto);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in RechargeServiceManagerImpl - > postpaidRecharge ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in RechargeServiceManagerImpl - > postpaidRecharge ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

}
