package com.bcoss.mtrans.logic;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.CompanyDetails;
import com.bcoss.mtrans.CompanyDetailsDto;
import com.bcoss.mtrans.dao.CompanyDetailsDao;
import com.bcoss.mtrans.dao.ReportDao;
import com.bcoss.mtrans.dao.ServiceOperatorsDao;
import com.bcoss.mtrans.dao.ServicesDao;
import com.bcoss.mtrans.dto.DashbordDto;
import com.bcoss.mtrans.dto.LiveTransactionReportDto;
import com.bcoss.mtrans.dto.MoneyTransferResponseDto;
import com.bcoss.mtrans.dto.ServiceResponseDto;
import com.bcoss.mtrans.dto.WalletTransactionDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.MoneyTransferResponse;
import com.bcoss.mtrans.jpa.ServiceOperators;
import com.bcoss.mtrans.jpa.ServiceResponse;
import com.bcoss.mtrans.jpa.Services;
import com.bcoss.mtrans.jpa.WalletTransaction;
import com.bcoss.mtrans.mapper.MoneyTransferResponseMapper;
import com.bcoss.mtrans.mapper.ServiceResponseMapper;
import com.bcoss.mtrans.mapper.WalletTransactionMapper;

@Component
public class ReportLogicImpl implements ReportLogic{

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(ReportLogicImpl.class);
	@Autowired
	private ReportDao reportDao;
	
	@Autowired
	private ServiceOperatorsDao serviceOperatorsDao;
	
	@Autowired
	private CompanyDetailsDao companyDetailsDao;
	
	@Autowired
	private ServicesDao servicesDao;

	
	
	@Override
	public Map<String, Object> showRechargeReportByDate(Integer serviceId, Date startDate, Date endDate,Integer companyId,Pageable pageable)
			throws HelthwellExceptionHandler {
		List<ServiceResponseDto> serviceResponseDtoList = new ArrayList<ServiceResponseDto>();
		Map<String,Object> resultMap = new HashMap<String,Object>();
		try {
			Page<ServiceResponse> serviceResponseList = reportDao.showRechargeReportByDate(serviceId,startDate,endDate,companyId,pageable);
			if (serviceResponseList != null && serviceResponseList.getTotalElements()!=0) {

				for (ServiceResponse serviceResponse : serviceResponseList) {
					ServiceResponseDto serviceResponseDto = ServiceResponseMapper
							._toDto(serviceResponse);
					CompanyDetails companyDetails = companyDetailsDao.getCompanyDetailsById(serviceResponseDto.getCompanyId());
					serviceResponseDto.setCompanyName(companyDetails.getCompanyName());
					serviceResponseDto.setCompanyType(companyDetails.getCompanyType());
					serviceResponseDtoList.add(serviceResponseDto);
				}
			}
			resultMap.put("list", serviceResponseDtoList);
			resultMap.put("TOTAL_ELEMENTS", serviceResponseList.getTotalElements());
			resultMap.put("TOTAL_PAGES", serviceResponseList.getTotalPages());
			return  resultMap;
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportLogicImpl - > getBillingHistoryByDate ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportLogicImpl - > getBillingHistoryByDate ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}
	@Override
	public List<WalletTransactionDto> showAllTransactionReport(Integer companyType) throws HelthwellExceptionHandler {
		List<WalletTransactionDto> serviceResponseDtoList = new ArrayList<WalletTransactionDto>();
		try {
			List<WalletTransaction> walletTransactionList = reportDao.showAllTransactionReport(companyType);
			if (walletTransactionList != null && !walletTransactionList.isEmpty()) {

				for (WalletTransaction walletTransaction : walletTransactionList) {
					WalletTransactionDto walletTransactionDto = WalletTransactionMapper
							._toDto(walletTransaction);
					serviceResponseDtoList.add(walletTransactionDto);
				}
			}
	
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportLogicImpl - > showAllTransactionReport ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportLogicImpl - > showAllTransactionReport ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return serviceResponseDtoList;
	}
	@Override
	public  Map<String, Object> showRechargeHistory(Integer companyId,Pageable pageable) throws HelthwellExceptionHandler {
		List<ServiceResponseDto> serviceResponseDtoList = new ArrayList<ServiceResponseDto>();
		Map<String,Object> resultMap = new HashMap<String,Object>();
		try {
			Page<ServiceResponse> serviceResponseList = reportDao.showRechargeHistory(companyId,pageable);
			if (serviceResponseList != null && serviceResponseList.getTotalElements()!=0) {

				for (ServiceResponse serviceResponse : serviceResponseList) {
					ServiceResponseDto serviceResponseDto = ServiceResponseMapper
							._toDto(serviceResponse);
					CompanyDetails companyDetails = companyDetailsDao.getCompanyDetailsById(serviceResponseDto.getCompanyId());
					serviceResponseDto.setCompanyName(companyDetails.getCompanyName());
					serviceResponseDto.setCompanyType(companyDetails.getCompanyType());
					serviceResponseDtoList.add(serviceResponseDto);
				}
			}
			resultMap.put("list", serviceResponseDtoList);
			resultMap.put("TOTAL_ELEMENTS", serviceResponseList.getTotalElements());
			resultMap.put("TOTAL_PAGES", serviceResponseList.getTotalPages());
			return  resultMap;
	
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportLogicImpl - > showRechargeHistory ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportLogicImpl - > showRechargeHistory ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}
	@Override
	public Map<String, Object> showReportByServiceId(Integer serviceId,Integer companyId,Pageable pageable) throws HelthwellExceptionHandler {
		List<ServiceResponseDto> serviceResponseDtoList = new ArrayList<ServiceResponseDto>();
		Map<String,Object> resultMap = new HashMap<String,Object>();
		try {
			Page<ServiceResponse> serviceResponseList = reportDao.showReportByServiceId(serviceId,companyId,pageable);
			
			if (serviceResponseList != null && serviceResponseList.getTotalElements()!=0) {

				for (ServiceResponse serviceResponse : serviceResponseList) {
					ServiceResponseDto serviceResponseDto = ServiceResponseMapper
							._toDto(serviceResponse);
					
					CompanyDetails companyDetails = companyDetailsDao.getCompanyDetailsById(serviceResponseDto.getCompanyId());
					serviceResponseDto.setCompanyName(companyDetails.getCompanyName());
					serviceResponseDto.setCompanyType(companyDetails.getCompanyType());
					serviceResponseDtoList.add(serviceResponseDto);
				}
			}
			resultMap.put("list", serviceResponseDtoList);
			resultMap.put("TOTAL_ELEMENTS", serviceResponseList.getTotalElements());
			resultMap.put("TOTAL_PAGES", serviceResponseList.getTotalPages());
			return  resultMap;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportLogicImpl - > showReportByServiceId ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportLogicImpl - > showReportByServiceId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		
	}
	@Override
	public Map<String, Object> getLiveReport(Date startDate, Date endDate,Integer companyId,Pageable pageable) throws HelthwellExceptionHandler {
		List<LiveTransactionReportDto> liveTransactionReportDtoList = new ArrayList<LiveTransactionReportDto>();
		Map<String,Object> resultMap = new HashMap<String,Object>();
		try {
			Page<ServiceResponse> serviceResponseList = reportDao.getLiveReport(startDate,endDate,companyId,pageable);
			if (serviceResponseList != null && serviceResponseList.getTotalElements()!=0) {

				for (ServiceResponse serviceResponse : serviceResponseList) {
					LiveTransactionReportDto liveTransactionReportDto=new LiveTransactionReportDto();
					ServiceOperators serviceOperators = serviceOperatorsDao.getServiceOperatorsByOperaterId(serviceResponse.getOperatorId());
					CompanyDetails companyDetails = companyDetailsDao.getCompanyDetailsById(serviceResponse.getCompanyId());
					Services services = servicesDao.getServicesById(serviceResponse.getServiceId());
					
					liveTransactionReportDto.setOperaterName(serviceOperators.getOperator());
					liveTransactionReportDto.setCopmanyName(companyDetails.getCompanyName());
					liveTransactionReportDto.setCopmanyType(companyDetails.getCompanyType());
					liveTransactionReportDto.setServiseName(services.getName());
					liveTransactionReportDto.setAmount(serviceResponse.getAmount());
					liveTransactionReportDto.setFinalAmount(serviceResponse.getFinalAmount());
					liveTransactionReportDto.setSurcharge(serviceResponse.getSurcharge());
					liveTransactionReportDto.setMargine(serviceResponse.getMargine());
					liveTransactionReportDto.setMombileNumber(serviceResponse.getMombileNumber());
					liveTransactionReportDto.setTime(serviceResponse.getCreatedOn());
					liveTransactionReportDto.setTxId(serviceResponse.getTxId());
					liveTransactionReportDto.setStatus(serviceResponse.getStatus());
					liveTransactionReportDtoList.add(liveTransactionReportDto);
					
				}
			}
	
			resultMap.put("list", liveTransactionReportDtoList);
			resultMap.put("TOTAL_ELEMENTS", serviceResponseList.getTotalElements());
			resultMap.put("TOTAL_PAGES", serviceResponseList.getTotalPages());
			return  resultMap;
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportLogicImpl - > getLiveReport ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportLogicImpl - > getLiveReport ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

	}
	
	@Override
	public Map<String, Object> showMoneyTransferHistory(Integer companyId,Pageable pageable) throws HelthwellExceptionHandler {
		Map<String,Object> resultMap = new HashMap<String,Object>();
		List<MoneyTransferResponseDto> paymentDtoList = new ArrayList<MoneyTransferResponseDto>();
		try {
			Page<MoneyTransferResponse> paymentList = reportDao.showMoneyTransferHistory(companyId,pageable);
			if (paymentList.getTotalElements() != 0 ) {

				for (MoneyTransferResponse payment : paymentList) {
					MoneyTransferResponseDto paymentDto = MoneyTransferResponseMapper
							._toDto(payment);
					CompanyDetails companyDetails=companyDetailsDao.getCompanyDetailsById(paymentDto.getCompanyId());
					paymentDto.setCompanyName(companyDetails.getCompanyName());
					paymentDto.setCompanyType(companyDetails.getCompanyType());
					paymentDtoList.add(paymentDto);
				}
			}
	
			resultMap.put("list", paymentDtoList);
			resultMap.put("TOTAL_ELEMENTS", paymentList.getTotalElements());
			resultMap.put("TOTAL_PAGES", paymentList.getTotalPages());
			return  resultMap;
	
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportLogicImpl - > showMoneyTransferHistory ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportLogicImpl - > showMoneyTransferHistory ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}
	@Override
	public Map<String, Object> showMoneyTransferHistoryByDate(Integer companyId, Date startDate, Date endDate,Pageable pageable)
			throws HelthwellExceptionHandler {
		Map<String,Object> resultMap = new HashMap<String,Object>();
		List<MoneyTransferResponseDto> paymentDtoList = new ArrayList<MoneyTransferResponseDto>();
		try {
			Page<MoneyTransferResponse> paymentList = reportDao.showMoneyTransferHistoryByDate(companyId,startDate,endDate,pageable);
			if (paymentList.getTotalElements() != 0 ) {

				for (MoneyTransferResponse payment : paymentList) {
					MoneyTransferResponseDto paymentDto = MoneyTransferResponseMapper
							._toDto(payment);
					CompanyDetails companyDetails=companyDetailsDao.getCompanyDetailsById(paymentDto.getCompanyId());
					paymentDto.setCompanyName(companyDetails.getCompanyName());
					paymentDto.setCompanyType(companyDetails.getCompanyType());
					paymentDtoList.add(paymentDto);
				}
			}
	
			resultMap.put("list", paymentDtoList);
			resultMap.put("TOTAL_ELEMENTS", paymentList.getTotalElements());
			resultMap.put("TOTAL_PAGES", paymentList.getTotalPages());
			return  resultMap;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportLogicImpl - > showMoneyTransferHistoryByDate ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportLogicImpl - > showMoneyTransferHistoryByDate ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}
	@Override
	public List<ServiceResponseDto> showAllReportByServiceId(Integer serviceId, Integer companyId)
			throws HelthwellExceptionHandler {
		List<ServiceResponseDto> serviceResponseDtoList = new ArrayList<ServiceResponseDto>();
		try {
			List<ServiceResponse> serviceResponseList = reportDao.showAllReportByServiceId(serviceId,companyId);
			
			if (serviceResponseList != null && serviceResponseList.size()!=0) {

				for (ServiceResponse serviceResponse : serviceResponseList) {
					ServiceResponseDto serviceResponseDto = ServiceResponseMapper
							._toDto(serviceResponse);
					
					CompanyDetails companyDetails = companyDetailsDao.getCompanyDetailsById(serviceResponseDto.getCompanyId());
					serviceResponseDto.setCompanyName(companyDetails.getCompanyName());
					serviceResponseDto.setCompanyType(companyDetails.getCompanyType());
					serviceResponseDtoList.add(serviceResponseDto);
				}
			}
			
			return  serviceResponseDtoList;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportLogicImpl - > showReportByServiceId ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportLogicImpl - > showReportByServiceId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		
	}
	@Override
	public List<LiveTransactionReportDto> getAllLiveReport(Integer companyId) throws HelthwellExceptionHandler {
		List<LiveTransactionReportDto> liveTransactionReportDtoList = new ArrayList<LiveTransactionReportDto>();
		try {
			List<ServiceResponse> serviceResponseList = reportDao.getAllLiveReport(companyId);
			if (serviceResponseList != null && serviceResponseList.size()!=0) {

				for (ServiceResponse serviceResponse : serviceResponseList) {
					LiveTransactionReportDto liveTransactionReportDto=new LiveTransactionReportDto();
					ServiceOperators serviceOperators = serviceOperatorsDao.getServiceOperatorsByOperaterId(serviceResponse.getOperatorId());
					CompanyDetails companyDetails = companyDetailsDao.getCompanyDetailsById(serviceResponse.getCompanyId());
					Services services = servicesDao.getServicesById(serviceResponse.getServiceId());
					
					liveTransactionReportDto.setOperaterName(serviceOperators.getOperator());
					liveTransactionReportDto.setCopmanyName(companyDetails.getCompanyName());
					liveTransactionReportDto.setCopmanyType(companyDetails.getCompanyType());
					liveTransactionReportDto.setServiseName(services.getName());
					liveTransactionReportDto.setAmount(serviceResponse.getAmount());
					liveTransactionReportDto.setFinalAmount(serviceResponse.getFinalAmount());
					liveTransactionReportDto.setMargine(serviceResponse.getMargine());
					liveTransactionReportDto.setMombileNumber(serviceResponse.getMombileNumber());
					liveTransactionReportDto.setTime(serviceResponse.getCreatedOn());
					liveTransactionReportDto.setTxId(serviceResponse.getTxId());
					liveTransactionReportDto.setStatus(serviceResponse.getStatus());
					liveTransactionReportDtoList.add(liveTransactionReportDto);
					
				}
			}
	
			return  liveTransactionReportDtoList;
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportLogicImpl - > getAllLiveReport ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportLogicImpl - > getAllLiveReport ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

	}
	@Override
	public List<MoneyTransferResponseDto> showAllMoneyTransferHistory(Integer companyId)
			throws HelthwellExceptionHandler {
		List<MoneyTransferResponseDto> paymentDtoList = new ArrayList<MoneyTransferResponseDto>();
		try {
			List<MoneyTransferResponse> paymentList = reportDao.showAllMoneyTransferHistory(companyId);
			if (paymentList.size() != 0 ) {

				for (MoneyTransferResponse payment : paymentList) {
					MoneyTransferResponseDto paymentDto = MoneyTransferResponseMapper
							._toDto(payment);
					CompanyDetails companyDetails=companyDetailsDao.getCompanyDetailsById(paymentDto.getCompanyId());
					paymentDto.setCompanyName(companyDetails.getCompanyName());
					paymentDto.setCompanyType(companyDetails.getCompanyType());
					paymentDtoList.add(paymentDto);
				}
			}
	
			
			return  paymentDtoList;
	
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportLogicImpl - > showAllMoneyTransferHistory ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportLogicImpl - > showAllMoneyTransferHistory ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}
	@Override
	public DashbordDto getDashbordData(Integer companyId) throws HelthwellExceptionHandler {
		try {
			return  reportDao.getDashbordData(companyId);
	
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportLogicImpl - > getDashbordData ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportLogicImpl - > getDashbordData ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}


}
