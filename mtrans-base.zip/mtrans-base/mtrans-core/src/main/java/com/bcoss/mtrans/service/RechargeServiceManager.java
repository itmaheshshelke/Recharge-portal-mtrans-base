package com.bcoss.mtrans.service;

import com.bcoss.mtrans.dto.ServiceResponseDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface RechargeServiceManager {

	ServiceResponseDto recharge(ServiceResponseDto serviceResponseDto)throws HelthwellExceptionHandler;
	
	ServiceResponseDto getBill(ServiceResponseDto serviceResponseDto)throws HelthwellExceptionHandler;
	
	Boolean postpaidRecharge(ServiceResponseDto serviceResponseDto)throws HelthwellExceptionHandler;

}
