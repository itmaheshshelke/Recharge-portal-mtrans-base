package com.bcoss.mtrans.service;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bcoss.mtrans.dto.PaymentDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.logic.PaymentLogic;

@Service
public class PaymentServiceManagerImpl implements PaymentServiceManager{
	
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(PaymentServiceManagerImpl.class);

	
	@Autowired
	private PaymentLogic paymentLogic;

	@Override
	public Boolean payment(PaymentDto paymentDto) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {
			result = paymentLogic.payment(paymentDto);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in PaymentServiceManagerImpl - > payment ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PaymentServiceManagerImpl - > payment ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

}
