package com.bcoss.mtrans.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bcoss.mtrans.CompanyDetailsDto;
import com.bcoss.mtrans.EmployeeDto;
import com.bcoss.mtrans.dto.WalletDto;
import com.bcoss.mtrans.dto.WalletTransactionDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.WalletTransaction;
import com.bcoss.mtrans.logic.WalletLogic;

@Service
public class WalleterviceManagerImpl  implements WalleterviceManager {
	
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(WalleterviceManagerImpl.class);

	@Autowired
	private WalletLogic walletLogic;

	@Override
	public WalletDto getwalletById(Integer walletId) throws HelthwellExceptionHandler {
		WalletDto walletDto = new WalletDto();
		try {
			walletDto = walletLogic.getwalletById(walletId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalleterviceManagerImpl - > getwalletById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalleterviceManagerImpl - > getwalletById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return walletDto;
	}

	@Override
	public List<CompanyDetailsDto> getAllCompanyWallateBalance(Integer companyId) throws HelthwellExceptionHandler {
		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<>();
		try {
			companyDetailsDtoList = walletLogic.getAllCompanyWallateBalance(companyId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalleterviceManagerImpl - > getAllCompanyWallateBalance ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalleterviceManagerImpl - > getAllCompanyWallateBalance ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return companyDetailsDtoList;
	}

	@Override
	public List<CompanyDetailsDto> companyRecharge(Integer companyId) throws HelthwellExceptionHandler {
		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<>();
		try {
			companyDetailsDtoList = walletLogic.companyRecharge(companyId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalleterviceManagerImpl - > companyRecharge ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalleterviceManagerImpl - > companyRecharge ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return companyDetailsDtoList;
	}

	@Override
	public List<WalletTransactionDto> getAllCompanyTransaction(Integer companyId) throws HelthwellExceptionHandler {
		List<WalletTransactionDto> walletTransactionDtoList = new ArrayList<>();
		try {
			walletTransactionDtoList = walletLogic.getAllCompanyTransaction(companyId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalleterviceManagerImpl - > getAllCompanyTransaction ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalleterviceManagerImpl - > getAllCompanyTransaction ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return walletTransactionDtoList;
	}

	@Override
	public Boolean updateWallet(WalletDto walletDto) throws HelthwellExceptionHandler {
		Boolean resuslt=false;
		try {
			resuslt = walletLogic.updateWallet(walletDto);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalleterviceManagerImpl - > updateWallet ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalleterviceManagerImpl - > updateWallet ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return resuslt;
	}

	@Override
	public Boolean saveRechargeWallet(Integer loggedCompanyId ,Integer companyId, Double rechargeamount,char type) throws HelthwellExceptionHandler {
		Boolean resuslt=false;
		try {
			resuslt = walletLogic.saveRechargeWallet(loggedCompanyId,companyId,rechargeamount,type);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalleterviceManagerImpl - > saveRechargeWallet ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalleterviceManagerImpl - > saveRechargeWallet ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return resuslt;
	}

	@Override
	public void addRequestRecharge(WalletTransaction walletTransaction) throws HelthwellExceptionHandler {
		Boolean resuslt=false;
		try {
			resuslt = walletLogic.addRequestRecharge(walletTransaction);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalleterviceManagerImpl - > addRequestRecharge ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalleterviceManagerImpl - > addRequestRecharge ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}

	@Override
	public List<CompanyDetailsDto> getRequestRecharge(Integer login_companyId) throws HelthwellExceptionHandler {
		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<>();
		try {
			companyDetailsDtoList = walletLogic.getRequestRecharge(login_companyId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalleterviceManagerImpl - > getRequestRecharge ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalleterviceManagerImpl - > getRequestRecharge ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return companyDetailsDtoList;
	}

	@Override
	public Boolean approveRequest(String transNumber,Integer login_walletId,Integer login_companyId) throws HelthwellExceptionHandler {
		
		Boolean resuslt=false;
		try {
			resuslt = walletLogic.approveRequest(transNumber,login_walletId,login_companyId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalleterviceManagerImpl - > approveRequest ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalleterviceManagerImpl - > approveRequest ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return resuslt;
	}

	@Override
	public Boolean activeDeactiveCompany(Integer compnayId,Integer isActive) throws HelthwellExceptionHandler {
		Boolean resuslt=false;
		try {
			resuslt = walletLogic.activeDeactiveCompany(compnayId,isActive);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalleterviceManagerImpl - > activeDeactiveCompany ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalleterviceManagerImpl - > activeDeactiveCompany ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return resuslt;
	}

	@Override
	public Boolean saveDeductWalletBalance(Integer loggedCompanyId, Integer walletId, Double deductAmount,char type)
			throws HelthwellExceptionHandler {
		Boolean resuslt=false;
		try {
			resuslt = walletLogic.saveDeductWalletBalance(loggedCompanyId,walletId,deductAmount,type);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalleterviceManagerImpl - > saveDeductWalletBalance ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalleterviceManagerImpl - > saveDeductWalletBalance ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return resuslt;
	}

	@Override
	public WalletDto getTotalWalletRecharge(Integer login_companyId) throws HelthwellExceptionHandler {
		WalletDto walletDto = new WalletDto();
		try {
			walletDto = walletLogic.getTotalWalletRecharge(login_companyId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalleterviceManagerImpl - > getTotalWalletRecharge ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalleterviceManagerImpl - > getTotalWalletRecharge ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return walletDto;
	}

	@Override
	public Boolean readWriteCompany(Integer compnayId, Character isReadOnly) throws HelthwellExceptionHandler {
		Boolean resuslt=false;
		try {
			resuslt = walletLogic.readWriteCompany(compnayId,isReadOnly);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalleterviceManagerImpl - > readWriteCompany ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalleterviceManagerImpl - > readWriteCompany ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return resuslt;
	}
	
}


