package com.bcoss.mtrans.logic;

import com.bcoss.mtrans.dto.PaymentDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface PaymentLogic {

	Boolean payment(PaymentDto paymentDto)throws HelthwellExceptionHandler;

}
