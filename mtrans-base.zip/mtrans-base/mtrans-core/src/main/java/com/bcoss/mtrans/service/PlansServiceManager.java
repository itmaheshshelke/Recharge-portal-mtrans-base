package com.bcoss.mtrans.service;

import java.util.List;

import com.bcoss.mtrans.dto.PlansDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface PlansServiceManager {
	public List<PlansDto> getAllPlans() throws HelthwellExceptionHandler;

	public PlansDto getPlansById(Integer plansId) throws HelthwellExceptionHandler;

}
