package com.bcoss.mtrans.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bcoss.mtrans.DistrictDto;
import com.bcoss.mtrans.StateDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.logic.StateLogic;

@Service
public class StateServiceManagerImpl implements StateServiceManager{
	
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(StateServiceManagerImpl.class);

	@Autowired
	private StateLogic stateLogic;
	

	
	public List<StateDto> getAllState() throws HelthwellExceptionHandler {
		List<StateDto> stateDtoList = new ArrayList<StateDto>();
		try {
			stateDtoList = stateLogic.getAllState();
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in StateServiceManagerImpl - > getAllState ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in StateServiceManagerImpl - > getAllState ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return stateDtoList;
	}

	
	public StateDto getStateById(Integer stateId) throws HelthwellExceptionHandler {
		StateDto stateDto = new StateDto();
		try {
			stateDto = stateLogic.getStateById(stateId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in StateServiceManagerImpl - > getStateById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in StateServiceManagerImpl - > getStateById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return stateDto;
	}

	
	public List<DistrictDto> getAllDistrict(Integer stateId) throws HelthwellExceptionHandler {
		List<DistrictDto> districtDtoList = new ArrayList<DistrictDto>();
		try {
			districtDtoList = stateLogic.getAllDistrict(stateId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in StateServiceManagerImpl - > getAllDistrict ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in StateServiceManagerImpl - > getAllDistrict ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return districtDtoList;
	}

	
}
