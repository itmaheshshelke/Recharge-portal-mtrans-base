package com.bcoss.mtrans.service;


import java.util.List;

import com.bcoss.mtrans.dto.EmployeeDocumentDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface IDocumentService {

	List<EmployeeDocumentDto> getAllEmployeeDocument(Integer employeeId)throws HelthwellExceptionHandler;


	Boolean addEmployeeDocument(EmployeeDocumentDto employeeDocumentDto)throws HelthwellExceptionHandler;


	boolean deleteEmployeeDocument(Integer emploeeDocumentId)throws HelthwellExceptionHandler;


	EmployeeDocumentDto getEmployeeDocumentById(Integer documentId)throws HelthwellExceptionHandler;

}
