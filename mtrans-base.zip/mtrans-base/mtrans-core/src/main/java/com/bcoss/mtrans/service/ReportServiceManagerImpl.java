package com.bcoss.mtrans.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.bcoss.mtrans.dto.DashbordDto;
import com.bcoss.mtrans.dto.LiveTransactionReportDto;
import com.bcoss.mtrans.dto.MoneyTransferResponseDto;
import com.bcoss.mtrans.dto.ServiceResponseDto;
import com.bcoss.mtrans.dto.WalletTransactionDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.logic.ReportLogic;
import com.bcoss.mtrans.util.FlowData;

@Service
public class ReportServiceManagerImpl implements ReportServiceManager{

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(ReportServiceManagerImpl.class);

	@Autowired
	private ReportLogic reportLogic;
	@Override
	public Map<String, Object> showRechargeReportByDate(Integer serviceId, Date startDate, Date endDate,Integer companyId,Pageable pageable)
			throws HelthwellExceptionHandler {
		try {
			return reportLogic.showRechargeReportByDate(serviceId,startDate,endDate,companyId,pageable);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportServiceManagerImpl - > showReportByDate ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportServiceManagerImpl - > showReportByDate ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		
	}
	@Override
	public List<WalletTransactionDto> showAllTransactionReport(Integer companyType) throws HelthwellExceptionHandler {
		List<WalletTransactionDto> walletTransactionDtoList;
		try {
			walletTransactionDtoList = reportLogic.showAllTransactionReport(companyType);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportServiceManagerImpl - > showAllTransactionReport ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportServiceManagerImpl - > showAllTransactionReport ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return walletTransactionDtoList;
	}
	@Override
	public Map<String, Object> showRechargeHistory(Integer companyId,Pageable pageable) throws HelthwellExceptionHandler {
		
		try {
			return reportLogic.showRechargeHistory(companyId,pageable);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportServiceManagerImpl - > showRechargeHistory ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportServiceManagerImpl - > showRechargeHistory ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		
	}
	@Override
	public Map<String, Object> showReportByServiceId(Integer serviceId,Integer companyId,Pageable pageable) throws HelthwellExceptionHandler {
		List<ServiceResponseDto> serviceResponseDtoList;
		try {
			return reportLogic.showReportByServiceId(serviceId,companyId,pageable);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportServiceManagerImpl - > showReportByServiceId ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportServiceManagerImpl - > showReportByServiceId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		
	}
	@Override
	public Map<String, Object> getLiveReport(Date startDate, Date endDate,Integer companyId,Pageable pageable) throws HelthwellExceptionHandler {
		
		try {
			return  reportLogic.getLiveReport(startDate,endDate,companyId,pageable);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportServiceManagerImpl - > getLiveReport ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportServiceManagerImpl - > getLiveReport ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		
	}
	
	@Override
	public Map<String, Object> showMoneyTransferHistory(Integer companyId,Pageable pageable) throws HelthwellExceptionHandler {
		try {
			return reportLogic.showMoneyTransferHistory(companyId,pageable);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportServiceManagerImpl - > showMoneyTransferHistory ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportServiceManagerImpl - > showMoneyTransferHistory ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		
	}
	@Override
	public Map<String, Object> showMoneyTransferHistoryByDate(Integer companyId, Date startDate, Date endDate,Pageable pageable)
			throws HelthwellExceptionHandler {
		
		try {
			return reportLogic.showMoneyTransferHistoryByDate(companyId,startDate,endDate,pageable);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportServiceManagerImpl - > showMoneyTransferHistoryByDate ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportServiceManagerImpl - > showMoneyTransferHistoryByDate ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}
	@Override
	public List<ServiceResponseDto> showAllReportByServiceId(Integer serviceId, Integer companyId)
			throws HelthwellExceptionHandler {
		List<ServiceResponseDto> serviceResponseDtoList;
		try {
			serviceResponseDtoList=reportLogic.showAllReportByServiceId(serviceId,companyId);
			return serviceResponseDtoList;

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportServiceManagerImpl - > showAllReportByServiceId ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportServiceManagerImpl - > showAllReportByServiceId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}
	@Override
	public List<LiveTransactionReportDto> getAllLiveReport(Integer companyId) throws HelthwellExceptionHandler {
		try {
			return reportLogic.getAllLiveReport(companyId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportServiceManagerImpl - > getAllLiveReport ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportServiceManagerImpl - > getAllLiveReport ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}
	@Override
	public List<MoneyTransferResponseDto> showAllMoneyTransferHistory(Integer companyId)
			throws HelthwellExceptionHandler {
		try {
			return reportLogic.showAllMoneyTransferHistory(companyId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportServiceManagerImpl - > showAllMoneyTransferHistory ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportServiceManagerImpl - > showAllMoneyTransferHistory ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}
	@Override
	public DashbordDto getDashbordData(Integer companyId) throws HelthwellExceptionHandler {
		try {
			return reportLogic.getDashbordData(companyId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportServiceManagerImpl - > getDashbordData ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportServiceManagerImpl - > getDashbordData ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}


}
