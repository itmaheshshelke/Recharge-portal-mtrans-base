package com.bcoss.mtrans.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bcoss.mtrans.Address;
import com.bcoss.mtrans.AddressDto;
import com.bcoss.mtrans.dao.AddressDao;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.mapper.AddressMapper;

@Service
public class AddressServiceManagerImpl  implements AddressServiceManager {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(AddressServiceManagerImpl.class);
	@Autowired
	private AddressDao addressDao;

	@Override
	public List<AddressDto> getAllAddress() throws HelthwellExceptionHandler {
		List<AddressDto> addressDtoList = null;
		try {
			List<Address> addressList = addressDao.getAllAddress();
			if (addressList != null && !addressList.isEmpty()) {
				addressDtoList = new ArrayList<AddressDto>();
				for (Address address : addressList) {
					AddressDto addressDto = AddressMapper._toDto(address);
					addressDtoList.add(addressDto);
				}
			}
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in AddressServiceImpl- > getAllAddress", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in AddressServiceImpl- > getAllAddress", ee);
		}
		return addressDtoList;

	}

	@Override
	public AddressDto getAddressById(int id) throws HelthwellExceptionHandler {
		try {
			Address address = addressDao.getAddressById(id);
			if (address != null) {
				AddressDto addressDto = AddressMapper._toDto(address);
				return addressDto;
			}
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in AddressServiceImpl- > getAddressById", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in AddressServiceImpl- > getAddressById", ee);
		}
		return null;
	}

	@Override
	public Address addAddress(Address address) throws HelthwellExceptionHandler {
		try {
			     addressDao.addAddress(address);
			return address;
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in AddressServiceImpl- > addAddress", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in AddressServiceImpl- > addAddress", ee);
		}
		return address;
	}

	@Override
	public Address updateAddress(Address address) throws HelthwellExceptionHandler {
		try {
			addressDao.updateAddress(address);
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in AddressServiceImpl- > updateAddress", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in AddressServiceImpl- > updateAddress", ee);
		}
		return address;
	}

	@Override
	public boolean deleteAddress(int id) throws HelthwellExceptionHandler {
		try {
			addressDao.deleteAddress(id);
			return true;
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in AddressServiceImpl- > deleteAddress", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in AddressServiceImpl- > deleteAddress", ee);
		}
		return false;
	}

}