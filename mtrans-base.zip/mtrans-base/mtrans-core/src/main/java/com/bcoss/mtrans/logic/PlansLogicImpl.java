package com.bcoss.mtrans.logic;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.dao.PlansDao;
import com.bcoss.mtrans.dto.PlansDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.Plans;
import com.bcoss.mtrans.mapper.PlansMapper;

@Component
public class PlansLogicImpl implements PlansLogic {
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(PlansLogicImpl.class);

	@Autowired
	private PlansDao plansDao;

	@Override
	public List<PlansDto> getAllPlans() throws HelthwellExceptionHandler {

		List<PlansDto> plansDtoList = new ArrayList<PlansDto>();
		try {
			List<Plans> plansList = plansDao.getAllPlans();
			if (plansList != null && !plansList.isEmpty()) {

				for (Plans plans : plansList) {
					PlansDto plansDto = PlansMapper._toDto(plans);
					plansDtoList.add(plansDto);
				}
			}

		} catch (HibernateException he) {
			logger.error("HibernateException Error in PlansLogicImpl - > getAllPlans ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PlansLogicImpl - > getAllPlans ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return plansDtoList;
	}

	@Override
	public PlansDto getPlansById(Integer plansId) throws HelthwellExceptionHandler {
		PlansDto plansDto = new PlansDto();
		try {

			Plans plans = plansDao.getPlansById(plansId);
			plansDto = PlansMapper._toDto(plans);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in PlansLogicImpl - > getPlansById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PlansLogicImpl - > getPlansById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return plansDto;
	}

}
