package com.bcoss.mtrans.service;

import com.bcoss.mtrans.email.MessageDto;

public interface EmailService {

	public Boolean send(MessageDto message);
}
