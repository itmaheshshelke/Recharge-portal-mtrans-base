package com.bcoss.mtrans.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bcoss.mtrans.EmployeeDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.logic.EmployeeLogic;



@Service
public class EmployeeServiceManagerImpl implements EmployeeServiceManager {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(EmployeeServiceManagerImpl.class);

	@Autowired
	private EmployeeLogic employeeLogic;

	public List<EmployeeDto> getAllEmployee(Integer companyId) throws HelthwellExceptionHandler {
		List<EmployeeDto> employeeDtoList = new ArrayList<EmployeeDto>();
		try {
			employeeDtoList = employeeLogic.getAllEmployee(companyId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in EmployeeServiceManagerImpl - > getAllEmployee ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in EmployeeServiceManagerImpl - > getAllEmployee ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return employeeDtoList;
	}

	public EmployeeDto getEmployeeById(Integer employeeId) throws HelthwellExceptionHandler {
		EmployeeDto employeeDto = new EmployeeDto();
		try {
			employeeDto = employeeLogic.getEmployeeById(employeeId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in EmployeeServiceManagerImpl - > getEmployeeById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in EmployeeServiceManagerImpl - > getEmployeeById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return employeeDto;
	}

	public Boolean saveEmployee(EmployeeDto employeeDto) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {

			result = employeeLogic.saveEmployee(employeeDto);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in EmployeeServiceManagerImpl - > saveEmployee ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in EmployeeServiceManagerImpl - > saveEmployee ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	public Boolean deleteEmployee(Integer employeeId) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {

			result = employeeLogic.deleteEmployee(employeeId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in EmployeeServiceManagerImpl - > deleteEmployee ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in EmployeeServiceManagerImpl - > deleteEmployee ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}
	
	
	
}
