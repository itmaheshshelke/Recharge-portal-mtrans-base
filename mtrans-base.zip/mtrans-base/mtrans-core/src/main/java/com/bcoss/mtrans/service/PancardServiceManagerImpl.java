package com.bcoss.mtrans.service;

import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.bcoss.mtrans.PanCardDto;
import com.bcoss.mtrans.dto.CategoryDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.logic.PancardLogic;

@Service
public class PancardServiceManagerImpl implements PancardServiceManager{
	
private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(PancardServiceManagerImpl.class);

	
	@Autowired
	private PancardLogic pancardLogic;


	@Override
	public Boolean SaveNewPancard(PanCardDto panCardDto) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {
			Integer panId = pancardLogic.SaveNewPancard(panCardDto);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in PancardServiceManagerImpl - > SaveNewPancard ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PancardServiceManagerImpl - > SaveNewPancard ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}


	@Override
	public Map<String, Object> getAllPancardRequest(Integer companyId,Integer appType, Pageable pageable)
			throws HelthwellExceptionHandler {
		try {
			return pancardLogic.getAllPancardRequest(companyId,appType,pageable);

		} catch (HelthwellExceptionHandler he) {
			throw he;
		} catch (Exception e) {
			logger.error("Exception Error in PancardServiceManagerImpl - > SaveNewPancard ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}


	@Override
	public PanCardDto getPanCardById(Integer panId) throws HelthwellExceptionHandler {

		try {
			return pancardLogic.getPanCardById(panId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in PancardServiceManagerImpl - > getPanCardById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PancardServiceManagerImpl - > getPanCardById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}


	@Override
	public List<CategoryDto> getCategoryByApplicationTypeId(Integer applicationTypeId)
			throws HelthwellExceptionHandler {
		try {
			return pancardLogic.getCategoryByApplicationTypeId(applicationTypeId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in PancardServiceManagerImpl - > getCategoryByApplicationTypeId ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PancardServiceManagerImpl - > getCategoryByApplicationTypeId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}

}
