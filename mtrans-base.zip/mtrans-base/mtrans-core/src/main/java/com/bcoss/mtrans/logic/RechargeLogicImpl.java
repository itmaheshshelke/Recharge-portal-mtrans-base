package com.bcoss.mtrans.logic;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.bcoss.mtrans.dao.RechargeDao;
import com.bcoss.mtrans.dao.ServiceOperatorsDao;
import com.bcoss.mtrans.dto.ServiceResponseDto;
import com.bcoss.mtrans.dto.provider.response.QuickRechargeResponseDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.ServiceOperators;
import com.bcoss.mtrans.rest.CrowfinchRestClient;
import com.bcoss.mtrans.util.CalendarUtil;
import com.bcoss.mtrans.util.PostpaidRechargeUtil;
import com.bcoss.mtrans.util.PrepaidRechargeUtil;
import com.bcoss.mtrans.util.RechargeResponse;

@Component
public class RechargeLogicImpl implements RechargeLogic{
	
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(RechargeLogicImpl.class);

	@Autowired
	private RechargeDao RechargeDao;

	@Autowired
	private ServiceOperatorsDao serviceOperatorsDao;
	
	@Autowired
	private CrowfinchRestClient crowfinchRestClient;
	
	@Override
	public ServiceResponseDto recharge(ServiceResponseDto serviceResponseDto) throws HelthwellExceptionHandler {
		
		try {
			
			SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS+hh:mm");
			
			ServiceOperators serviceOperators = serviceOperatorsDao.getServiceOperatorsById(serviceResponseDto.getOperatorId());
			
			serviceResponseDto.setOperatorCode(serviceOperators.getOperatorCode());
			serviceResponseDto.setServiceId(serviceOperators.getServiceId());
			
			//String rechargeResponseString=PrepaidRechargeUtil.prepaidRecharge(serviceResponseDto);
			
			//String messageToRecharge = serviceResponseDto.getOperatorCode()+" "+serviceResponseDto.getMombileNumber()+" "+serviceResponseDto.getAmount();
			
			MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
			map.add("opcode", serviceResponseDto.getOperatorCode());
			map.add("number", serviceResponseDto.getMombileNumber());
			map.add("amount", serviceResponseDto.getAmount().toString());
			map.add("request_id", crowfinchRestClient.getUniqueTransactionCode());
			map.add("optional1", serviceResponseDto.getOptional1());
			
			QuickRechargeResponseDto response = crowfinchRestClient.rechargeApi(map,serviceResponseDto.getCompanyId());
			
			
			serviceResponseDto.setRemarks(response.getMessage());
			
			serviceResponseDto.setErrorCode(response.getError());
			serviceResponseDto.setStatus("PENDING");
			serviceResponseDto.setResponseJson(response.getResponse());
			serviceResponseDto.setOperatorRef(response.getOptxnid());
			serviceResponseDto.setDataStatus("PENDING");
			serviceResponseDto.setTxId(map.getFirst("request_id"));
			serviceResponseDto.setRefId(map.getFirst("request_id"));
			serviceResponseDto.setTime(CalendarUtil.getISTDate());
			serviceResponseDto.setCreatedOn(CalendarUtil.getISTDate());
			
			/*serviceResponseDto.setRemarks("jhjhh");
			serviceResponseDto.setErrorCode("jghg");
			serviceResponseDto.setStatus("PENDING");
			serviceResponseDto.setResponseJson("hgfgf");
			serviceResponseDto.setOperatorRef("jhgh78");
			serviceResponseDto.setDataStatus("PENDING");
			serviceResponseDto.setTxId("jhguj6687");
			serviceResponseDto.setRefId("mjmhg87");
			serviceResponseDto.setTime(CalendarUtil.getISTDate());
			serviceResponseDto.setCreatedOn(CalendarUtil.getISTDate());*/
			
			RechargeDao.saveRechargeResponse(serviceResponseDto);
			
					
		} catch (HibernateException he) {
			logger.error("HibernateException Error in RechargeLogicImpl - > prepaidRecharge ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in RechargeLogicImpl - > prepaidRecharge ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return serviceResponseDto;
	}
	
	@Override
	public ServiceResponseDto getBill(ServiceResponseDto serviceResponseDto) throws HelthwellExceptionHandler {
		
		try {
			
			ServiceOperators serviceOperators = serviceOperatorsDao.getServiceOperatorsById(serviceResponseDto.getOperatorId());
			
			serviceResponseDto.setOperatorCode(serviceOperators.getOperatorCode());
			serviceResponseDto.setServiceId(serviceOperators.getServiceId());
			
			
			QuickRechargeResponseDto response = crowfinchRestClient.billfetch(serviceResponseDto.getOperatorCode(),
					serviceResponseDto.getAccountNumber(), serviceResponseDto.getOptional1());

			serviceResponseDto.setCustomername(response.getCustomername());
			serviceResponseDto.setBillnumber(response.getBillnumber());
			if (null != response && null != response.getDueamount() && !response.getDueamount().isEmpty())
				serviceResponseDto.setAmount(Double.parseDouble(response.getDueamount()));
			serviceResponseDto.setRemarks(response.getMessage());
			
			
					
		} catch (HibernateException he) {
			logger.error("HibernateException Error in RechargeLogicImpl - > prepaidRecharge ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in RechargeLogicImpl - > prepaidRecharge ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return serviceResponseDto;
	}

	@Override
	public Boolean postpaidRecharge(ServiceResponseDto serviceResponseDto) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {
			
			SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS+hh:mm");
			ServiceOperators serviceOperators = serviceOperatorsDao.getServiceOperatorsById(serviceResponseDto.getOperatorId());
			
			serviceResponseDto.setOperatorCode(serviceOperators.getOperatorCode());
			serviceResponseDto.setServiceId(serviceOperators.getServiceId());
			
			String rechargeResponseString=PostpaidRechargeUtil.postpaidRecharge(serviceResponseDto);
			
			RechargeResponse rechargeResponse=PostpaidRechargeUtil.transactionResponse(rechargeResponseString);
				
			serviceResponseDto.setErrorCode(rechargeResponse.getError_code());
			serviceResponseDto.setTxId(rechargeResponse.getTxid());
			try {
				serviceResponseDto.setTime(formatter.parse(rechargeResponse.getTime()));
			}catch (Exception e) {
				// TODO: handle exception
				logger.info("Date format is different from provider {} inserting server date ",rechargeResponse.getTime());
				serviceResponseDto.setTime(CalendarUtil.getISTDate());
			}
			
			serviceResponseDto.setStatus(rechargeResponse.getStatus());
			serviceResponseDto.setOperatorRef(rechargeResponse.getOperator_ref());
			
			result=RechargeDao.saveRechargeResponse(serviceResponseDto);
					
		} catch (HibernateException he) {
			logger.error("HibernateException Error in RechargeLogicImpl - > prepaidRecharge ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in RechargeLogicImpl - > prepaidRecharge ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}
	
	public static void main(String args[]) {
		String dateString = "2018-05-31T21:03:15.1823639+05:30";
		SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS+hh:mm");
		try {
			System.out.println(formatter.parse(dateString));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

public static Date getISTDate() throws ParseException {		

		Date serverCurrentDate = new Date();
		System.out.println("Server Date : - "+serverCurrentDate);
		DateFormat formatterIST = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		formatterIST.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata")); 
		String dateStr = formatterIST.format(serverCurrentDate);
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		
		Date date = formatter.parse(dateStr);
		System.out.println("Converted UTC date "+date);
		return date;
	
	}

}
