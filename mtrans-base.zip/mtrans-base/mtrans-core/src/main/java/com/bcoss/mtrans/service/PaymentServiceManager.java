package com.bcoss.mtrans.service;

import com.bcoss.mtrans.dto.PaymentDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface PaymentServiceManager {

	Boolean payment(PaymentDto paymentDto)throws HelthwellExceptionHandler;

}
