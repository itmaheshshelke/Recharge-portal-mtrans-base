package com.bcoss.mtrans.service;


import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bcoss.mtrans.dao.IDocumentDao;
import com.bcoss.mtrans.dto.EmployeeDocumentDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.EmployeeDocument;
import com.bcoss.mtrans.mapper.EmployeeDocumentMapper;

@Service
public class DocumentServiceImpl implements IDocumentService {
	
	Logger logger = LoggerFactory.getLogger(DocumentServiceImpl.class);
	
	@Autowired
	private IDocumentDao documentDao;

	@Override
	public List<EmployeeDocumentDto> getAllEmployeeDocument(Integer companyId) throws HelthwellExceptionHandler {
		List<EmployeeDocumentDto> employeeDocumentDtoList = null;

		try {
			List<EmployeeDocument> employeeDocumentList = documentDao.getAllEmployeeDocument(companyId);
			if (employeeDocumentList != null && !employeeDocumentList.isEmpty()) {
				employeeDocumentDtoList = new ArrayList<EmployeeDocumentDto>();
				for (EmployeeDocument employeeDocument : employeeDocumentList) {
					EmployeeDocumentDto employeeDocumentDto = EmployeeDocumentMapper._toDto(employeeDocument);
					employeeDocumentDtoList.add(employeeDocumentDto);
				}
			}
		} catch (HelthwellExceptionHandler e) {
			throw e;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in DocumentServiceImpl - > getAllEmployeeDocument ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in DocumentServiceImpl - > getAllEmployeeDocument ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return employeeDocumentDtoList;

	}

	

	@Override
	public Boolean addEmployeeDocument(EmployeeDocumentDto employeeDocumentDto) throws HelthwellExceptionHandler {
		Boolean result = false;
		Integer empDocId = 0;
		final String UPLOAD_DIRECTORY = "images";
		try {

			empDocId = documentDao.addEmployeeDocument(employeeDocumentDto,empDocId);
			result=true;
			
			if(empDocId!=0) {
			String fileUploadPath = System.getProperty("user.dir");

			// C:\Users\AMOL\mcon-workspace\mcon-services

			File file1 = new File(fileUploadPath + File.separator + UPLOAD_DIRECTORY+File.separator+"EmpolyeeDocument");
			if (!file1.exists()) {
				if (file1.mkdirs()) {
					logger.info("Directory is created!");
				} else {
					logger.info("Failed to create directory!");
				}
			}
			// Create the file on server
			String filePath = fileUploadPath + File.separator + UPLOAD_DIRECTORY +File.separator+"EmpolyeeDocument"+ File.separator + empDocId + "."
					+ employeeDocumentDto.getExtension();
			logger.info("Save directory Path=="+filePath);
			
			File serverFile = new File(filePath);
			BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
			stream.write(employeeDocumentDto.getData());
			stream.flush();
			stream.close();

			logger.info("Server File Location=" + serverFile.getAbsolutePath());

			employeeDocumentDto.setUri(File.separator + UPLOAD_DIRECTORY +File.separator+"EmpolyeeDocument"+ File.separator + empDocId + "."
					+ employeeDocumentDto.getExtension());

			documentDao.addEmployeeDocument(employeeDocumentDto, empDocId);
			result=true;
			}
		} catch (HelthwellExceptionHandler e) {
			throw e;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in DocumentServiceImpl - > addEmployeeDocument ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
 			logger.error("Exception Error in DocumentServiceImpl - > addEmployeeDocument ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;

	}


	@Override
	public boolean deleteEmployeeDocument(Integer emploeeDocumentId) throws HelthwellExceptionHandler {
		try {
			return documentDao.deleteEmployeeDocument(emploeeDocumentId);
		} catch (HelthwellExceptionHandler e) {
			throw e;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in DocumentServiceImpl - > deleteEmployeeDocument ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in DocumentServiceImpl - > deleteEmployeeDocument ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}



	@Override
	public EmployeeDocumentDto getEmployeeDocumentById(Integer documentId) throws HelthwellExceptionHandler {
		try {
			 EmployeeDocument employeeDocument=	documentDao.getEmployeeDocumentById(documentId);
			 EmployeeDocumentDto employeeDocumentDto = EmployeeDocumentMapper._toDto(employeeDocument);
			return employeeDocumentDto;
		} catch (HelthwellExceptionHandler e) {
			throw e;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in DocumentServiceImpl - > getEmployeeDocumentById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in DocumentServiceImpl - > getEmployeeDocumentById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}

}
