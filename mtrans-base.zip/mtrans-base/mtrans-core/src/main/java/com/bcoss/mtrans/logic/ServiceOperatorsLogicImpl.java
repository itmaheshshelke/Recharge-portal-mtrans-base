package com.bcoss.mtrans.logic;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.dao.ServiceOperatorsDao;
import com.bcoss.mtrans.dto.ServiceOperatorsDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.ServiceOperators;
import com.bcoss.mtrans.mapper.ServiceOperatorsMapper;

@Component
public class ServiceOperatorsLogicImpl implements ServiceOperatorsLogic {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(ServiceOperatorsLogicImpl.class);

	@Autowired
	private ServiceOperatorsDao serviceOperatorsDao;

	@Override
	public List<ServiceOperatorsDto> getAllServiceOperators() throws HelthwellExceptionHandler {
		List<ServiceOperatorsDto> serviceOperatorsDtoList =new ArrayList<>();
		try {
			List<ServiceOperators> serviceOperatorsList = serviceOperatorsDao.getAllServiceOperators();
			if (serviceOperatorsList != null && !serviceOperatorsList.isEmpty()) {
				

				for (ServiceOperators serviceOperators : serviceOperatorsList) {
					ServiceOperatorsDto serviceOperatorsDto = ServiceOperatorsMapper._toDto(serviceOperators);
					serviceOperatorsDtoList.add(serviceOperatorsDto);
				}
			}
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServiceOperatorsLogicImpl - > getAllServiceOperators ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServiceOperatorsLogicImpl - > getAllServiceOperators ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return serviceOperatorsDtoList;
	}

	@Override
	public ServiceOperatorsDto getServiceOperatorsById(Integer serviceId) throws HelthwellExceptionHandler {
		ServiceOperatorsDto serviceOperatorsDto = new ServiceOperatorsDto();
		try {

			ServiceOperators serviceOperators = serviceOperatorsDao.getServiceOperatorsById(serviceId);
			serviceOperatorsDto = ServiceOperatorsMapper._toDto(serviceOperators);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServiceOperatorsLogicImpl - > getServiceOperatorsById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServiceOperatorsLogicImpl - > getServiceOperatorsById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return serviceOperatorsDto;
	}
	
	@Override
	public Boolean saveServiceOperators(ServiceOperatorsDto serviceOperatorsDto) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {

			
			ServiceOperators serviceOperators =ServiceOperatorsMapper._toJpa(serviceOperatorsDto);
			result = serviceOperatorsDao.saveServiceOperators(serviceOperators);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServiceOperatorsLogicImpl - > saveServiceOperators ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServiceOperatorsLogicImpl - > saveServiceOperators ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public Boolean deleteServiceOperators(Integer serviceId)throws HelthwellExceptionHandler {
		Boolean result = false;
		try {

			result = serviceOperatorsDao.deleteServiceOperators(serviceId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServiceOperatorsLogicImpl - > deleteServiceOperators ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServiceOperatorsLogicImpl - > deleteServiceOperators ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public List<ServiceOperatorsDto> getOperatorByServiceId(Integer serviceId) throws HelthwellExceptionHandler {
		List<ServiceOperatorsDto> serviceOperatorsDtoList =new ArrayList<>();
		try {
			List<ServiceOperators> serviceOperatorsList = serviceOperatorsDao.getOperatorByServiceId(serviceId);
			if (serviceOperatorsList != null && !serviceOperatorsList.isEmpty()) {
				

				for (ServiceOperators serviceOperators : serviceOperatorsList) {
					ServiceOperatorsDto serviceOperatorsDto = ServiceOperatorsMapper._toDto(serviceOperators);
					serviceOperatorsDtoList.add(serviceOperatorsDto);
				}
			}
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServiceOperatorsLogicImpl - > getOperatorByServiceId ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServiceOperatorsLogicImpl - > getOperatorByServiceId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return serviceOperatorsDtoList;
	}

}
