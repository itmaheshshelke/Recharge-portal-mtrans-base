package com.bcoss.mtrans.schedular;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.CompanyDetailsDto;
import com.bcoss.mtrans.dao.ReportDao;
import com.bcoss.mtrans.dto.WalletDto;
import com.bcoss.mtrans.dto.provider.response.QuickRechargeResponseDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.jpa.ServiceResponse;
import com.bcoss.mtrans.jpa.WalletTransaction;
import com.bcoss.mtrans.repository.WalletTransactionRepository;
import com.bcoss.mtrans.rest.CrowfinchRestClient;
import com.bcoss.mtrans.service.CompanyDetailsServiceManager;
import com.bcoss.mtrans.service.WalleterviceManager;
import com.bcoss.mtrans.util.CalendarUtil;

@Component
public class ScheduledTasks {

    private static final Logger log = LoggerFactory.getLogger(ScheduledTasks.class);
    
    @Autowired
    private ReportDao reportDao;
    
    @Autowired
	private CrowfinchRestClient crowfinchRestClient;

	@Autowired
 	private WalleterviceManager walleterviceManager;
	
	@Autowired
	private CompanyDetailsServiceManager companyServiceManager;
	
	@Autowired
	WalletTransactionRepository walletTransactionRepository;

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

    @Scheduled(fixedRate = 100000)
    public void reportCurrentTime() throws ParseException {
        log.info("The time is now {}", dateFormat.format(CalendarUtil.getISTDate()));
        
        try {
			List<ServiceResponse> serviceResponseList= reportDao.getPendingTransaction();
			if(! serviceResponseList.isEmpty() || serviceResponseList.size()>0) {
			for (ServiceResponse serviceResponse : serviceResponseList) {
				try {
						if (null != serviceResponse.getRefId()) {
							QuickRechargeResponseDto response = crowfinchRestClient
									.getStatus(serviceResponse.getRefId());
							serviceResponse.setStatus(response.getStatus());
							serviceResponse.setDataStatus(response.getStatus());
							serviceResponse.setOperatorRef(response.getOptxnid());
							serviceResponse.setRemarks(response.getMessage());
							reportDao.changeStatus(serviceResponse);
							
							// if transaction is not sucess then revet the wallet balance 
							
							CompanyDetailsDto companyDetailsDto = companyServiceManager.getCompanyDetailsById(serviceResponse.getCompanyId());
							if (!companyDetailsDto.getCompanyType().equals(1)) {
								if (response.getStatus().equals("FAILED")) {
									WalletDto walletDto = walleterviceManager
											.getwalletById(companyDetailsDto.getWalletId());
									double walletBalance = walletDto.getBalance();
									walletBalance = walletBalance + (serviceResponse.getFinalAmount()!=null?serviceResponse.getFinalAmount():0.0);
									walletDto.setBalance(walletBalance);
									walleterviceManager.updateWallet(walletDto);

									WalletTransaction walletTransaction = new WalletTransaction();
									walletTransaction.setCreatedBy(companyDetailsDto.getCompanyId());
									walletTransaction.setCreatedOn(CalendarUtil.getISTDate());
									walletTransaction.setTransAmount(serviceResponse.getFinalAmount()!=null?serviceResponse.getFinalAmount():0.0);
									walletTransaction.setTransDate(CalendarUtil.getISTDate());
									walletTransaction.setTransNumber(serviceResponse.getTxId());
									walletTransaction.setTransType('C');
									walletTransaction.setWalletId(companyDetailsDto.getWalletId());
									walletTransaction.setTransStatus("sucess");
									walletTransactionRepository.save(walletTransaction);
								}
							}
						}
						
				}catch (Exception e) {
					log.error("Exception occured while updating transaction of "+serviceResponse.getTxId()+" response id : "+serviceResponse.getServiceResponseId());
				}
				
			}
			}
			
		} catch (HelthwellExceptionHandler e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
        
    }
}