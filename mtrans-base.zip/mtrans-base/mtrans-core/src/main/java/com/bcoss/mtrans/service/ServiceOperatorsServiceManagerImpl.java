package com.bcoss.mtrans.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bcoss.mtrans.dto.ServiceOperatorsDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.logic.ServiceOperatorsLogic;
@Service
public class ServiceOperatorsServiceManagerImpl implements ServiceOpertaorsServiceManager {
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(ServiceOperatorsServiceManagerImpl.class);
	
	@Autowired
	private ServiceOperatorsLogic serviceOperatorsLogic;
	
	@Override
	public List<ServiceOperatorsDto> getAllServiceOperators() throws HelthwellExceptionHandler {
		List<ServiceOperatorsDto> serviceOperatorsDtoList = new ArrayList<ServiceOperatorsDto>();
		try {
			serviceOperatorsDtoList = serviceOperatorsLogic.getAllServiceOperators();

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServiceOperatorsServiceManagerImpl - > getAllServiceOperators ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServiceOperatorsServiceManagerImpl - > getAllServiceOperators ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return serviceOperatorsDtoList;
	}
	
	@Override
	public ServiceOperatorsDto getServiceOperatorsById(Integer serviceId) throws HelthwellExceptionHandler {
		ServiceOperatorsDto serviceOperatorsDto = new ServiceOperatorsDto();
		try {
			serviceOperatorsDto = serviceOperatorsLogic.getServiceOperatorsById(serviceId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServiceOperatorsServiceManagerImpl - > getServiceOperatorsById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServiceOperatorsServiceManagerImpl - > getServiceOperatorsById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return serviceOperatorsDto;
	}
	
	@Override
	public Boolean saveServiceOperators(ServiceOperatorsDto serviceOperatorsDto) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			result = serviceOperatorsLogic.saveServiceOperators(serviceOperatorsDto);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServiceOperatorsServiceManagerImpl - > saveServiceOperators ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServiceOperatorsServiceManagerImpl - > saveServiceOperators ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;

	}
	
	@Override
	public Boolean deleteServiceOperators(Integer serviceId) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			result = serviceOperatorsLogic.deleteServiceOperators(serviceId);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServiceOperatorsServiceManagerImpl - > deleteServiceOperators ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServiceOperatorsServiceManagerImpl - > deleteServiceOperators ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public List<ServiceOperatorsDto> getOperatorByServiceId(Integer serviceId) throws HelthwellExceptionHandler {
		List<ServiceOperatorsDto> serviceOperatorsDtoList = new ArrayList<ServiceOperatorsDto>();
		try {
			serviceOperatorsDtoList = serviceOperatorsLogic.getOperatorByServiceId(serviceId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServiceOperatorsServiceManagerImpl - > getOperatorByServiceId ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServiceOperatorsServiceManagerImpl - > getOperatorByServiceId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return serviceOperatorsDtoList;
	}


	
	

}
