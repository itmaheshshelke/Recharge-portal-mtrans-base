package com.bcoss.mtrans.logic;

import java.util.List;

import com.bcoss.mtrans.RoleDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface RoleLogic {

	Boolean saveRole(RoleDto roleDto) throws HelthwellExceptionHandler;

	List<RoleDto> getAllRole() throws HelthwellExceptionHandler;

	RoleDto getRoleById(Integer roleId)throws HelthwellExceptionHandler;

	Boolean deleteRole(Integer roleId) throws HelthwellExceptionHandler;


	

}
