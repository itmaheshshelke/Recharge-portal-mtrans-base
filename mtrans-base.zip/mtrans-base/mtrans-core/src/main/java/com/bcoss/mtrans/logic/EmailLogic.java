package com.bcoss.mtrans.logic;

import com.bcoss.mtrans.email.EmailMessage;
import com.bcoss.mtrans.jpa.sms.EmailSetting;

public interface EmailLogic {

	public void send(EmailMessage message, EmailSetting emailSetting);
}
