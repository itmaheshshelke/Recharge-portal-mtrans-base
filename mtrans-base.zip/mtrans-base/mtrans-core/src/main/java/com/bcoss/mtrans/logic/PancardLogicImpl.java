package com.bcoss.mtrans.logic;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.CompanyDetails;
import com.bcoss.mtrans.PanCardDto;
import com.bcoss.mtrans.dao.CompanyDetailsDao;
import com.bcoss.mtrans.dao.PancardDao;
import com.bcoss.mtrans.dto.CategoryDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.Category;
import com.bcoss.mtrans.jpa.PanCard;
import com.bcoss.mtrans.mapper.CategoryMapper;
import com.bcoss.mtrans.mapper.PancardMapper;

@Component
public class PancardLogicImpl implements PancardLogic{
	
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(PancardLogicImpl.class);


	@Autowired
	private PancardDao pancardDao;
	
	@Autowired
	private CompanyDetailsDao companyDetailsDao;

	@Value("${mtarns.doc.path}")
    private String docPath;
	@Override
	public Integer SaveNewPancard(PanCardDto panCardDto) throws HelthwellExceptionHandler {
		Integer panId;
		File serverFile;
		BufferedOutputStream stream;
		String filePath="";
		 final String UPLOAD_DIRECTORY = "images";
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date dob = sdf.parse(panCardDto.getDobString());
			panCardDto.setDob(dob);
			panCardDto.setCreatedOn(new Date());
			
			if(panCardDto.getIdentityUri().equals(""))
				panCardDto.setIdentityUri(null);
			if(panCardDto.getDobUri().equals(""))
				panCardDto.setDobUri(null);
			if(panCardDto.getAddressUri().equals(""))
				panCardDto.setAddressUri(null);
			if(panCardDto.getScanCopyUri().equals(""))
				panCardDto.setScanCopyUri(null);
			
			 panId=  pancardDao.saveNewPancard(panCardDto);
			 String fileUploadPath = System.getProperty("user.dir");
		
			
			 if (!panCardDto.getDobImage().isEmpty()) {
					try {
						// String filePath = getServletContext().getRealPath("/");

						byte[] bytes = panCardDto.getDobImage().getBytes();
						String filename = panCardDto.getDobImage().getOriginalFilename();
						String extension = filename.split(Pattern.quote("."))[1];
						panCardDto.setData(bytes);
						panCardDto.setExt(extension);
					} catch (Exception e) {
					}
				}
			 if(panCardDto.getData()!=null) {
			 File file1 = new File(fileUploadPath + File.separator + UPLOAD_DIRECTORY+File.separator+"document");
				if (!file1.exists()) {
					if (file1.mkdirs()) {
						logger.info("Directory is created!");
					} else {
						logger.info("Failed to create directory!");
					};
				}
				// Create the file on server
				 filePath = fileUploadPath + File.separator + UPLOAD_DIRECTORY +File.separator+"document"+ File.separator + panId + "_dob."
						+ panCardDto.getExt();
				logger.info("Save directory Path=="+filePath);
				
				 serverFile = new File(filePath);
				 stream = new BufferedOutputStream(new FileOutputStream(serverFile));
				stream.write(panCardDto.getData());
				stream.flush();
				stream.close();

				logger.info("Server File Location=" + serverFile.getAbsolutePath());

				panCardDto.setDobUri(File.separator + UPLOAD_DIRECTORY +File.separator+"document"+ File.separator + panId + "_dob."
						+ panCardDto.getExt());
				panCardDto.setPanId(panId);
				pancardDao.UpdatePancard(panCardDto);
			
			 }
			 panCardDto.setData(null);
				 if (!panCardDto.getAddressImage().isEmpty()) {
						try {
							// String filePath = getServletContext().getRealPath("/");

							byte[] bytes = panCardDto.getAddressImage().getBytes();
							String filename = panCardDto.getAddressImage().getOriginalFilename();
							String extension = filename.split(Pattern.quote("."))[1];
							panCardDto.setData(bytes);
							panCardDto.setExt(extension);
						} catch (Exception e) {
						}
					}
				 if(panCardDto.getData()!=null) {
				 
					// Create the file on server
					 filePath = fileUploadPath + File.separator + UPLOAD_DIRECTORY +File.separator+"document"+ File.separator + panId + "_address."
							+ panCardDto.getExt();
					logger.info("Save directory Path=="+filePath);
					
					 serverFile = new File(filePath);
					 stream = new BufferedOutputStream(new FileOutputStream(serverFile));
					stream.write(panCardDto.getData());
					stream.flush();
					stream.close();

					logger.info("Server File Location=" + serverFile.getAbsolutePath());

					panCardDto.setAddressUri(File.separator + UPLOAD_DIRECTORY +File.separator+"document"+ File.separator + panId + "_address."
							+ panCardDto.getExt());
					panCardDto.setPanId(panId);
					pancardDao.UpdatePancard(panCardDto);
			}
				 panCardDto.setData(null);
			
					 if (!panCardDto.getIdentityImage().isEmpty()) {
							try {
								// String filePath = getServletContext().getRealPath("/");

								byte[] bytes = panCardDto.getIdentityImage().getBytes();
								String filename = panCardDto.getIdentityImage().getOriginalFilename();
								String extension = filename.split(Pattern.quote("."))[1];
								panCardDto.setData(bytes);
								panCardDto.setExt(extension);
							} catch (Exception e) {
							}
						}
					 
					 if(panCardDto.getData()!=null) {
						// Create the file on server
						 filePath = fileUploadPath + File.separator + UPLOAD_DIRECTORY +File.separator+"document"+ File.separator + panId + "_identity."
								+ panCardDto.getExt();
						logger.info("Save directory Path=="+filePath);
						
						 serverFile = new File(filePath);
						 stream = new BufferedOutputStream(new FileOutputStream(serverFile));
						stream.write(panCardDto.getData());
						stream.flush();
						stream.close();

						logger.info("Server File Location=" + serverFile.getAbsolutePath());

						panCardDto.setIdentityUri(File.separator + UPLOAD_DIRECTORY +File.separator+"document"+ File.separator + panId + "_identity."
								+ panCardDto.getExt());
						panCardDto.setPanId(panId);
						pancardDao.UpdatePancard(panCardDto);
			}
					 
					 panCardDto.setData(null);
						
					 if (!panCardDto.getScanCopyImage().isEmpty()) {
							try {
								// String filePath = getServletContext().getRealPath("/");

								byte[] bytes = panCardDto.getScanCopyImage().getBytes();
								String filename = panCardDto.getScanCopyImage().getOriginalFilename();
								String extension = filename.split(Pattern.quote("."))[1];
								panCardDto.setData(bytes);
								panCardDto.setExt(extension);
							} catch (Exception e) {
							}
						}
					 
					 if(panCardDto.getData()!=null) {
						// Create the file on server
						 filePath = fileUploadPath + File.separator + UPLOAD_DIRECTORY +File.separator+"document"+ File.separator + panId + "_scancopy."
								+ panCardDto.getExt();
						logger.info("Save directory Path=="+filePath);
						
						 serverFile = new File(filePath);
						 stream = new BufferedOutputStream(new FileOutputStream(serverFile));
						stream.write(panCardDto.getData());
						stream.flush();
						stream.close();

						logger.info("Server File Location=" + serverFile.getAbsolutePath());

						panCardDto.setScanCopyUri(File.separator + UPLOAD_DIRECTORY +File.separator+"document"+ File.separator + panId + "_scancopy."
								+ panCardDto.getExt());
						panCardDto.setPanId(panId);
						pancardDao.UpdatePancard(panCardDto);
			}
					
		} catch (HelthwellExceptionHandler he) {
			throw he;
		} catch (Exception e) {
			logger.error("Exception Error in PancardLogicImpl - > saveNewPancard ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return panId;
	}
	@Override
	public Map<String, Object> getAllPancardRequest(Integer companyId, Integer appType, Pageable pageable)
			throws HelthwellExceptionHandler {
		List<PanCardDto> serviceResponseDtoList = new ArrayList<PanCardDto>();
		Map<String,Object> resultMap = new HashMap<String,Object>();
		try {
			Page<PanCard> serviceResponseList = pancardDao.getAllPancardRequest(companyId,appType,pageable);
			if (serviceResponseList != null && serviceResponseList.getTotalElements()!=0) {

				for (PanCard panCard : serviceResponseList) {
					PanCardDto panCardDto = PancardMapper
							._toDto(panCard);
					CompanyDetails companyDetails = companyDetailsDao.getCompanyDetailsById(panCard.getCreatedBy());
					panCardDto.setCompanyName(companyDetails.getCompanyName());
					panCardDto.setCompanyType(companyDetails.getCompanyType());
					serviceResponseDtoList.add(panCardDto);
				}
			}
			resultMap.put("list", serviceResponseDtoList);
			resultMap.put("TOTAL_ELEMENTS", serviceResponseList.getTotalElements());
			resultMap.put("TOTAL_PAGES", serviceResponseList.getTotalPages());
			return  resultMap;
	
		} catch (HibernateException he) {
			logger.error("HibernateException Error in PancardLogicImpl - > getAllPancardRequest ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PancardLogicImpl - > getAllPancardRequest ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}

	@Override
	public PanCardDto getPanCardById(Integer panId) throws HelthwellExceptionHandler {
		PanCardDto panCardDto = new PanCardDto();
		try {
			PanCard panCard = pancardDao.getPanCardById(panId);
			panCardDto = PancardMapper._toDto(panCard);
			return panCardDto;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in PancardLogicImpl - > getPanCardById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PancardLogicImpl - > getPanCardById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

	}
	public List<CategoryDto> getCategoryByApplicationTypeId(Integer applicationTypeId)
			throws HelthwellExceptionHandler {
		List<CategoryDto> categoryDtoList = new ArrayList<>();
		try {
			List<Category> categoryList = pancardDao.getCategoryByApplicationTypeId(applicationTypeId);
			for (Category category : categoryList) {
				categoryDtoList.add(CategoryMapper._toDto(category));
			}
			return categoryDtoList;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in PancardLogicImpl - > getCategoryByApplicationTypeId ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PancardLogicImpl - > getCategoryByApplicationTypeId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}

}
