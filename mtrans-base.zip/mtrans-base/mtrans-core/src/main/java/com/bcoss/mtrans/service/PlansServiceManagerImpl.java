package com.bcoss.mtrans.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bcoss.mtrans.dto.PlansDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.logic.PlansLogic;

@Service
public class PlansServiceManagerImpl implements PlansServiceManager {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(PlansServiceManagerImpl.class);

	@Autowired
	private PlansLogic plansLogic;

	@Override
	public List<PlansDto> getAllPlans() throws HelthwellExceptionHandler {

		List<PlansDto> plansDtoList = new ArrayList<PlansDto>();
		try {
			plansDtoList = plansLogic.getAllPlans();

		} catch (HibernateException he) {
			logger.error("HibernateException Error in PlansServiceManagerImpl - > getAllPlans ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PlansServiceManagerImpl - > getAllPlans ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return plansDtoList;
	}

	@Override
	public PlansDto getPlansById(Integer plansId) throws HelthwellExceptionHandler {
		PlansDto plansDto = new PlansDto();
		try {
			plansDto = plansLogic.getPlansById(plansId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in PlansServiceManagerImpl - > getPlansById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PlansServiceManagerImpl - > getPlansById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return plansDto;
	}
}
