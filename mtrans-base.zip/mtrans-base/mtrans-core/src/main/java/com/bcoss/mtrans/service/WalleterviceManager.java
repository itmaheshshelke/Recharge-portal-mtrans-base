package com.bcoss.mtrans.service;

import java.util.List;

import com.bcoss.mtrans.CompanyDetailsDto;
import com.bcoss.mtrans.dto.WalletDto;
import com.bcoss.mtrans.dto.WalletTransactionDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.jpa.WalletTransaction;

public interface WalleterviceManager {

	WalletDto getwalletById(Integer walletId)throws HelthwellExceptionHandler;

	List<CompanyDetailsDto> getAllCompanyWallateBalance(Integer companyId)throws HelthwellExceptionHandler;

	List<CompanyDetailsDto> companyRecharge(Integer companyId)throws HelthwellExceptionHandler;

	List<WalletTransactionDto> getAllCompanyTransaction(Integer companyId)throws HelthwellExceptionHandler;

	Boolean updateWallet(WalletDto walletDto)throws HelthwellExceptionHandler;

	Boolean saveRechargeWallet(Integer loggedCompanyId,Integer companyId, Double rechargeamount, char type)throws HelthwellExceptionHandler;

	void addRequestRecharge(WalletTransaction walletTransaction)throws HelthwellExceptionHandler;

	List<CompanyDetailsDto> getRequestRecharge(Integer login_companyId)throws HelthwellExceptionHandler;

	Boolean approveRequest(String transNumber,Integer login_walletId, Integer login_companyId)throws HelthwellExceptionHandler;

	Boolean activeDeactiveCompany(Integer isActive, Integer isActive2)throws HelthwellExceptionHandler;

	Boolean saveDeductWalletBalance(Integer loggedCompanyId, Integer walletId, Double deductAmount, char type)throws HelthwellExceptionHandler;

	WalletDto getTotalWalletRecharge(Integer login_companyId)throws HelthwellExceptionHandler;

	Boolean readWriteCompany(Integer compnayId, Character isReadOnly)throws HelthwellExceptionHandler;


	


}
