package com.bcoss.mtrans.service;

import com.bcoss.mtrans.ChangePasswordDto;
import com.bcoss.mtrans.EmployeeDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.util.FlowData;

public interface LoginServiceManager {

	EmployeeDto login(EmployeeDto employeeDto, FlowData flowData)throws HelthwellExceptionHandler;

	EmployeeDto sendOtp(String mono)throws HelthwellExceptionHandler;

	Boolean saveChangePassword(ChangePasswordDto changePasswordDto)throws HelthwellExceptionHandler;

	EmployeeDto reSendPassword(String mono) throws HelthwellExceptionHandler;

}
