package com.bcoss.mtrans.service;

import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.jpa.sms.Template;

public interface SmsLogic {

	public String sendSms(String mobileNo, String message, String route, String mode,int templateId, Integer companyId) throws HelthwellExceptionHandler;
	
	public String sendOtp(String mobileNo, int siteId) throws HelthwellExceptionHandler;

	public String getBalance(int siteId) throws HelthwellExceptionHandler;
	
	public Template getSmsTemplateById(Integer templateId) throws HelthwellExceptionHandler;

	public String getDeleveryReport(String mobileNo, String messageId,int siteId) throws HelthwellExceptionHandler;
	

	}
