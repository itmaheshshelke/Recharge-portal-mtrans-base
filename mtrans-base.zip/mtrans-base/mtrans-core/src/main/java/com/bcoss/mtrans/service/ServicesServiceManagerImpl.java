package com.bcoss.mtrans.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bcoss.mtrans.dto.ServicesDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.logic.ServicesLogic;
@Service
public class ServicesServiceManagerImpl implements ServicesServiceManager {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(ServicesServiceManagerImpl.class);

	@Autowired
	private ServicesLogic servicesLogic;

	@Override
	public List<ServicesDto> getAllServices(Integer planId) throws HelthwellExceptionHandler {
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		try {
			servicesDtoList = servicesLogic.getAllServices(planId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServicesServiceManagerImpl - > getAllServices ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServicesServiceManagerImpl - > getAllServices ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return servicesDtoList;
	}

	@Override
	public ServicesDto getServicesById(Integer serviceId) throws HelthwellExceptionHandler {
		ServicesDto servicesDto = new ServicesDto();
		try {
			servicesDto = servicesLogic.getServicesById(serviceId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServicesServiceManagerImpl - > getServicesById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServicesServiceManagerImpl - > getServicesById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return servicesDto;
	}

	@Override
	public Boolean saveServices(ServicesDto servicesDto) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			result = servicesLogic.saveServices(servicesDto);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServicesServiceManagerImpl - > saveServices ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServicesServiceManagerImpl - > saveServices ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;

	}

	@Override
	public Boolean deleteServices(Integer serviceId) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			result = servicesLogic.deleteServices(serviceId);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServicesServiceManagerImpl - > deleteServices ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServicesServiceManagerImpl - > deleteServices ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}
}
