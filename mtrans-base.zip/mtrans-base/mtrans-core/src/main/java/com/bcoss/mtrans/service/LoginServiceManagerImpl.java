package com.bcoss.mtrans.service;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bcoss.mtrans.ChangePasswordDto;
import com.bcoss.mtrans.CompanyDetailsDto;
import com.bcoss.mtrans.EmployeeDto;
import com.bcoss.mtrans.StateDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.logic.LoginLogic;
import com.bcoss.mtrans.logic.StateLogic;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@Service
public class LoginServiceManagerImpl implements LoginServiceManager {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(LoginServiceManagerImpl.class);

	@Autowired
	private LoginLogic loginLogic;
	
	@Autowired
	private CompanyDetailsServiceManager companyServiceManager;
	
	@Autowired
	private StateLogic stateLogic;

	
	
	@Override
	public EmployeeDto login(EmployeeDto employeeDto, FlowData flowData) throws HelthwellExceptionHandler {
		try {
			employeeDto = loginLogic.login(employeeDto);
	
			CompanyDetailsDto companyDetailsDto = companyServiceManager.getCompanyDetailsById(employeeDto.getCompanyId());
			StateDto stateDto = stateLogic.getStateById(companyDetailsDto.getStateId());
			flowData.setSessionDataObject(WebAppConstants.EMPLOYEE, employeeDto);
			flowData.setSessionData(WebAppConstants.CIRCLECODE, stateDto.getCircleCode()+"");
			flowData.setSessionData(WebAppConstants.EMPLOYEEID, employeeDto.getEmployeeId()+"");
			flowData.setSessionData(WebAppConstants.WALLETID, companyDetailsDto.getWalletId()+"");
			flowData.setSessionData(WebAppConstants.COMPANYID, employeeDto.getCompanyId()+"");
			flowData.setSessionData(WebAppConstants.PLANID, companyDetailsDto.getPlanId()+"");
			flowData.setSessionData(WebAppConstants.COMPANYTYPE, companyDetailsDto.getCompanyType()+"");
			flowData.setSessionData(WebAppConstants.FIRSTNAME, employeeDto.getName());
			flowData.setSessionData(WebAppConstants.EMAIL_ID, employeeDto.getEmailId());
			flowData.setSessionDataObject(WebAppConstants.IS_READONLY, companyDetailsDto.getIsReadOnly());
		} catch (HibernateException he) {
			logger.error("HibernateException Error in LoginServiceManagerImpl - > login ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in LoginServiceManagerImpl - > login ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return employeeDto;
	}



	@Override
	public EmployeeDto sendOtp(String mono) throws HelthwellExceptionHandler {
		 EmployeeDto employeeDto = new EmployeeDto();  
			try {

				employeeDto = loginLogic.sendOtp(mono);

			} catch (HibernateException he) {
				logger.error("HibernateException Error in LoginServiceManagerImpl - > sendOtp ", he);
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
			} catch (Exception e) {
				logger.error("Exception Error in LoginServiceManagerImpl - > sendOtp ", e);
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
			}
			
			return employeeDto;
	}

	
	@Override
	public EmployeeDto reSendPassword(String mono) throws HelthwellExceptionHandler {
		 EmployeeDto employeeDto = new EmployeeDto();  
			try {

				employeeDto = loginLogic.reSendPassword(mono);

			} catch (HibernateException he) {
				logger.error("HibernateException Error in LoginServiceManagerImpl - > reSendPassword ", he);
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
			} catch (Exception e) {
				logger.error("Exception Error in LoginServiceManagerImpl - > reSendPassword ", e);
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
			}
			
			return employeeDto;
	}



	@Override
	public Boolean saveChangePassword(ChangePasswordDto changePasswordDto) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {

			result = loginLogic.saveChangePassword(changePasswordDto);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in LoginServiceManagerImpl - > saveChangePassword ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in LoginServiceManagerImpl - > saveChangePassword ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		
		return result;
	}

}
