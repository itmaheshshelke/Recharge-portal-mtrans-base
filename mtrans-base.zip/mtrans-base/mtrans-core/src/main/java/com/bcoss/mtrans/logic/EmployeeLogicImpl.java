package com.bcoss.mtrans.logic;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.Employee;
import com.bcoss.mtrans.EmployeeDto;
import com.bcoss.mtrans.dao.EmployeeDao;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.mapper.EmployeeMapper;
import com.bcoss.mtrans.util.CalendarUtil;

@Component
public class EmployeeLogicImpl implements EmployeeLogic {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(EmployeeLogicImpl.class);

	@Autowired
	private EmployeeDao employeeDao;

	@Override
	public List<EmployeeDto> getAllEmployee(Integer companyId) throws HelthwellExceptionHandler {
		List<EmployeeDto> employeeDtoList = null;
		try {
			List<Employee> employeeList = employeeDao.getAllEmployee(companyId);
			if (employeeList != null && !employeeList.isEmpty()) {
				employeeDtoList = new ArrayList<EmployeeDto>();

				for (Employee employee : employeeList) {
					EmployeeDto employeeDto = EmployeeMapper._toDto(employee);
					employeeDtoList.add(employeeDto);
				}
			}

		} catch (HibernateException he) {
			logger.error("HibernateException Error in EmployeeLogicImpl - > getAllEmployee ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in EmployeeLogicImpl - > getAllEmployee ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return employeeDtoList;
	}

	@Override
	public EmployeeDto getEmployeeById(Integer employeeId) throws HelthwellExceptionHandler {
		EmployeeDto employeeDto = new EmployeeDto();
		try {

			Employee employee = employeeDao.getEmployeeById(employeeId);
			employeeDto = EmployeeMapper._toDto(employee);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in EmployeeLogicImpl - > getEmployeeById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in EmployeeLogicImpl - > getEmployeeById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return employeeDto;
	}

	@Override
	public Boolean saveEmployee(EmployeeDto employeeDto) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {

			Employee employee = EmployeeMapper._toJpa(employeeDto);
			if (employee.getEmployeeId() != null) {
				employee.setUpdatedOn(CalendarUtil.getISTDate());
				employee.setDelFlag('N');
				result = employeeDao.updateEmployee(employee);
			} else {
				employee.setCreatedOn(CalendarUtil.getISTDate());
				employee.setDelFlag('N');
				result = employeeDao.saveEmployee(employee);
			}

		} catch (HibernateException he) {
			logger.error("HibernateException Error in EmployeeLogicImpl - > saveEmployee ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in EmployeeLogicImpl - > saveEmployee ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public Boolean deleteEmployee(Integer employeeId) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {

			result = employeeDao.deleteEmployee(employeeId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in EmployeeLogicImpl - > deleteEmployee ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in EmployeeLogicImpl - > deleteEmployee ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	
}
