package com.bcoss.mtrans.logic;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.CompanyDetails;
import com.bcoss.mtrans.CompanyDetailsDto;
import com.bcoss.mtrans.Employee;
import com.bcoss.mtrans.dao.CompanyDetailsDao;
import com.bcoss.mtrans.dao.WalletDao;
import com.bcoss.mtrans.dto.EmailSettingDto;
import com.bcoss.mtrans.email.EmailMessage;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.jpa.Wallet;
import com.bcoss.mtrans.jpa.sms.Template;
import com.bcoss.mtrans.mapper.CompanyDetailsMapper;
import com.bcoss.mtrans.repository.WalletRepository;
import com.bcoss.mtrans.service.SmsLogic;
import com.bcoss.mtrans.util.EmailUtil;

@Component
public class CompanyLogicImpl implements CompanyLogic {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(CompanyLogicImpl.class);
	
	@Autowired
	private CompanyDetailsDao companyDetailsDao;
	@Autowired
	private WalletRepository walletRepository;
	
	@Autowired
	private SmsLogic smsLogic;
	
	@Autowired
	private WalletDao walletDao;
	
	@Value("${mtrans.email.email}")
	private String emailId;

	@Value("${mtrans.email.password}")
	private String password;

	@Value("${mtrans.email.host}")
	private String host;

	@Value("${mtrans.email.port}")
	private String port;
	
	@Value("${mtrans.email.template}")
	private String templatePath;
	
	@Value("${mtrans.app.url}")
	private String appUrl;
	
	@Override
	public List<CompanyDetailsDto> getAllCompanyDetails(Integer companyId) throws HelthwellExceptionHandler {
		List<CompanyDetailsDto> companyDetailsDtoList = null;
		try {
			List<CompanyDetails> companyDetailsList = companyDetailsDao.getAllCompanyDetails(companyId);
			if (companyDetailsList != null && !companyDetailsList.isEmpty()) {
				companyDetailsDtoList = new ArrayList<CompanyDetailsDto>();
				for (CompanyDetails companyDetails : companyDetailsList) {
					CompanyDetailsDto companyDetailsDto = CompanyDetailsMapper._toDto(companyDetails);
					companyDetailsDtoList.add(companyDetailsDto);
				}
			}
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > getAllCompanyDetails", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > getAllCompanyDetails", ee);
		}
		return companyDetailsDtoList;

	}

	@Override
	public CompanyDetailsDto getCompanyDetailsById(int id) throws HelthwellExceptionHandler {
		try {
			CompanyDetails companyDetails = companyDetailsDao.getCompanyDetailsById(id);
			if (companyDetails != null) {
				CompanyDetailsDto companyDetailsDto = CompanyDetailsMapper._toDto(companyDetails);
				return companyDetailsDto;
			}
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > getCompanyDetailsById", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > getCompanyDetailsById", ee);
		}
		return null;
	}

	@Override
	public Boolean addCompanyDetails(CompanyDetailsDto companyDetailsDto) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {
			CompanyDetails companyDetails = CompanyDetailsMapper._toJpa(companyDetailsDto);
			Employee employee= companyDetailsDao.addCompanyDetails(companyDetails);
			
			final Integer companyId = employee.getCompanyId();
			final String mobileNo = employee.getContactNo();
			final String pass = employee.getPassword();
			Template template = smsLogic.getSmsTemplateById(1);
			Thread t = new Thread(new Runnable() {

				@Override
				public void run() {

					try {
						String content = "";
						content = template.getSmsBody();
						content = content.replaceAll("##1", employee.getName());
						content = content.replaceAll("##2", employee.getContactNo());
						content = content.replaceAll("##3", pass);
						smsLogic.sendSms(mobileNo, content, "TRANS", "Debug", template.getTemplateId(), companyId);
					} catch (Exception e) {
						System.out.println("Exception while sending SMS to customer " + mobileNo);
					}

				}
			});
			t.start();
			
			EmailSettingDto emailSettingDto = new EmailSettingDto(emailId, password, Integer.parseInt(port),host);

			final String EMAIL_TEMPLATE = "Account_created.htm";
			//String templateUrl = System.getProperty("user.dir");
			String templateUrl = templatePath + File.separator + EMAIL_TEMPLATE ;
			final String emailUrl=templateUrl;
			Thread emailThread = new Thread(new Runnable() {
				public void run() {
					EmailMessage em = new EmailMessage();
					em.setRetryCount(2);
					String htmlEmailPath = emailUrl;
					String content = EmailUtil.getEmailHtmlFile(htmlEmailPath);
					content = content.replaceAll("###1", employee.getName());
					content = content.replaceAll("###2", appUrl);
					content = content.replaceAll("###3", employee.getContactNo());
					content = content.replaceAll("###4", pass);
					content = content.replaceAll("###5", "RKSS Technologies Pvt. Ltd.");
					EmailUtil.sendEmail(emailSettingDto ,em, employee.getEmailId(), "User account credentials mail", content);
				}
			});
			emailThread.start();
			
			return result;
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > addCompanyDetails", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > addCompanyDetails", ee);
		}
		return result;
	}

	@Override
	public Boolean updateCompanyDetails(CompanyDetailsDto companyDetailsDto) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {
			CompanyDetails companyDetails = CompanyDetailsMapper._toJpa(companyDetailsDto);

			result=companyDetailsDao.updateCompanyDetails(companyDetails);
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > updateCompanyDetails", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > updateCompanyDetails", ee);
		}
		return result;
	}

	@Override
	public boolean deleteCompanyDetails(int id) throws HelthwellExceptionHandler {
		try {
			companyDetailsDao.deleteCompanyDetails(id);
			return true;
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > deleteCompanyDetails", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > deleteCompanyDetails", ee);
		}
		return false;
	}

	@Override
	public List<CompanyDetailsDto> searchCompanyDetails(Integer companyId, String qString)
			throws HelthwellExceptionHandler {
		List<CompanyDetailsDto> companyDetailsDtoList = null;
		Wallet wallet=null;
		try {
			List<CompanyDetails> companyDetailsList = companyDetailsDao.searchCompanyDetails(companyId,qString);
			if (companyDetailsList != null && !companyDetailsList.isEmpty()) {
				companyDetailsDtoList = new ArrayList<CompanyDetailsDto>();
				for (CompanyDetails companyDetails : companyDetailsList) {
					CompanyDetailsDto companyDetailsDto = CompanyDetailsMapper._toDto(companyDetails);
					if(companyDetailsDto.getWalletId()!=null)
					 wallet = walletDao.getwalletById(companyDetailsDto.getWalletId());
					if(wallet!=null) {companyDetailsDto.setBalance(wallet.getBalance());}
					companyDetailsDtoList.add(companyDetailsDto);
				}
			}
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > searchCompanyDetails", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > searchCompanyDetails", ee);
		}
		return companyDetailsDtoList;


	}

	@Override
	public Map<String,Object> getAllDistributors(Pageable pageable, Integer companyId,String searchTerm) throws HelthwellExceptionHandler {
		Map<String,Object> companyDetailsMap = new HashMap<String,Object>();
		List<CompanyDetailsDto> companyDetailsDtoList = null;
		try {
			Page<CompanyDetails> companyDetailsList = companyDetailsDao.getAllDistributors(pageable,companyId,searchTerm);
			if (companyDetailsList != null && companyDetailsList.getTotalElements()>0) {
				companyDetailsDtoList = new ArrayList<CompanyDetailsDto>();
				for (CompanyDetails companyDetails : companyDetailsList) {
					CompanyDetailsDto companyDetailsDto = CompanyDetailsMapper._toDto(companyDetails);
					Wallet wallet=	walletRepository.findOne(companyDetails.getWalletId());
					
					if(wallet.getBalance() !=null)
					companyDetailsDto.setBalance(wallet.getBalance());
					
					companyDetailsDtoList.add(companyDetailsDto);
				}
			}
			companyDetailsMap.put("list", companyDetailsDtoList);
			companyDetailsMap.put("TOTAL_ELEMENTS", companyDetailsList.getTotalElements());
			companyDetailsMap.put("TOTAL_PAGES", companyDetailsList.getTotalPages());
			return  companyDetailsMap;
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > getAllDistributors", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > getAllDistributors", ee);
		}
		return null;
	}

	@Override
	public Map<String,Object> getAllRetailers(Integer id,Pageable pageable, String searchTerm) throws HelthwellExceptionHandler {
		Map<String,Object> companyDetailsMap = new HashMap<String,Object>();
		List<CompanyDetailsDto> companyDetailsDtoList = null;
		try {
			Page<CompanyDetails> companyDetailsList = companyDetailsDao.getAllRetailers(id,pageable,searchTerm);
			if (companyDetailsList != null && companyDetailsList.getTotalElements()>0) {
				companyDetailsDtoList = new ArrayList<CompanyDetailsDto>();
				for (CompanyDetails companyDetails : companyDetailsList) {
					CompanyDetailsDto companyDetailsDto = CompanyDetailsMapper._toDto(companyDetails);
					Wallet wallet=	walletRepository.findOne(companyDetails.getWalletId());
					
					if(wallet.getBalance() !=null)
					companyDetailsDto.setBalance(wallet.getBalance());
					companyDetailsDtoList.add(companyDetailsDto);
				}
			}
			
			companyDetailsMap.put("list", companyDetailsDtoList);
			companyDetailsMap.put("TOTAL_ELEMENTS", companyDetailsList.getTotalElements());
			companyDetailsMap.put("TOTAL_PAGES", companyDetailsList.getTotalPages());
			return  companyDetailsMap;
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > getAllRetailers", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > getAllRetailers", ee);
		}
		return null;
	}

	@Override
	public Boolean isMobileNoExits(String mobileNo) throws HelthwellExceptionHandler {
		try {
			return companyDetailsDao.isMobileNoExits(mobileNo);
			 
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > mobileNo", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > mobileNo", ee);
		}
		return true;
	}

}
