package com.bcoss.mtrans.service;

import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.constant.SMSTemplates;
import com.bcoss.mtrans.dao.SmsDao;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.sms.SmsProviderSetting;
import com.bcoss.mtrans.jpa.sms.Template;

@Component
public class SmsLogicImpl implements SmsLogic {

	Logger logger = LoggerFactory.getLogger(SmsLogicImpl.class);

	@Autowired
	private  SmsDao smsDaoImpl;

	
	@Override
	public String sendSms(String mobileNo, String message, String service, String mode , int templateId,Integer clinicId) throws HelthwellExceptionHandler {
		String messageTransId;
		boolean result = false;
		try {
			SmsProviderSetting smsConfig=new SmsProviderSetting();
			
			 smsConfig = smsDaoImpl.getSmsConfig(1);
			 
			//messageTransId= "Submitted | 549154856a1042053297";
			 ////RESPONSE-S.585297
			messageTransId = com.bcoss.mtrans.util.SMSUtil.sendSms(smsConfig, mobileNo, message, service, templateId);
			//String[] s3 = messageTransId.trim();
			//messageTransId = s3[2].trim(); // Submitted | 549154856a1042053297
			if (!messageTransId.equals("")) {
				result = smsDaoImpl.saveSms(mobileNo, service, mode, messageTransId ,templateId,clinicId);
				if (!result) {
					throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
				}
			}
		} catch (HelthwellExceptionHandler e) {
			throw e;
		} catch (Exception e) {
			logger.error("Exception Error in SmsLogicImpl - > sendSms ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return messageTransId;
	}
	
	public String sendOtp(String mobileNo, int siteId) throws HelthwellExceptionHandler{
		String otpNum="";
		try {
			
			int length = 4;

			String numbers = "0123456789";

			Random rndm_method = new Random();

			char[] otp = new char[length];

			for (int i = 0; i < length; i++) {
				otp[i] = numbers.charAt(rndm_method.nextInt(numbers.length()));
			}

			 otpNum = String.valueOf(otp);
			System.out.println(":====================" + otpNum);
			String content = "";
			
			if(!mobileNo.isEmpty()) {
				content = SMSTemplates.OTP_SENT;
				content = content.replaceAll("#1", otpNum);
				
				
			}
			sendSms(mobileNo, content, "TRANS", "Debug", 1, length);

		} catch (Exception e) {
			System.out.println("Exception while sending SMS to customer " + mobileNo);
		}
		return otpNum;
	}

	@Override
	public String getBalance(int siteId) throws HelthwellExceptionHandler {

		String result = "";
		try {
			SmsProviderSetting smsConfig = smsDaoImpl.getSmsConfig(siteId);
			result = com.bcoss.mtrans.util.SMSUtil.getBalance(smsConfig);
		} catch (HelthwellExceptionHandler e) {
			throw e;
		} catch (Exception e) {
			logger.error("Exception Error in SmsLogicImpl - > getBalance ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return result;

	}

	@Override
	public Template getSmsTemplateById(Integer templateId) throws HelthwellExceptionHandler {
		Template template;
		String result = "";
		try {
			 template = smsDaoImpl.getSmsTempalte(templateId);
			
		} catch (HelthwellExceptionHandler e) {
			throw e;
		} catch (Exception e) {
			logger.error("Exception Error in SmsLogicImpl - > getBalance ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return template;

	}

	
	@Override
	public String getDeleveryReport(String mobileNo, String messageId,int siteId) throws HelthwellExceptionHandler {

		String result = "";
		try {
			SmsProviderSetting smsConfig = smsDaoImpl.getSmsConfig(siteId);

			String status = com.bcoss.mtrans.util.SMSUtil.deleveryReport(smsConfig, messageId);
			// status=Mobile No : 9405408644 | Sent Time : 2017-08-12 12:14:24 |
			// Sender Name : GRENRY | Transaction Id : 549154856a1042053297 |
			// Service : TRANS | Status : DELIVERED | SMS Credit : 1";

			String[] s3 = status.split("\\s");
			status = s3[33];

			result = smsDaoImpl.getDeliveryReport(mobileNo, messageId, status);
			return result;
		} catch (HelthwellExceptionHandler e) {
			throw e;
		} catch (Exception e) {
			logger.error("Exception Error in SmsLogicImpl - > getDeleveryReport ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}

	
	
	
}
