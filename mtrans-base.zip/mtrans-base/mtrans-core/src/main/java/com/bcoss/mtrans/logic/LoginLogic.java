package com.bcoss.mtrans.logic;

import com.bcoss.mtrans.ChangePasswordDto;
import com.bcoss.mtrans.EmployeeDto;
import com.bcoss.mtrans.UserDetailsDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface LoginLogic {

	EmployeeDto login(EmployeeDto employeeDto)throws HelthwellExceptionHandler;

	EmployeeDto sendOtp(String mono)throws HelthwellExceptionHandler;

	Boolean saveChangePassword(ChangePasswordDto changePasswordDto)throws HelthwellExceptionHandler;

	EmployeeDto reSendPassword(String mono)throws HelthwellExceptionHandler;

}
