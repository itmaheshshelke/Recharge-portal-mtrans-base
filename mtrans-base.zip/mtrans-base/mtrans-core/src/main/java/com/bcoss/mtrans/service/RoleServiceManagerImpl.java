package com.bcoss.mtrans.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bcoss.mtrans.RoleDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.logic.RoleLogic;

@Service
public class RoleServiceManagerImpl implements RoleServiceManager {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(RoleServiceManagerImpl.class);

	@Autowired
	private RoleLogic roleLogic;

	
	public List<RoleDto> getAllRole() throws HelthwellExceptionHandler {
		List<RoleDto> roleDtoList = new ArrayList<RoleDto>();
		try {
			roleDtoList = roleLogic.getAllRole();

		} catch (HibernateException he) {
			logger.error("HibernateException Error in RoleServiceManagerImpl - > getAllRole ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in RoleServiceManagerImpl - > getAllRole ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return roleDtoList;
	}
	
	
	public RoleDto getRoleById(Integer roleId) throws HelthwellExceptionHandler {
		RoleDto roleDto = new RoleDto();
		try {
			roleDto = roleLogic.getRoleById(roleId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in RoleServiceManagerImpl - > getRoleById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in RoleServiceManagerImpl - > getRoleById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return roleDto;
	}

	}
