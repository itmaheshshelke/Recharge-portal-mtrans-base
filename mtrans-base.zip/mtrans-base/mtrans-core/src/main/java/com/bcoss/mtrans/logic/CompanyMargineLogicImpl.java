package com.bcoss.mtrans.logic;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.CompanyDetails;
import com.bcoss.mtrans.dao.CompanyDetailsRepository;
import com.bcoss.mtrans.dao.CompanyMargineDao;
import com.bcoss.mtrans.dao.ServiceOperatorsDao;
import com.bcoss.mtrans.dao.repository.CompanyMargineRepository;
import com.bcoss.mtrans.dto.CompanyMargineDto;
import com.bcoss.mtrans.dto.MargineDto;
import com.bcoss.mtrans.dto.ServiceOperatorsDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.CompanyMargine;
import com.bcoss.mtrans.jpa.ServiceOperators;
import com.bcoss.mtrans.mapper.CompanyMargineMapper;

@Component
public class CompanyMargineLogicImpl implements CompanyMargineLogic{
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(CompanyMargineLogicImpl.class);
	
	@Autowired
	private CompanyMargineDao companyMargineDao;
	@Autowired
	private CompanyMargineRepository companyMargineRepository;

	@Autowired
	private CompanyDetailsRepository companyDetailsRepository;
	@Autowired
	private ServiceOperatorsDao serviceOperatorsDao;
	public List<CompanyMargineDto> getAllCompanyMargine(Integer planId) throws HelthwellExceptionHandler {

		List<CompanyMargineDto> companyMargineDtoList =  new ArrayList<CompanyMargineDto>();
		try {
			List<CompanyMargine> companyMargineList = companyMargineDao.getAllCompanyMargine(planId);
			if (companyMargineList != null && !companyMargineList.isEmpty()) {
				

				for (CompanyMargine companyMargine : companyMargineList) {
					CompanyMargineDto companyMargineDto =CompanyMargineMapper._toDto(companyMargine);
					companyMargineDtoList.add(companyMargineDto);
				}
			}

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineLogicImpl - > getAllCompanyMargine ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineLogicImpl - > getAllCompanyMargine ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return companyMargineDtoList;
	}
	
	@Override
	public 	CompanyMargineDto getCompanyMargineById(Integer companyMargineId) throws HelthwellExceptionHandler{
		CompanyMargineDto companyMargineDto = new CompanyMargineDto();
		try {

			CompanyMargine companyMargine = companyMargineDao.getCompanyMargineById(companyMargineId);
			companyMargineDto = CompanyMargineMapper._toDto(companyMargine);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineLogicImpl - > getCompanyMargineById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineLogicImpl - > getCompanyMargineById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return companyMargineDto;
	}

	@Override
	public	Boolean saveCompanyMargine(CompanyMargineDto companyMargineDto) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {

			
			CompanyMargine companyMargine = CompanyMargineMapper._toJpa(companyMargineDto);
			result = companyMargineDao.saveCompanyMargine(companyMargine);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineLogicImpl - > saveCompanyMargine ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineLogicImpl - > saveCompanyMargine ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public List<CompanyMargineDto> getMarginByPlanId(Integer planId) throws HelthwellExceptionHandler {
		List<CompanyMargineDto> companyMargineDtoList =  new ArrayList<CompanyMargineDto>();
		try {
			List<CompanyMargine> companyMargineList = companyMargineDao.getMarginByPlanId(planId);
			if (companyMargineList != null && !companyMargineList.isEmpty()) {
				

				for (CompanyMargine companyMargine : companyMargineList) {
					CompanyMargineDto companyMargineDto =CompanyMargineMapper._toDto(companyMargine);
					companyMargineDtoList.add(companyMargineDto);
				}
			}

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineLogicImpl - > getMarginByPlanId ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineLogicImpl - > getMarginByPlanId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return companyMargineDtoList;
	}

	@Override
	public List<CompanyMargineDto> getAllCompanyMargineBycompanyId(Integer companyId) throws HelthwellExceptionHandler {
		List<CompanyMargineDto> companyMargineDtoList =  new ArrayList<CompanyMargineDto>();
		try {
			
			List<CompanyMargine> companyMargineList = companyMargineDao.getAllCompanyMargineBycompanyId(companyId);
			if (companyMargineList != null && !companyMargineList.isEmpty()) {
				

				for (CompanyMargine companyMargine : companyMargineList) {
					CompanyMargineDto companyMargineDto =CompanyMargineMapper._toDto(companyMargine);
					companyMargineDtoList.add(companyMargineDto);
				}
			}

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineLogicImpl - > getAllCompanyMargineBycompanyId ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineLogicImpl - > getAllCompanyMargineBycompanyId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return companyMargineDtoList;

	}

	@Override
	public List<CompanyMargineDto> getAllCompanyMargineByMargineType(Integer margineType, Integer companyId,
			Integer serviceId) throws HelthwellExceptionHandler {
		List<CompanyMargineDto> companyMargineDtoList = new ArrayList<CompanyMargineDto>();
		try {

			
			List<CompanyMargine> companyMargineList = companyMargineDao.getAllCompanyMargineByMargineType(
					margineType, companyId, serviceId);
			if (companyMargineList != null && !companyMargineList.isEmpty()) {

				for (CompanyMargine companyMargine : companyMargineList) {
					ServiceOperators ServiceOperators = serviceOperatorsDao
							.getServiceOperatorsById(companyMargine.getOperatorId());
					CompanyMargineDto companyMargineDto = CompanyMargineMapper._toDto(companyMargine);
					companyMargineDto.setOperatorName(ServiceOperators.getOperator());
					companyMargineDtoList.add(companyMargineDto);
				}
				
			}
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineLogicImpl - > getAllCompanyMargineByMargineType ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineLogicImpl - > getAllCompanyMargineByMargineType ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return companyMargineDtoList;
	}

	@Override
	public List<MargineDto> getMargineData(Integer margineType, Integer serviceId) throws HelthwellExceptionHandler {
		List<MargineDto> margineDtoList = new ArrayList<>();
		try {

			margineDtoList = companyMargineDao.getMargineData(margineType,serviceId);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineLogicImpl - > getMargineData ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineLogicImpl - > getMargineData ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return margineDtoList;
	}

	@Override
	public CompanyMargineDto getCompanyMargineByCompanyAndOperatorId(Integer companyId, Integer operatorId)
			throws HelthwellExceptionHandler {
		 CompanyMargineDto companyMargineDto=new CompanyMargineDto();
		try {
			CompanyMargine companyMargine = companyMargineDao.getCompanyMargineByCompanyAndOperatorId(companyId,operatorId);
			if (null != companyMargine) {
				companyMargineDto = CompanyMargineMapper._toDto(companyMargine);
			} else {
				return null;
			}
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineLogicImpl - > getAllCompanyMargine ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineLogicImpl - > getAllCompanyMargine ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return companyMargineDto;
	}
	
}
