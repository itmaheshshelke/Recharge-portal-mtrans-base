package com.bcoss.mtrans.logic;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.ChangePasswordDto;
import com.bcoss.mtrans.Employee;
import com.bcoss.mtrans.EmployeeDto;
import com.bcoss.mtrans.dao.LoginDao;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.sms.Template;
import com.bcoss.mtrans.mapper.EmployeeMapper;
import com.bcoss.mtrans.service.SmsLogic;


@Component
public class LoginLogicImpl implements LoginLogic {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(LoginLogicImpl.class);

	@Autowired
	private LoginDao loginDao;
	
	@Autowired
	private SmsLogic smsLogic;

	
	
	@Override
	public EmployeeDto login(EmployeeDto employeeDto) throws HelthwellExceptionHandler {
		
		try {
			String userName=employeeDto.getContactNo();
			String Password=employeeDto.getPassword();
			
			Employee employee = loginDao.login(userName,Password);
			employeeDto=EmployeeMapper._toDto(employee);
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in LoginLogicImpl - > login ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in LoginLogicImpl - > login ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return employeeDto;
	}



	@Override
	public EmployeeDto sendOtp(String mobNo) throws HelthwellExceptionHandler {
			Boolean result = false;
			 EmployeeDto employeeDto = new EmployeeDto();  
			Long otp = Math.round(Math.random() * 10000000); 
			try {
				
				Employee employee = loginDao.sendOtp(mobNo);
				  employeeDto = EmployeeMapper._toDto(employee);
				 employeeDto.setOtp(otp);
				if(result = true) {
					
					final String otp1 = String.valueOf(otp);
				
					final String mobileNo = mobNo;
					Template template = smsLogic.getSmsTemplateById(3);
					Thread t = new Thread(new Runnable() {

						@Override
						public void run() {

							try {
								
								String content = "";
								content = template.getSmsBody();
								content = content.replaceAll("##1",otp1);
								
								smsLogic.sendSms(mobileNo, content, "TRANS", "Debug", template.getTemplateId(),1);

							} catch (Exception e) {
								System.out.println("Exception while sending SMS to customer " + mobileNo);
							}

						}
					});
					t.start();
					
					}
				

			} catch (HibernateException he) {
				logger.error("HibernateException Error in LoginLogicImpl - > sendOtp ", he);
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
			} catch (Exception e) {
				logger.error("Exception Error in LoginLogicImpl - > sendOtp ", e);
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
			}
			return employeeDto;
		
	}

	
	@Override
	public EmployeeDto reSendPassword(String mobNo) throws HelthwellExceptionHandler {
			Boolean result = false;
			 EmployeeDto employeeDto = new EmployeeDto();  
			try {
				
				Employee employee = loginDao.sendOtp(mobNo);
				if(employee!=null) {
				  employeeDto = EmployeeMapper._toDto(employee);
				if(result = true) {
					
					final String otp1 = String.valueOf(employeeDto.getPassword());
				
					final String mobileNo = mobNo;
					Template template = smsLogic.getSmsTemplateById(5);
					Thread t = new Thread(new Runnable() {

						@Override
						public void run() {

							try {
								
								String content = "";
								content = template.getSmsBody();
								content = content.replaceAll("##1",otp1);
								
								smsLogic.sendSms(mobileNo, content, "TRANS", "Debug", template.getTemplateId(),1);

							} catch (Exception e) {
								System.out.println("Exception while sending SMS to customer " + mobileNo);
							}

						}
					});
					t.start();
					
					}
				}
			} catch (HibernateException he) {
				logger.error("HibernateException Error in LoginLogicImpl - > reSendPassword ", he);
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
			} catch (Exception e) {
				logger.error("Exception Error in LoginLogicImpl - > reSendPassword ", e);
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
			}
			return employeeDto;
		
	}



	@Override
	public Boolean saveChangePassword(ChangePasswordDto changePasswordDto) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {

			result = loginDao.saveChangePassword(changePasswordDto);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in LoginLogicImpl - > saveChangePassword ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in LoginLogicImpl - > saveChangePassword ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		
		return result;
	}

	}


