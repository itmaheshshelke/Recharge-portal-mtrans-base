package com.bcoss.mtrans.service;

import java.util.List;

import com.bcoss.mtrans.DistrictDto;
import com.bcoss.mtrans.StateDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface StateServiceManager {


	StateDto getStateById(Integer stateId)throws HelthwellExceptionHandler;

	List<StateDto> getAllState()throws HelthwellExceptionHandler;

	List<DistrictDto> getAllDistrict(Integer stateId)throws HelthwellExceptionHandler;

	
}
