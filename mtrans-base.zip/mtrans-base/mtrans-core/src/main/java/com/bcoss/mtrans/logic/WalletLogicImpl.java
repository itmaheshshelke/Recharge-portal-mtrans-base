package com.bcoss.mtrans.logic;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.CompanyDetails;
import com.bcoss.mtrans.CompanyDetailsDto;
import com.bcoss.mtrans.dao.CompanyDetailsDao;
import com.bcoss.mtrans.dao.WalletDao;
import com.bcoss.mtrans.dto.EmailSettingDto;
import com.bcoss.mtrans.dto.WalletDto;
import com.bcoss.mtrans.dto.WalletTransactionDto;
import com.bcoss.mtrans.email.EmailMessage;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.Wallet;
import com.bcoss.mtrans.jpa.WalletTransaction;
import com.bcoss.mtrans.jpa.sms.Template;
import com.bcoss.mtrans.mapper.WalletMapper;
import com.bcoss.mtrans.mapper.WalletTransactionMapper;
import com.bcoss.mtrans.service.SmsLogic;
import com.bcoss.mtrans.util.EmailUtil;

@Component
public class WalletLogicImpl implements WalletLogic{
	
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(WalletLogicImpl.class);

	@Autowired
	private WalletDao walletDao;
	
	@Autowired
	private CompanyDetailsDao companyDetailsDao;
	
	@Autowired
	private SmsLogic smsLogic;
	
	@Value("${mtrans.email.email}")
	private String emailId;

	@Value("${mtrans.email.password}")
	private String password;

	@Value("${mtrans.email.host}")
	private String host;

	@Value("${mtrans.email.port}")
	private String port;
	
	@Value("${mtrans.email.template}")
	private String templatePath;

	@Override
	public WalletDto getwalletById(Integer walletId) throws HelthwellExceptionHandler {
		WalletDto walletDto = new WalletDto();
		try {

			Wallet wallet = walletDao.getwalletById(walletId);
			walletDto = WalletMapper._toDto(wallet);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletLogicImpl - > getwalletById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalletLogicImpl - > getwalletById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return walletDto;
	}

	@Override
	public List<CompanyDetailsDto> getAllCompanyWallateBalance(Integer companyId) throws HelthwellExceptionHandler {
		List<CompanyDetailsDto> companyDetailsDtoList=new ArrayList<>();
		try {
			 companyDetailsDtoList = walletDao.getAllCompanyWallateBalance(companyId);
			

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletLogicImpl - > getAllCompanyWallateBalance ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalletLogicImpl - > getAllCompanyWallateBalance ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return companyDetailsDtoList;
	}

	@Override
	public List<CompanyDetailsDto> companyRecharge(Integer companyId) throws HelthwellExceptionHandler {
		List<CompanyDetailsDto> companyDetailsDtoList = null;
		
		try {
			/*List<CompanyDetails> companyDetailsList = walletDao.companyRecharge(companyId);
			if (companyDetailsList != null && !companyDetailsList.isEmpty()) {
				Wallet wallet=new Wallet();
				companyDetailsDtoList = new ArrayList<CompanyDetailsDto>();
				for (CompanyDetails companyDetails : companyDetailsList) {
					CompanyDetailsDto companyDetailsDto = CompanyDetailsMapper._toDto(companyDetails);
					if(companyDetailsDto.getCompanyId()!=1)
					 wallet = walletDao.getwalletById(companyDetailsDto.getWalletId());
					if(wallet.getBalance()!=null)
					companyDetailsDto.setBalance(wallet.getBalance());
					companyDetailsDtoList.add(companyDetailsDto);
				}
			}*/
			 companyDetailsDtoList = walletDao.getAllCompanyWallateBalance(companyId);
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in WalletLogicImpl- > companyRecharge", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in WalletLogicImpl- > companyRecharge", ee);
		}
		return companyDetailsDtoList;
	}

	@Override
	public List<WalletTransactionDto> getAllCompanyTransaction(Integer companyId) throws HelthwellExceptionHandler {
		List<WalletTransaction> WalletTransactionList=new ArrayList<>();
		List<WalletTransactionDto> walletTransactionDtoList=new ArrayList<>();
		try {
			WalletTransactionList = walletDao.getAllCompanyTransaction(companyId);
			for (WalletTransaction walletTransaction : WalletTransactionList) {
				WalletTransactionDto WalletTransactionDto=WalletTransactionMapper._toDto(walletTransaction);
				
					CompanyDetails companyDetails=companyDetailsDao.getCompanyDetailsById(walletTransaction.getCreatedBy());
					if (companyDetails!=null) {
						WalletTransactionDto.setRechargeBy(companyDetails.getCompanyName());
					}
					
					
				
				
				walletTransactionDtoList.add(WalletTransactionDto);
			}

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletLogicImpl - > getAllCompanyTransaction ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalletLogicImpl - > getAllCompanyTransaction ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return walletTransactionDtoList;
	}

	@Override
	public Boolean updateWallet(WalletDto walletDto) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {

			result = walletDao.updateWallet(walletDto);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletLogicImpl - > updateWallet ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalletLogicImpl - > updateWallet ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public Boolean saveRechargeWallet(Integer loggedCompanyId ,Integer companyId, Double rechargeamount,char type) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {

			// deduct balance of parent company

			WalletDto walletDto = new WalletDto();
			CompanyDetails companyDetails = companyDetailsDao.getCompanyDetailsById(loggedCompanyId);
			Wallet wallet = null;
			Double currBal = 0.0;
			
			
			
			walletDto = new WalletDto();
			companyDetails = companyDetailsDao.getCompanyDetailsById(companyId);
			wallet = walletDao.getwalletById(companyDetails.getWalletId());

			currBal = wallet.getBalance();
			currBal = currBal + rechargeamount;

			walletDto.setWalletId(companyDetails.getWalletId());
			walletDto.setBalance(currBal);
			result = walletDao.saveRechargeWallet(walletDto, loggedCompanyId, rechargeamount, type);

			final String mobileNo = companyDetails.getContactNo();
			final Double amount = rechargeamount;
			Template template = smsLogic.getSmsTemplateById(4);

			String name = companyDetails.getCompanyName();
			Thread t = new Thread(new Runnable() {

				@Override
				public void run() {

					try {
						String content = "";
						content = template.getSmsBody();
						content = content.replaceAll("##1", name);
						content = content.replaceAll("##2", String.valueOf(rechargeamount));
						smsLogic.sendSms(mobileNo, content, "TRANS", "Debug", template.getTemplateId(), companyId);

					} catch (Exception e) {
						System.out.println("Exception while sending SMS to customer " + mobileNo);
					}

				}
			});
			t.start();

			EmailSettingDto emailSettingDto = new EmailSettingDto(emailId, password, Integer.parseInt(port), host);

			String balance = walletDto.getBalance().toString();// companyDetails.getCompanyName();
			String email = companyDetails.getEmailId();
			final String EMAIL_TEMPLATE = "Wallet_Recharged.htm";
			String templateUrl = templatePath + File.separator + EMAIL_TEMPLATE ;
			final String emailUrl=templateUrl;
			Thread emailThread = new Thread(new Runnable() {
				public void run() {
					EmailMessage em = new EmailMessage();
					em.setRetryCount(2);
					String htmlEmailPath = emailUrl;
					String content = EmailUtil.getEmailHtmlFile(htmlEmailPath);
					content = content.replaceAll("###1", name);
					content = content.replaceAll("###2", rechargeamount.toString());
					content = content.replaceAll("###3", mobileNo);
					content = content.replaceAll("###4", balance);
					content = content.replaceAll("###5", "RKSS Technologies Pvt. Ltd.");
					EmailUtil.sendEmail(emailSettingDto, em, email, "Wallet recharged with Rs. " + rechargeamount,
							content);
				}
			});
			emailThread.start();
		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletLogicImpl - > updateWallet ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalletLogicImpl - > updateWallet ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}
	@Override
	public Boolean addRequestRecharge(WalletTransaction walletTransaction) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {

			result = walletDao.addRequestRecharge(walletTransaction);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletLogicImpl - > addRequestRecharge ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalletLogicImpl - > addRequestRecharge ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public List<CompanyDetailsDto> getRequestRecharge(Integer login_companyId) throws HelthwellExceptionHandler {
		List<CompanyDetailsDto> companyDetailsList=null;
		try {
			 companyDetailsList = walletDao.getRequestRecharge(login_companyId);
			
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in WalletLogicImpl- > getRequestRecharge", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in WalletLogicImpl- > getRequestRecharge", ee);
		}
		return companyDetailsList;
	}

	@Override
	public Boolean approveRequest(String transNumber,Integer login_walletId,Integer login_companyId) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {

			result = walletDao.approveRequest(transNumber,login_walletId,login_companyId);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletLogicImpl - > approveRequest ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalletLogicImpl - > approveRequest ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public Boolean activeDeactiveCompany(Integer compnayId,Integer isActive) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {

			result = walletDao.activeDeactiveCompany(compnayId,isActive);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletLogicImpl - > activeDeactiveCompany ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalletLogicImpl - > activeDeactiveCompany ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public Boolean saveDeductWalletBalance(Integer loggedCompanyId, Integer walletId, Double deductAmount,char type)
			throws HelthwellExceptionHandler {
		Boolean result=false;
		try {

			// deduct balance of parent company

			
			WalletDto	walletDto = new WalletDto();
			Wallet	wallet = walletDao.getwalletById(walletId);

			Double currBal = wallet.getBalance();
			
			if(currBal>0) {
				currBal = currBal-deductAmount;

				walletDto.setWalletId(walletId);
				walletDto.setBalance(currBal);
				result = walletDao.saveRechargeWallet(walletDto, loggedCompanyId, deductAmount, type);
			}
			

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletLogicImpl - > updateWallet ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalletLogicImpl - > updateWallet ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;

	}

	@Override
	public WalletDto getTotalWalletRecharge(Integer login_companyId) throws HelthwellExceptionHandler {
		WalletDto walletDto = new WalletDto();
		try {

			Wallet wallet = walletDao.getTotalWalletRecharge(login_companyId);
			walletDto = WalletMapper._toDto(wallet);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletLogicImpl - > getTotalWalletRecharge ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalletLogicImpl - > getTotalWalletRecharge ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return walletDto;
	}

	@Override
	public Boolean readWriteCompany(Integer compnayId, Character isReadOnly) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {

			result = walletDao.readWriteCompany(compnayId,isReadOnly);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletLogicImpl - > readWriteCompany ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalletLogicImpl - > readWriteCompany ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	
}
