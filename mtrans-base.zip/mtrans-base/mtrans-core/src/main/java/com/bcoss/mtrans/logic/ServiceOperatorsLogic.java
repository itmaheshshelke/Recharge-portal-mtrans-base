package com.bcoss.mtrans.logic;

import java.util.List;

import com.bcoss.mtrans.dto.ServiceOperatorsDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface ServiceOperatorsLogic {
	List<ServiceOperatorsDto> getAllServiceOperators()throws HelthwellExceptionHandler;

	ServiceOperatorsDto getServiceOperatorsById(Integer servicesId)throws HelthwellExceptionHandler;

	Boolean saveServiceOperators(ServiceOperatorsDto serviceOperatorsDto)throws HelthwellExceptionHandler;

	Boolean deleteServiceOperators(Integer servicesId)throws HelthwellExceptionHandler;

	List<ServiceOperatorsDto> getOperatorByServiceId(Integer serviceId)throws HelthwellExceptionHandler;

}
