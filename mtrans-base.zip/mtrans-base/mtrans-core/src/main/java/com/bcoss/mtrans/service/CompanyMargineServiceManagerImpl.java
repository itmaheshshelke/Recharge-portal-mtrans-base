package com.bcoss.mtrans.service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bcoss.mtrans.dto.CompanyMargineDto;
import com.bcoss.mtrans.dto.MargineDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.logic.CompanyMargineLogic;

@Service
public class CompanyMargineServiceManagerImpl implements CompanyMargineServiceManager {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(CompanyMargineServiceManagerImpl.class);


	@Autowired
	private  CompanyMargineLogic companyMargineLogic;
	
	@Override
	public	List<CompanyMargineDto> getAllCompanyMargine(Integer planId)throws HelthwellExceptionHandler {
		List<CompanyMargineDto> companyMargineDtoList = new ArrayList<CompanyMargineDto>();
		try {
			companyMargineDtoList = companyMargineLogic.getAllCompanyMargine(planId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineServiceManagerImpl - > getAllCompanyMargine ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineServiceManagerImpl - > getAllCompanyMargine ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return companyMargineDtoList;
	}
	
	@Override
	public CompanyMargineDto getcompanyMargineById(Integer companyMargineId)throws HelthwellExceptionHandler {
		CompanyMargineDto companyMargineDto = new CompanyMargineDto();
		try {
			companyMargineDto = companyMargineLogic.getCompanyMargineById(companyMargineId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineServiceManagerImpl - > getcompanyMargineById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineServiceManagerImpl - > getcompanyMargineById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return companyMargineDto;
	}
	
	@Override
	public Boolean saveCompanyMargine(CompanyMargineDto companyMargineDto)throws HelthwellExceptionHandler {
		Boolean result = false;
		try {

			result = companyMargineLogic.saveCompanyMargine(companyMargineDto);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineServiceManagerImpl - > saveCompanyMargine ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineServiceManagerImpl - > saveCompanyMargine ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public List<CompanyMargineDto> getMarginByPlanId(Integer planId) throws HelthwellExceptionHandler {
		List<CompanyMargineDto> companyMargineDtoList = new ArrayList<CompanyMargineDto>();
		try {
			companyMargineDtoList = companyMargineLogic.getMarginByPlanId(planId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineServiceManagerImpl - > getMarginByPlanId ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineServiceManagerImpl - > getMarginByPlanId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return companyMargineDtoList;
	}

	@Override
	public List<CompanyMargineDto> getAllCompanyMargineBycompanyId(Integer companyId) throws HelthwellExceptionHandler {
		List<CompanyMargineDto> companyMargineDtoList = new ArrayList<CompanyMargineDto>();
		try {
			companyMargineDtoList = companyMargineLogic.getAllCompanyMargineBycompanyId(companyId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineServiceManagerImpl - > getAllCompanyMargineBycompanyId ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineServiceManagerImpl - > getAllCompanyMargineBycompanyId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return companyMargineDtoList;
	}

	@Override
	public List<CompanyMargineDto> getAllCompanyMargineByMargineType(Integer margineType,Integer companyId, Integer serviceId)
			throws HelthwellExceptionHandler {
		List<CompanyMargineDto> companyMargineDtoList = new ArrayList<CompanyMargineDto>();
		try {
			companyMargineDtoList = companyMargineLogic.getAllCompanyMargineByMargineType(margineType,companyId,serviceId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineServiceManagerImpl - > getAllCompanyMargineByMargineType ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineServiceManagerImpl - > getAllCompanyMargineByMargineType ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return companyMargineDtoList;
	}

	@Override
	public List<MargineDto> getMargineData(Integer margineType, Integer serviceId) throws HelthwellExceptionHandler {
		List<MargineDto> margineDtoList = new ArrayList<MargineDto>();
		try {
			margineDtoList = companyMargineLogic.getMargineData(margineType,serviceId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineServiceManagerImpl - > getMargineData ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineServiceManagerImpl - > getMargineData ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return margineDtoList;
	}

	@Override
	public CompanyMargineDto getCompanyMargineByCompanyAndOperatorId(Integer companyId, Integer operatorId)
			throws HelthwellExceptionHandler {
		CompanyMargineDto companyMargineDto=new CompanyMargineDto();
		try {
			companyMargineDto = companyMargineLogic.getCompanyMargineByCompanyAndOperatorId(companyId,operatorId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineServiceManagerImpl - > getCompanyMargineByCompanyAndOperatorId ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineServiceManagerImpl - > getCompanyMargineByCompanyAndOperatorId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return companyMargineDto;
	}



}
