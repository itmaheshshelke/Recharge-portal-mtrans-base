package com.bcoss.mtrans.logic;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.dao.ServicesDao;
import com.bcoss.mtrans.dto.ServicesDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.Services;
import com.bcoss.mtrans.mapper.ServicesMapper;

@Component
public class ServicesLogicImpl implements ServicesLogic {

	
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(ServicesLogicImpl.class);

	@Autowired
	private ServicesDao servicesDao;

	@Override
	public List<ServicesDto> getAllServices(Integer planId) throws HelthwellExceptionHandler {
		List<ServicesDto> servicesDtoList =new ArrayList<>();
		try {
			List<Services> servicesList = servicesDao.getAllServices(planId);
			if (servicesList != null && !servicesList.isEmpty()) {
				

				for (Services services : servicesList) {
					ServicesDto servicesDto = ServicesMapper._toDto(services);
					servicesDtoList.add(servicesDto);
				}
			}
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServicesLogicImpl - > getAllServices ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServicesLogicImpl - > getAllServices ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return servicesDtoList;
	}

	@Override
	public ServicesDto getServicesById(Integer serviceId) throws HelthwellExceptionHandler {
		ServicesDto servicesDto = new ServicesDto();
		try {

			Services services = servicesDao.getServicesById(serviceId);
			servicesDto = ServicesMapper._toDto(services);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServicesLogicImpl - > getServicesById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServicesLogicImpl - > getServicesById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return servicesDto;
	}
	
	@Override
	public Boolean saveServices(ServicesDto servicesDto) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {

			
			Services services =ServicesMapper._toJpa(servicesDto);
			result = servicesDao.saveServices(services);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServicesLogicImpl - > saveServices ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServicesLogicImpl - > saveServices ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public Boolean deleteServices(Integer serviceId)throws HelthwellExceptionHandler {
		Boolean result = false;
		try {

			result = servicesDao.deleteServices(serviceId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServicesLogicImpl - > deleteServices ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServicesLogicImpl - > deleteServices ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

}
