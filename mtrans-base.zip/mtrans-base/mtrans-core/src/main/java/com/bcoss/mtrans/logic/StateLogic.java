package com.bcoss.mtrans.logic;

import java.util.List;

import com.bcoss.mtrans.DistrictDto;
import com.bcoss.mtrans.StateDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface StateLogic {
	List<StateDto> getAllState()throws HelthwellExceptionHandler;

	StateDto getStateById(Integer stateId)throws HelthwellExceptionHandler;

	List<DistrictDto> getAllDistrict(Integer stateId)throws HelthwellExceptionHandler;


}
