package com.bcoss.mtrans.service;

import java.util.List;

import com.bcoss.mtrans.Address;
import com.bcoss.mtrans.AddressDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;


public interface AddressServiceManager {

	List<AddressDto> getAllAddress() throws HelthwellExceptionHandler;
	AddressDto getAddressById(int id) throws HelthwellExceptionHandler;
	Address addAddress(Address address) throws HelthwellExceptionHandler;
	Address updateAddress(Address address) throws HelthwellExceptionHandler;
	boolean deleteAddress(int id) throws HelthwellExceptionHandler;
    
}
