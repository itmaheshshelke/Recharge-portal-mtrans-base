package com.bcoss.mtrans.service;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Pageable;

import com.bcoss.mtrans.CompanyDetailsDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface CompanyDetailsServiceManager {
	
	List<CompanyDetailsDto> getAllCompanyDetails(Integer companyId) throws HelthwellExceptionHandler;
	CompanyDetailsDto getCompanyDetailsById(int id) throws HelthwellExceptionHandler;
	Boolean addCompanyDetails(CompanyDetailsDto companyDetailsDto) throws HelthwellExceptionHandler;
	Boolean updateCompanyDetails(CompanyDetailsDto companyDetailsDto) throws HelthwellExceptionHandler;
	boolean deleteCompanyDetails(int id) throws HelthwellExceptionHandler;
	Object searchCompanyDetails(Integer companyId, String qString)throws HelthwellExceptionHandler;
	Map<String, Object> getAllDistributors(Pageable pageable, Integer companyId, String searchTerm)throws HelthwellExceptionHandler;
	Map<String, Object> getAllRetailers(Integer distributorId, Pageable pageable, String searchTerm)throws HelthwellExceptionHandler;
	Boolean isMobileNoExits(String mobileNo)throws HelthwellExceptionHandler;
	

}
