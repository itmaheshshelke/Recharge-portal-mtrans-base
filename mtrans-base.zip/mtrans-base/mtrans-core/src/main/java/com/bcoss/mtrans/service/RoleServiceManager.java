package com.bcoss.mtrans.service;

import java.util.List;

import com.bcoss.mtrans.RoleDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface RoleServiceManager {

	RoleDto getRoleById(Integer roleId) throws HelthwellExceptionHandler;

	List<RoleDto> getAllRole()throws HelthwellExceptionHandler;

	
}
