package com.bcoss.mtrans.rest;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.bcoss.mtrans.dto.ActivateBenificiaryDto;
import com.bcoss.mtrans.dto.BenificiaryDto;
import com.bcoss.mtrans.dto.CreateUserDto;
import com.bcoss.mtrans.dto.MoneyTransferDto;
import com.bcoss.mtrans.dto.provider.response.AddBenificiaryResponseDto;
import com.bcoss.mtrans.dto.provider.response.QRMoneyTransferCheckUserDto;
import com.bcoss.mtrans.dto.provider.response.SendMoneyResponseDto;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class MoneyTransferRestClient {

private Logger logger = LoggerFactory.getLogger(CrowfinchRestClient.class);
	
	private String baseUrl = "https://www.quickrecharge.in/money_api/";
	private String userName = "9762461555";
	private String password = "9762461555";
	private String pin = "68870";

	RestTemplate restTemplate = new RestTemplate();
	
	public QRMoneyTransferCheckUserDto checkUser(String mobileNumber) {

		QRMoneyTransferCheckUserDto response = null;
		
		String endPoint = baseUrl + "checkuser";
		
	//	logger.info("Recharge request of company {} is {} ",companyId,endPoint);
		
		MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
		map.add("member_id", userName);
		map.add("api_password", password);
		map.add("api_pin", pin);
		map.add("mobile_no", mobileNumber);
		
		String result = restTemplate.postForObject(endPoint, map, String.class);

		logger.info("Check user response is {} ",result);
		
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			response = mapper.readValue(result, QRMoneyTransferCheckUserDto.class);

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		result = "Request : "+endPoint + " ,  Response "+result;
		//response.setRequestUrl(endPoint);
		//response.setResponse(result);

		return response;
	}
	
	public AddBenificiaryResponseDto addBenificiary(BenificiaryDto benificiaryDto) {

		AddBenificiaryResponseDto response = null;
		
		String endPoint = baseUrl + "addBeneficiary";
		
	//	logger.info("Recharge request of company {} is {} ",companyId,endPoint);
		
		MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
		map.add("member_id", userName);
		map.add("api_password", password);
		map.add("api_pin", pin);
		map.add("mobile_no", benificiaryDto.getMobile());
		map.add("beneficiary_name", benificiaryDto.getName());
		map.add("remitterid", benificiaryDto.getRemitterId());
		map.add("account_no", benificiaryDto.getAccountNumber());
		map.add("IFSC", benificiaryDto.getIfscNumber());
		
		String result = restTemplate.postForObject(endPoint, map, String.class);

		logger.info("Check user response is {} ",result);
		
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			response = mapper.readValue(result, AddBenificiaryResponseDto.class);

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		result = "Request : "+endPoint + " ,  Response "+result;
		//response.setRequestUrl(endPoint);
		//response.setResponse(result);

		return response;
	}
	
	public QRMoneyTransferCheckUserDto resendOtp(ActivateBenificiaryDto activateBenificiaryDto) {

		QRMoneyTransferCheckUserDto response = null;
		
		String endPoint = baseUrl + "BeneficiaryresendOtp";
		
	//	logger.info("Recharge request of company {} is {} ",companyId,endPoint);
		
		MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
		map.add("member_id", userName);
		map.add("api_password", password);
		map.add("api_pin", pin);
		map.add("beneficiary_id", activateBenificiaryDto.getBenificiaryId());
		map.add("remitter_id", activateBenificiaryDto.getRemitterId());
		
		String result = restTemplate.postForObject(endPoint, map, String.class);

		logger.info("Check user response is {} ",result);
		
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			response = mapper.readValue(result, QRMoneyTransferCheckUserDto.class);

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		result = "Request : "+endPoint + " ,  Response "+result;
		//response.setRequestUrl(endPoint);
		//response.setResponse(result);

		return response;
	}
	
	public QRMoneyTransferCheckUserDto activateBenificiary(ActivateBenificiaryDto activateBenificiaryDto) {

		QRMoneyTransferCheckUserDto response = null;
		
		String endPoint = baseUrl + "BeneficiaryverifyOtp";
		
	//	logger.info("Recharge request of company {} is {} ",companyId,endPoint);
		
		MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
		map.add("member_id", userName);
		map.add("api_password", password);
		map.add("api_pin", pin);
		map.add("beneficiary_id", activateBenificiaryDto.getBenificiaryId());
		map.add("remitter_id", activateBenificiaryDto.getRemitterId());
		map.add("otp", activateBenificiaryDto.getOtp());
		
		String result = restTemplate.postForObject(endPoint, map, String.class);

		logger.info("Check user response is {} ",result);
		
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			response = mapper.readValue(result, QRMoneyTransferCheckUserDto.class);

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		result = "Request : "+endPoint + " ,  Response "+result;
		//response.setRequestUrl(endPoint);
		//response.setResponse(result);

		return response;
	}
	
	public QRMoneyTransferCheckUserDto deleteBenificiaryOtp(ActivateBenificiaryDto activateBenificiaryDto) {

		QRMoneyTransferCheckUserDto response = null;
		
		String endPoint = baseUrl + "delBeneficiaryverifyOtp";
		
	//	logger.info("Recharge request of company {} is {} ",companyId,endPoint);
		
		MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
		map.add("member_id", userName);
		map.add("api_password", password);
		map.add("api_pin", pin);
		map.add("beneficiary_id", activateBenificiaryDto.getBenificiaryId());
		map.add("remitter_id", activateBenificiaryDto.getRemitterId());
		map.add("otp", activateBenificiaryDto.getOtp());
		
		String result = restTemplate.postForObject(endPoint, map, String.class);

		logger.info("Check user response is {} ",result);
		
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			response = mapper.readValue(result, QRMoneyTransferCheckUserDto.class);

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		result = "Request : "+endPoint + " ,  Response "+result;
		//response.setRequestUrl(endPoint);
		//response.setResponse(result);

		return response;
	}
	
	
	public QRMoneyTransferCheckUserDto createUser(CreateUserDto createUserDto) {

		QRMoneyTransferCheckUserDto response = null;
		
		String endPoint = baseUrl + "createuser";
		
	//	logger.info("Recharge request of company {} is {} ",companyId,endPoint);
		
		MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
		map.add("member_id", userName);
		map.add("api_password", password);
		map.add("api_pin", pin);
		map.add("mobile_no", createUserDto.getMobileNumber());
		map.add("pin", createUserDto.getPin());
		map.add("customer_name", createUserDto.getCustomerName());
		
		String result = restTemplate.postForObject(endPoint, map, String.class);

		logger.info("Check user response is {} ",result);
		
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			response = mapper.readValue(result, QRMoneyTransferCheckUserDto.class);

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		result = "Request : "+endPoint + " ,  Response "+result;
		//response.setRequestUrl(endPoint);
		//response.setResponse(result);

		return response;
	}
	
	public QRMoneyTransferCheckUserDto deleteBenificiary(ActivateBenificiaryDto activateBenificiaryDto) {

		QRMoneyTransferCheckUserDto response = null;
		
		String endPoint = baseUrl + "deleteBeneficiary";
		
	//	logger.info("Recharge request of company {} is {} ",companyId,endPoint);
		
		MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
		map.add("member_id", userName);
		map.add("api_password", password);
		map.add("api_pin", pin);
		map.add("beneficiary_id", activateBenificiaryDto.getBenificiaryId());
		map.add("remitter_id", activateBenificiaryDto.getRemitterId());
		
		String result = restTemplate.postForObject(endPoint, map, String.class);

		logger.info("Check user response is {} ",result);
		
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			response = mapper.readValue(result, QRMoneyTransferCheckUserDto.class);

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		result = "Request : "+endPoint + " ,  Response "+result;
		//response.setRequestUrl(endPoint);
		//response.setResponse(result);

		return response;
	}
	
	
	public SendMoneyResponseDto moneyTransfer(MoneyTransferDto moneyTransferDto) {

		SendMoneyResponseDto response = null;
		
		String endPoint = baseUrl + "moneytransfer";
		
	//	logger.info("Recharge request of company {} is {} ",companyId,endPoint);
		
		MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
		map.add("member_id", userName);
		map.add("api_password", password);
		map.add("api_pin", pin);
		map.add("mobile_no", moneyTransferDto.getMobileNo());
		map.add("beneficiary_code", moneyTransferDto.getBeneficiaryCode());
		map.add("amount", moneyTransferDto.getAmount());
		map.add("transfer_type", moneyTransferDto.getTransferType());
		map.add("member_request_id", getUniqueTransactionCode());
		
		String result = restTemplate.postForObject(endPoint, map, String.class);

		logger.info("Check user response is {} ",result);
		
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			response = mapper.readValue(result, SendMoneyResponseDto.class);

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		result = "Request : "+endPoint + " ,  Response "+result;

		return response;
	}
	
	public static String getUniqueTransactionCode() {
		String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

		StringBuilder builder = new StringBuilder();
		int count = 7;
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}
}
