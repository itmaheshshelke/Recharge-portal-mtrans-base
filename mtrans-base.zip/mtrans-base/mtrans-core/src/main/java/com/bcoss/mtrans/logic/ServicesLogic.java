package com.bcoss.mtrans.logic;

import java.util.List;

import com.bcoss.mtrans.dto.ServicesDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface ServicesLogic {
	List<ServicesDto> getAllServices(Integer planId)throws HelthwellExceptionHandler;

	ServicesDto getServicesById(Integer servicesId)throws HelthwellExceptionHandler;

	Boolean saveServices(ServicesDto servicesDto)throws HelthwellExceptionHandler;

	Boolean deleteServices(Integer servicesId)throws HelthwellExceptionHandler;

}
