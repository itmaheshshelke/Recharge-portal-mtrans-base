package com.bcoss.mtrans.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Pageable;

import com.bcoss.mtrans.dto.DashbordDto;
import com.bcoss.mtrans.dto.LiveTransactionReportDto;
import com.bcoss.mtrans.dto.MoneyTransferResponseDto;
import com.bcoss.mtrans.dto.ServiceResponseDto;
import com.bcoss.mtrans.dto.WalletTransactionDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.util.FlowData;

public interface ReportServiceManager {

	Map<String, Object> showRechargeReportByDate(Integer serviceId, Date startDate, Date endDate, Integer companyId, Pageable pageable)throws HelthwellExceptionHandler;

	List<WalletTransactionDto> showAllTransactionReport(Integer companyType)throws HelthwellExceptionHandler;

	Map<String, Object> showRechargeHistory(Integer companyId, Pageable pageable)throws HelthwellExceptionHandler;

	Map<String, Object> showReportByServiceId(Integer serviceId, Integer companyId, Pageable pageable)throws HelthwellExceptionHandler;
	

	Map<String, Object> getLiveReport(Date startDate, Date endDate, Integer companyId, Pageable pageable)throws HelthwellExceptionHandler;

	Map<String, Object> showMoneyTransferHistory(Integer companyId, Pageable pageable)throws HelthwellExceptionHandler;

	Map<String, Object> showMoneyTransferHistoryByDate(Integer companyId, Date startDate, Date endDate, Pageable pageable)throws HelthwellExceptionHandler;

	List<ServiceResponseDto> showAllReportByServiceId(Integer serviceId, Integer companyId)throws HelthwellExceptionHandler;

	List<LiveTransactionReportDto> getAllLiveReport(Integer companyId)throws HelthwellExceptionHandler;

	List<MoneyTransferResponseDto> showAllMoneyTransferHistory(Integer companyId)throws HelthwellExceptionHandler;

	 DashbordDto getDashbordData(Integer companyId)throws HelthwellExceptionHandler;



}
