package com.bcoss.mtrans.logic;

import com.bcoss.mtrans.dto.ServiceResponseDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface RechargeLogic {

	ServiceResponseDto recharge(ServiceResponseDto serviceResponseDto)throws HelthwellExceptionHandler;
	
	ServiceResponseDto getBill(ServiceResponseDto serviceResponseDto)throws HelthwellExceptionHandler;

	Boolean postpaidRecharge(ServiceResponseDto serviceResponseDto)throws HelthwellExceptionHandler;


}
