package com.bcoss.mtrans.logic;

import java.util.List;

import com.bcoss.mtrans.EmployeeDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface EmployeeLogic {

	List<EmployeeDto> getAllEmployee(Integer companyId)throws HelthwellExceptionHandler;

	EmployeeDto getEmployeeById(Integer employeeId)throws HelthwellExceptionHandler;

	Boolean saveEmployee(EmployeeDto employeeDto)throws HelthwellExceptionHandler;

	Boolean deleteEmployee(Integer employeeId)throws HelthwellExceptionHandler;

}
