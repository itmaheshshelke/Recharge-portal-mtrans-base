package com.bcoss.mtrans.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.bcoss.mtrans.CompanyDetailsDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.logic.CompanyLogic;

@Service
public class CompanyDetailsServiceManagerImpl implements CompanyDetailsServiceManager {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(CompanyDetailsServiceManagerImpl.class);
	@Autowired
	private CompanyLogic companyLogic;

	@Override
	public List<CompanyDetailsDto> getAllCompanyDetails(Integer companyId) throws HelthwellExceptionHandler {
		List<CompanyDetailsDto> companyDetailsDtoList = null;
		try {
			companyDetailsDtoList= companyLogic.getAllCompanyDetails(companyId);
			
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > getAllCompanyDetails", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > getAllCompanyDetails", ee);
		}
		return companyDetailsDtoList;

	}

	@Override
	public CompanyDetailsDto getCompanyDetailsById(int id) throws HelthwellExceptionHandler {
		try {
			CompanyDetailsDto companyDetailsDto = companyLogic.getCompanyDetailsById(id);
				return companyDetailsDto;
			
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > getCompanyDetailsById", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > getCompanyDetailsById", ee);
		}
		return null;
	}

	@Override
	public Boolean addCompanyDetails(CompanyDetailsDto companyDetailsDto) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {
			result= companyLogic.addCompanyDetails(companyDetailsDto);
			return result;
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > addCompanyDetails", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > addCompanyDetails", ee);
		}
		return result;
	}

	@Override
	public Boolean updateCompanyDetails(CompanyDetailsDto companyDetailsDto) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {

			result=companyLogic.updateCompanyDetails(companyDetailsDto);
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > updateCompanyDetails", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > updateCompanyDetails", ee);
		}
		return result;
	}

	@Override
	public boolean deleteCompanyDetails(int id) throws HelthwellExceptionHandler {
		try {
			companyLogic.deleteCompanyDetails(id);
			return true;
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > deleteCompanyDetails", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > deleteCompanyDetails", ee);
		}
		return false;
	}

	@Override
	public Object searchCompanyDetails(Integer companyId, String qString) throws HelthwellExceptionHandler {
		List<CompanyDetailsDto> companyDetailsDtoList = null;
		try {
			companyDetailsDtoList= companyLogic.searchCompanyDetails(companyId,qString);
			
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > searchCompanyDetails", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > searchCompanyDetails", ee);
		}
		return companyDetailsDtoList;
	}

	@Override
	public Map<String, Object> getAllDistributors(Pageable pageable,Integer companyId,String searchTerm) throws HelthwellExceptionHandler {
		try {
			return companyLogic.getAllDistributors(pageable,companyId,searchTerm);
			
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > getAllDistributors", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > getAllDistributors", ee);
		}
		return null;
	}
	@Override
	public Map<String, Object> getAllRetailers(Integer distributorId,Pageable pageable,String searchTerm) throws HelthwellExceptionHandler {
		try {
			return companyLogic.getAllRetailers(distributorId,pageable,searchTerm);
			
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > getAllRetailers", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > getAllRetailers", ee);
		}
		return null;
		
	}

	@Override
	public Boolean isMobileNoExits(String mobileNo) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {
			result= companyLogic.isMobileNoExits(mobileNo);
			return result;
		} catch (HelthwellExceptionHandler e) {
			e.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > isMobileNoExits", e);
		} catch (Exception ee) {
			ee.getStackTrace();
			logger.error("Error in CompanyDetailsServiceImpl- > isMobileNoExits", ee);
		}
		return result;
	}

}
