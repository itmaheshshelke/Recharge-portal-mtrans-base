package com.bcoss.mtrans.service;

import java.util.List;

import com.bcoss.mtrans.dto.ServiceOperatorsDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface ServiceOpertaorsServiceManager {
	List<ServiceOperatorsDto> getAllServiceOperators() throws HelthwellExceptionHandler;

	ServiceOperatorsDto getServiceOperatorsById(Integer serviceId) throws HelthwellExceptionHandler;

	Boolean saveServiceOperators(ServiceOperatorsDto serviceOperatorsDto) throws HelthwellExceptionHandler;

	Boolean deleteServiceOperators(Integer serviceId) throws HelthwellExceptionHandler;

	List<ServiceOperatorsDto> getOperatorByServiceId(Integer serviceId)throws HelthwellExceptionHandler;
}
