package com.bcoss.mtrans.service;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.bcoss.mtrans.dao.EmailDao;
import com.bcoss.mtrans.email.EmailMessage;
import com.bcoss.mtrans.email.MessageAttributes;
import com.bcoss.mtrans.email.MessageDto;
import com.bcoss.mtrans.jpa.sms.EmailSetting;
import com.bcoss.mtrans.logic.EmailLogic;
@Component
@Transactional
public class EmailServiceImpl implements EmailService {

	Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

	@Autowired
	private  EmailLogic emailLogic;
	
	@Autowired
	private EmailDao emailDao;

	@Async
	@Override
	public Boolean send(MessageDto message1) {
		Boolean result = false;
		
		try {
			
			EmailSetting emailSetting=emailDao.getEmailSettingById(message1.getClientId());
			if(emailSetting!=null) {
			// email logic part
			// welcome message for clinic (customer)
			EmailMessage message = new EmailMessage();
			message.setCustomerEmail(emailSetting.getEmailId());
			message.setSubject(message1.getSubject());
			message.setTemplateName("customer_enquiry_email.html");
			message.setRetryCount(1);

			MessageAttributes[] attributes = new MessageAttributes[5];
			MessageAttributes messageAttributes = new MessageAttributes();
			messageAttributes.setId("###1");
			messageAttributes.setValue(emailSetting.getCompanyName());
			attributes[0] = messageAttributes;

			messageAttributes = new MessageAttributes();
			messageAttributes.setId("###2");
			messageAttributes.setValue(message1.getSubject());
			attributes[1] = messageAttributes;

			messageAttributes = new MessageAttributes();
			messageAttributes.setId("###3");
			messageAttributes.setValue(message1.getName());
			attributes[2] = messageAttributes;
			
			messageAttributes = new MessageAttributes();
			messageAttributes.setId("###4");
			messageAttributes.setValue(message1.getContactNo());
			attributes[3] = messageAttributes;
			
			messageAttributes = new MessageAttributes();
			messageAttributes.setId("###5");
			messageAttributes.setValue(message1.getBody());
			attributes[4] = messageAttributes;
			
			
			message.setMessageAttributes(attributes);
			// in case of admin use this constructor to build email settings
		
			emailLogic.send(message,emailSetting);
			result=true;
			}
			} catch (Exception e) {
			logger.error("Exception Error in EmailServiceImpl - > sendEmail ", e);
			
		}
		 return result;
	}

}
