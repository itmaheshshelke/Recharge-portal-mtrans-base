package com.bcoss.mtrans.logic;

import java.util.List;

import com.bcoss.mtrans.dto.CompanyMargineDto;
import com.bcoss.mtrans.dto.MargineDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface CompanyMargineLogic {
	List<CompanyMargineDto> getAllCompanyMargine(Integer planId) throws HelthwellExceptionHandler;

	CompanyMargineDto getCompanyMargineById(Integer companyMargineId) throws HelthwellExceptionHandler;

	Boolean saveCompanyMargine(CompanyMargineDto companyMargineDto) throws HelthwellExceptionHandler;

	List<CompanyMargineDto> getMarginByPlanId(Integer planId)throws HelthwellExceptionHandler;

	List<CompanyMargineDto> getAllCompanyMargineBycompanyId(Integer companyId)throws HelthwellExceptionHandler;

	List<CompanyMargineDto> getAllCompanyMargineByMargineType(Integer margineType, Integer companyId, Integer serviceId)throws HelthwellExceptionHandler;

	List<MargineDto> getMargineData(Integer margineType, Integer serviceId)throws HelthwellExceptionHandler;

	CompanyMargineDto getCompanyMargineByCompanyAndOperatorId(Integer companyId, Integer operatorId)throws HelthwellExceptionHandler;
}
