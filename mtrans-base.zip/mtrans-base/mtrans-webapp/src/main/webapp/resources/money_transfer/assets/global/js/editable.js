     $(document).ready(function(){
      var i=1;
     $("#add_row").click(function(){
      $('#addr'+i).html("<td>"+ (i+1) +"</td>"
	  +"<td><input name='medicine"+i+"' type='text' placeholder='Medicine' class='form-control input-md'  /> </td>"
	  +"<td><input  name='dose"+i+"' type='text' placeholder='Does'  class='form-control input-md'></td>"
	  +"<td><select name='timing"+i+"'  class='form-control input-md' ><option>Timing</option><option>Morning</option><option>After Noon</option><option>Night</option></select></td>"
	  +"<td><input  name='days"+i+"' type='text' placeholder='Days' class='form-control input-md'></td>"
	  +"<td><input  name='qty"+i+"' type='text' placeholder='Qty' class='form-control input-md '></td>"
	  +"<td><input  name='amount"+i+"' type='text' placeholder='Amount'   class='form-control input-md'></td>");

      $('#tab_logic').append('<tr id="addr'+(i+1)+'"></tr>');
      i++; 
  });
     $("#delete_row").click(function(){
    	 if(i>1){
		 $("#addr"+(i-1)).html('');
		 i--;
		 }
	 });

	 $(".number").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
});