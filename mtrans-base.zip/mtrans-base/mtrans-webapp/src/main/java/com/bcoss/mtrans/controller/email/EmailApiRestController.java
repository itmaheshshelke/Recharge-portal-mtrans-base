package com.bcoss.mtrans.controller.email;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bcoss.mtrans.controller.BaseController;
import com.bcoss.mtrans.email.MessageDto;
import com.bcoss.mtrans.service.EmailService;

@RestController
@RequestMapping("/email-controller")
public class EmailApiRestController extends BaseController{

	Logger logger = LoggerFactory.getLogger(EmailApiRestController.class);
	
	@Autowired
	private EmailService emailService;
	
	@RequestMapping(value="/send-email",method = RequestMethod.POST)
	public void sendEmail(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute MessageDto message ) {
		boolean result=false;
		try {
			result=emailService.send(message);
		
			response.sendRedirect("https://rksstechnologies.com/registration.html?result="+result);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}
}
