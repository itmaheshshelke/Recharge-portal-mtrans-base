package com.bcoss.mtrans.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bcoss.mtrans.DistrictDto;
import com.bcoss.mtrans.StateDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.service.StateServiceManager;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@Controller
@RequestMapping("/state")
public class StateController extends BaseController{

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(StateController.class);

	@Autowired
	StateServiceManager stateServiceManager;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView getAllState(HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<StateDto> stateDtoList = new ArrayList<StateDto>();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			stateDtoList = stateServiceManager.getAllState();

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in StateController: getAllState", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In StateController getAllState Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("stateDtoList", stateDtoList);
		model.setViewName("state");
		model = super.getCommonSessionData(flowData, model);
		return model;

	}

	
	@RequestMapping(value = "/{stateId}", method = RequestMethod.GET)
	public ModelAndView getStateById(@PathVariable("stateId") Integer stateId,HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		StateDto stateDto = new StateDto();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			stateDto = stateServiceManager.getStateById(stateId);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in StateController: getStateById", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In StateController getStateById Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("stateDto", stateDto);
		model.setViewName("addstate");
		model = super.getCommonSessionData(flowData, model);
		return model;
	}

	

	@RequestMapping(value = "/getAllDistrict", method = RequestMethod.GET)
	public ModelAndView getAllDistrict(HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<DistrictDto> districtDtoList = new ArrayList<DistrictDto>();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			Integer stateId = 1;
			districtDtoList = stateServiceManager.getAllDistrict(stateId);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in StateController: getAllDistrict", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In StateController getAllDistrict Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("districtDtoList", districtDtoList);
		model.setViewName("state");
		model = super.getCommonSessionData(flowData, model);
		
		return model;
	}

}
