package com.bcoss.mtrans.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.bcoss.mtrans.CompanyDetailsDto;
import com.bcoss.mtrans.DistrictDto;
import com.bcoss.mtrans.StateDto;
import com.bcoss.mtrans.dto.PlansDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.service.CompanyDetailsServiceManager;
import com.bcoss.mtrans.service.PlansServiceManager;
import com.bcoss.mtrans.service.StateServiceManager;
import com.bcoss.mtrans.util.CalendarUtil;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@RestController
@RequestMapping("company")
public class CompanyController extends BaseController {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(RestController.class);

	@Autowired
	private CompanyDetailsServiceManager companyServiceManager;

	@Autowired
	private PlansServiceManager plansServiceManager;

	@Autowired
	StateServiceManager stateServiceManager;

	@GetMapping("/")
	public ModelAndView getAllCompanyDetails(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		model.setViewName("get-all-company-details");
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);
			Integer companyId =Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			model.addObject("companyDetailsList", companyServiceManager.getAllCompanyDetails(companyId));
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in CompanyController: AddCompany", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In CompanyController AddCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		return model;
	}

	@GetMapping(value = "/add-company-details")
	public ModelAndView companyRegister(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		List<PlansDto> plansDtoList = new ArrayList<PlansDto>();
		/*List<DistrictDto> districtDtoList = new ArrayList<DistrictDto>();*/
		List<StateDto> stateDtoList = new ArrayList<StateDto>();
		CompanyDetailsDto companyDetailsDto = null;
		try {
			model = super.getCommonSessionData(flowData, model);
			Integer companyId =Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			companyDetailsDto = companyServiceManager.getCompanyDetailsById(companyId);
			stateDtoList = stateServiceManager.getAllState();
			/*districtDtoList = stateServiceManager.getAllDistrict(companyDetailsDto.getStateId());*/
			plansDtoList = plansServiceManager.getAllPlans();

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in CompanyController: companyRegister", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In CompanyController companyRegister Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}

		model.setViewName("add-company-details");
		
		model.addObject("companyDetailsDto", new CompanyDetailsDto());
		model.addObject("stateDtoList", stateDtoList);
		/*model.addObject("districtDtoList", districtDtoList);*/
		model.addObject("plansDtoList", plansDtoList);
		model.addObject("companyType", companyDetailsDto.getCompanyType());

		return model;
	}

	@GetMapping("/edit-company/{companyId}")
	public ModelAndView editCompany(HttpServletRequest request, HttpServletResponse response,@PathVariable(value = "companyId") Integer companyId) {
		ModelAndView model = new ModelAndView();
		List<PlansDto> plansDtoList = new ArrayList<PlansDto>();
		List<DistrictDto> districtDtoList = new ArrayList<DistrictDto>();
		List<StateDto> stateDtoList = new ArrayList<StateDto>();
		CompanyDetailsDto companyDetailsDto = null;
		CompanyDetailsDto parentCompanyDetailsDto = null;
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);
			Integer parentCompanyId =Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			parentCompanyDetailsDto = companyServiceManager.getCompanyDetailsById(parentCompanyId);
			companyDetailsDto = companyServiceManager.getCompanyDetailsById(companyId);
			stateDtoList = stateServiceManager.getAllState();
			districtDtoList = stateServiceManager.getAllDistrict(companyDetailsDto.getStateId());
			plansDtoList = plansServiceManager.getAllPlans();

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in CompanyController: editCompany", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In CompanyController editCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("stateDtoList", stateDtoList);
		model.addObject("districtDtoList", districtDtoList);
		model.addObject("plansDtoList", plansDtoList);
		model.addObject("companyDetailsDto", companyDetailsDto);
		model.addObject("companyType", parentCompanyDetailsDto.getCompanyType());
		
		model.setViewName("add-company-details");

		return model;
	}

	@GetMapping("/deleteCompany/{companyId}")
	public ModelAndView deleteCompany(HttpServletRequest request, HttpServletResponse response,@PathVariable(value = "companyId") Integer companyId) {
		ModelAndView model = new ModelAndView();
		model.setViewName("get-all-company-details");
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		model = super.getCommonSessionData(flowData, model);
		try {

			Boolean result = companyServiceManager.deleteCompanyDetails(companyId);
			model.addObject("successmsg", "Delete company Details successfully");
			Integer company_id =Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			model.addObject("companyDetailsList", companyServiceManager.getAllCompanyDetails(company_id));

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in CompanyController: deleteCompany", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In CompanyController deleteCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		return model;
	}

	@PostMapping("/save-company-details")
	public ModelAndView saveCompany(@ModelAttribute("companyDetailsDto") CompanyDetailsDto companyDetailsDto,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		model.setViewName("get-all-company-details");
		Boolean result = false;

		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		model = super.getCommonSessionData(flowData, model);
		try {
			Integer companyId=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			
			if (companyDetailsDto.getCompanyId() == null) {
				companyDetailsDto.setCreatedBy(companyId);
				companyDetailsDto.setCreatedOn(CalendarUtil.getISTDate());
				companyDetailsDto.setParentId(companyId);
				result = companyServiceManager.addCompanyDetails(companyDetailsDto);
				model.addObject("successmsg", "save company Details successfully");

			} else {
				companyDetailsDto.setUpdatedBy(companyId);
				companyDetailsDto.setUpdatedOn(CalendarUtil.getISTDate());
				result = companyServiceManager.updateCompanyDetails(companyDetailsDto);
				model.addObject("successmsg", "Update company Details successfully");

			}
			model.addObject("companyDetailsList", companyServiceManager.getAllCompanyDetails(companyId));

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in CompanyController: saveCompany", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In CompanyController saveCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		return model;
	}
	
	
	@GetMapping(value="/getDistrictByStateId/{stateId}")
	public List<DistrictDto> getAllDistrict(HttpServletRequest request, HttpServletResponse response,
			@PathVariable Integer stateId) {
		
		List<DistrictDto> districtDtoList = new ArrayList<DistrictDto>();
		try {
			districtDtoList = stateServiceManager.getAllDistrict(stateId);
			
			return districtDtoList;
		} catch (Exception e) {
			logger.error("Exception In HomeController getAllDistrict  --", e);
		}
		return null;

	}
	
	@GetMapping("/searchCompanyDetails/{qString}")
	public ModelAndView searchCompanyDetails(HttpServletRequest request, HttpServletResponse response,
			@PathVariable(value = "qString") String qString) {
		ModelAndView model = new ModelAndView();
		model.setViewName("get-all-company-details");
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);
			Integer companyId =Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			model.addObject("companyDetailsList", companyServiceManager.searchCompanyDetails(companyId,qString));
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in CompanyController: searchCompanyDetails", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In CompanyController searchCompanyDetails Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		return model;
	}

	

	@GetMapping("/isMobileNoExits/{mobileNo}")
	public Boolean isMobileNoExits(HttpServletRequest request, HttpServletResponse response,
			@PathVariable("mobileNo") String mobileNo) {
		Boolean result = false;
		try {
			
			result = companyServiceManager.isMobileNoExits(mobileNo);
		} catch (Exception e) {
			logger.error("Exception In CompanyController isMobileNoExits  --", e);
		}
		
		return result;

	}
	
}
