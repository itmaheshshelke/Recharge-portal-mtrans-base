package com.bcoss.mtrans;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

public class LogInterceptor extends HandlerInterceptorAdapter {

	Logger logger = LoggerFactory.getLogger(LogInterceptor.class);

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		long startTime = System.currentTimeMillis();

		request.setAttribute("startTime", startTime);
		System.out.println("Request URL"+request.getRequestURI());
		if (request.getRequestURI().equals(WebAppConstants.APP_NAME + "/")
				|| request.getRequestURI().equals(WebAppConstants.APP_NAME + "/dashboard")
				|| request.getRequestURI().equals(WebAppConstants.APP_NAME + "/error")
				|| request.getRequestURI().equals(WebAppConstants.APP_NAME + "/pan-card/get-category-by-application-type-id")
				|| request.getRequestURI().equals(WebAppConstants.APP_NAME + "/payment")
				|| request.getRequestURI().contains(WebAppConstants.APP_NAME + "/report")
				|| request.getRequestURI().equals(WebAppConstants.APP_NAME + "/redirect-to-payment")
				|| request.getRequestURI().equals(WebAppConstants.APP_NAME + "/success-payment-transaction")
				|| request.getRequestURI().equals(WebAppConstants.APP_NAME + "/failed-payment-transaction")
				|| request.getRequestURI().contains(WebAppConstants.APP_NAME + "/")
				|| request.getRequestURI().contains(WebAppConstants.APP_NAME + "/email-controller")) {
			return true;
		}

		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (null == flowData || !flowData.isLoggedIn()) {
			response.sendRedirect("/");
			return false;
		}
		return true;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		// no need any code in posthandler as of now
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, //
			Object handler, Exception ex) throws Exception {

		long startTime = (Long) request.getAttribute("startTime");
		long endTime = System.currentTimeMillis();

		logger.info("Total Time Taken by url  (" + request.getRequestURI() + ") is : " + (endTime - startTime));
	}

	public ModelAndView loginPage(FlowData flowData, HttpServletRequest request) {
		Map<String, Object> resDtoObjects = new HashMap<String, Object>();
		logger.info("started loginPage method ");
		ModelAndView modelRoot = null;
		try {
			String viewName = "";
			viewName = (String) resDtoObjects.get(WebAppConstants.VIEW_NAME);
			modelRoot = new ModelAndView(viewName);
			modelRoot.addAllObjects(resDtoObjects);
			request.getSession().setAttribute(WebAppConstants.FLOWDATA, null);
			return modelRoot;
		} catch (Exception ex) {
			logger.error("Exception in loginPage()", ex);
			modelRoot = new ModelAndView((String) resDtoObjects.get(WebAppConstants.VIEW_NAME));

			return modelRoot;
		}
	}

}
