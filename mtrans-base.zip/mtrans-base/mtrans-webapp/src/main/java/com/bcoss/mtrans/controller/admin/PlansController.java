package com.bcoss.mtrans.controller.admin;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.bcoss.mtrans.controller.BaseController;
import com.bcoss.mtrans.dto.PlansDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.service.PlansServiceManager;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@RestController
@RequestMapping("/plans")
public class PlansController extends BaseController {
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(PlansController.class);

	@Autowired
	private PlansServiceManager plansServiceManager;

	@GetMapping(value = "/")
	public ModelAndView getAllPlans(HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<PlansDto> plansDtoList = new ArrayList<PlansDto>();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		try {
			model = super.getCommonSessionData(flowData, model);
			plansDtoList = plansServiceManager.getAllPlans();

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in PlansController: getAllPlans", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In PlansController getAllPlans Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("plansDtoList", plansDtoList);
		model.setViewName("plans");
		return model;
	}
	
	@GetMapping(value = "/addPlans")
	public ModelAndView addPlans(HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		model = super.getCommonSessionData(flowData, model);
		PlansDto plansDto = new PlansDto();
		model.addObject("plansDto", plansDto);
		model.setViewName("addPlans");
		return model;
	}
	
	@GetMapping(value = "/{plansId}")
	public ModelAndView getPlansById(@PathVariable("plansId") Integer plansId, HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		PlansDto plansDto = new PlansDto();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		try {
			
			model = super.getCommonSessionData(flowData, model);
			plansDto = plansServiceManager.getPlansById(plansId);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in PlansController: getPlansById", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In PlansController getPlansById Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("plansDto", plansDto);
		model.setViewName("addPlans");
		return model;
	}


}
