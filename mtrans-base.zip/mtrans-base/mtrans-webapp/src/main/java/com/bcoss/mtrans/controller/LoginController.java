package com.bcoss.mtrans.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.bcoss.mtrans.ChangePasswordDto;
import com.bcoss.mtrans.EmployeeDto;
import com.bcoss.mtrans.JavaIntegrationKit;
import com.bcoss.mtrans.dto.CompanyMargineDto;
import com.bcoss.mtrans.dto.PaymentDto;
import com.bcoss.mtrans.dto.PlansDto;
import com.bcoss.mtrans.dto.ServicesDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.rest.MoneyTransferRestClient;
import com.bcoss.mtrans.service.LoginServiceManager;
import com.bcoss.mtrans.service.PaymentServiceManager;
import com.bcoss.mtrans.service.PlansServiceManager;
import com.bcoss.mtrans.service.ServicesServiceManager;
import com.bcoss.mtrans.util.CalendarUtil;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@RestController
@RequestMapping(value = "/")
public class LoginController extends BaseController{
	
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(LoginController.class);

	@Autowired
	private LoginServiceManager loginServiceManager;
	
	@Autowired
	private PlansServiceManager plansServiceManager;
	
	@Autowired
	private ServicesServiceManager servicesServiceManager;
	
	@Autowired
	private PaymentServiceManager paymentServiceImpl;
	
	@Value("${mtrans.email.email}")
	private String emailId;

	@Value("${mtrans.email.password}")
	private String password;

	@Value("${mtrans.email.host}")
	private String host;

	@Value("${mtrans.email.port}")
	private String port;
	
	@Value("${mtrans.email.template}")
	private String templatePath;
	
	@Autowired
	private MoneyTransferRestClient moneyTransferRestClient;
	
	
	
	@Value("${mtrans.payumoney.salt}")
	private String salt;
	
	@Value("${mtrans.payumoney.key}")
	private String key;
	
	@Value("${mtrans.payumoney.url}")
	private String url;
	
	
	@GetMapping(value = "/")
	public ModelAndView login(HttpServletRequest request,
			HttpServletResponse response) {
		FlowData flowData = null;
		logger.info(LoginController.class.getName() + ".inside login controller START");  
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		//if (!flowData.isLoggedIn()) {
			return super.loginPage(flowData, request);
		/*} else {
			return getPostLoginDtls(flowData, request);
		}*/
	}
	

	
	@RequestMapping(value = "/dashboard", method = RequestMethod.POST)
	public ModelAndView dashboard(@ModelAttribute("employeeDto") EmployeeDto employeeDto, HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		/*if (flowData.isLoggedIn()) {
			return getPostLoginDtls(flowData, request);
		}*/
		
		List<PlansDto> plansDtoList=new ArrayList<PlansDto>();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		try {
			
			employeeDto = loginServiceManager.login(employeeDto, flowData);
			marginDto.setPlanId(Integer.parseInt(flowData.getSessionData(WebAppConstants.PLANID)));
			mv.setViewName("dashboard");
			mv = super.getCommonSessionData(flowData, mv);
			servicesDtoList = servicesServiceManager.getAllServices(marginDto.getPlanId());
			plansDtoList=plansServiceManager.getAllPlans();
			
			flowData.setSessionDataObject(WebAppConstants.MARGINE, marginDto);
			flowData.setSessionDataObject(WebAppConstants.SERVICE_LIST, servicesDtoList);
			flowData.setSessionDataObject(WebAppConstants.PLAN_LIST, plansDtoList);
			
			
			mv = super.getCommonSessionData(flowData, mv);
			
			mv.setViewName("dashboard");
			mv.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
			mv.addObject("employeeDto", flowData.getSessionDataObject(WebAppConstants.EMPLOYEE));
			mv.addObject("marginDto", flowData.getSessionDataObject(WebAppConstants.MARGINE));
			mv.addObject("plansDtoList", flowData.getSessionDataObject(WebAppConstants.PLAN_LIST));
			mv.addObject("servicesDtoList", flowData.getSessionDataObject(WebAppConstants.SERVICE_LIST));
			
		} catch (HelthwellExceptionHandler e) {
			logger.error("Error in LoginController- > dashboard", e);
			mv.addObject("massage", "Please enter valid username or password");
			mv.setViewName("login");
		} catch (Exception e) {
			logger.error("Error in EmployeeController- > dashboard", e);
			mv.addObject("massage", "Please enter valid username or password");
			mv.setViewName("login");
		}
		flowData.setSessionData(WebAppConstants.ISLOGEDIN, "true");
		mv = super.getCommonSessionData(flowData, mv);
		
		return mv;
	}
	
	public ModelAndView getPostLoginDtls(FlowData flowData, HttpServletRequest request) {
		logger.info("LoginController:getPostLoginDtls start");
		ModelAndView mv = new ModelAndView();
		String viewName = "";
		try {
			viewName = "dashboard";
			mv = new ModelAndView(viewName);
			mv = super.getCommonSessionData(flowData, mv);
			if (mv == null) {
				return super.loginPage(flowData, request);
			}
			flowData.setSessionData(WebAppConstants.ISLOGEDIN, "true");
			return mv;
		} catch (Exception e) {
			logger.error("Exception in LoginController:getPostLoginDtls", e);
		}
		logger.info(LoginController.class.getName() + ".inside user login controller END");
		return mv;
	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView("login");
		HttpSession session = request.getSession();
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			session.removeAttribute(WebAppConstants.FLOWDATA);
			session.invalidate();
		} catch (Exception e) {
			logger.error("Exception in LoginController:logout--->", e);
		}

		return mv;
	}

	@RequestMapping(value = "/redirect-to-payment", method = RequestMethod.POST)
	public ModelAndView payment(HttpServletRequest request, HttpServletResponse response) throws Exception {
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		ModelAndView mv = new ModelAndView("");

		HashMap<String, Object> reqDtoObjects = new HashMap<String, Object>();
		Map<String, Object> resDtoObjects = new HashMap<String, Object>();

		logger.info("PaymentController: payment Method Start.");
		request.setAttribute("salt", salt);
		request.setAttribute("key", key);
		request.setAttribute("url", url);

		JavaIntegrationKit integrationKit = new JavaIntegrationKit();
		Map<String, String> values = integrationKit.hashCalMethod(request, response);
		PrintWriter writer = response.getWriter();

		try {

			// build HTML code
			String htmlResponse = "<html> <body> \n" + "      \n" + "  \n" + "  \n" + "  \n" + "<div>"
					+ "        <form id=\"payuform\" action=\"" + values.get("action")
					+ "\"  name=\"payuform\" method=POST >\n" + "      <input type=\"hidden\" name=\"key\" value="
					+ values.get("key").trim() + ">" + "      <input type=\"hidden\" name=\"hash\" value="
					+ values.get("hash").trim() + ">" + "      <input type=\"hidden\" name=\"txnid\" value="
					+ values.get("txnid").trim() + ">" + "      "
					+ "          <td><input type=\"hidden\" name=\"amount\" value=" + values.get("amount").trim()
					+ " /></td>\n" + "         "
					+ "          <td><input type=\"hidden\" name=\"firstname\" id=\"firstname\" value="
					+ values.get("firstname").trim() + " /></td>\n" + "        <tr>\n" + "         "
					+ "          <td><input type=\"hidden\" name=\"email\" id=\"email\" value="
					+ values.get("email").trim() + " /></td>\n" + "         "
					+ "          <td><input type=\"hidden\"  name=\"phone\" value=" + values.get("phone") + " ></td>\n"
					+ "        </tr>\n" + "        <tr>\n" + "         " + "<td><input name=\"productinfo\" value="
					+ values.get("productinfo").trim() + " type=\"hidden\"></td>\n" + "        </tr>\n"
					+ "        <tr>\n"
					+ "          <td align=\\\"center\\\"><h3>Your Request Is Processing..... </h3></td>\n"
					+ "          <td colspan=\"3\"><input type=\"hidden\" name=\"surl\"  size=\"64\" value="
					+ values.get("surl") + "></td>\n" + "        </tr>\n" + "        <tr>\n" + "         "
					+ "          <td colspan=\"3\"><input type=\"hidden\" name=\"furl\" value=" + values.get("furl")
					+ " size=\"64\" ></td>\n" + "        </tr>\n" + "\n" + "        <tr>\n"
					+ "          <td colspan=\"3\"><input type=\"hidden\" name=\"service_provider\" value=\"payu_paisa\" /></td>\n"
					+ "        </tr>\n" + "        <td colspan=\"4\"><input type=\"submit\" value=\"Submit\"  /></td>\n"
					+ "      \n" + "    \n" + "      </table>\n" + "    </form>\n" + " <script> "
					+ " document.getElementById(\"payuform\").submit(); " + " </script> " + "       </div>   " + "  \n"
					+ "  </body>\n" + "</html>";
			// return response
			writer.println(htmlResponse);

		} catch (Exception e) {
			logger.error("Exception In PaymentController  --", e);
		}
		return null;

	}

	@RequestMapping(value = "/payment", method = RequestMethod.GET)
	public ModelAndView addPayment(HttpServletRequest request, HttpServletResponse response)
			throws HelthwellExceptionHandler {
		ModelAndView model =new ModelAndView();
		model.setViewName("payment");
		return model;
	}
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/success-payment-transaction", method = RequestMethod.POST)
	public ModelAndView SuccessPayment(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("PaymentController: SuccessPayment Method Start.");
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		ModelAndView mv = new ModelAndView("success_payment");
		HashMap<String, Object> reqDtoObjects = new HashMap<String, Object>();
		Map<String, Object> resDtoObjects = new HashMap<String, Object>();
		Boolean result = false;

		PaymentDto paymentDto = new PaymentDto();
		try {
			paymentDto.setFirstname(request.getParameter("firstname"));
			paymentDto.setEmail(request.getParameter("email"));
			paymentDto.setPhone(request.getParameter("phone"));
			paymentDto.setPayuMoneyId(request.getParameter("payuMoneyId"));
			paymentDto.setTxnid(request.getParameter("txnid"));
			paymentDto.setAmount(Float.parseFloat(request.getParameter("amount")));
			paymentDto.setStatus(request.getParameter("status"));
			paymentDto.setHash(request.getParameter("hash"));

			paymentDto.setProductInfo(request.getParameter("productinfo"));
			paymentDto.setMode(request.getParameter("mode"));
			paymentDto.setDateTime(CalendarUtil.getISTDate());
			result = paymentServiceImpl.payment(paymentDto);
		} catch (HelthwellExceptionHandler _be) {
			mv.setViewName((String) resDtoObjects.get("viewName"));
			logger.error("Exception in PaymentController: SuccessPayment", _be);
			mv.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());

		} catch (Exception e) {
			mv.setViewName((String) resDtoObjects.get("viewName"));
			logger.error("Exception In PaymentController  --", e);
		}
		mv.addObject("paymentDto", paymentDto);
		return mv;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/failed-payment-transaction", method = RequestMethod.POST)
	public ModelAndView FailedPayment(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("PaymentController: FailedPayment Method Start.");
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		ModelAndView mv = new ModelAndView("failed_payment");
		HashMap<String, Object> reqDtoObjects = new HashMap<String, Object>();
		Map<String, Object> resDtoObjects = new HashMap<String, Object>();

		Boolean result = false;
		PaymentDto paymentDto = new PaymentDto();
		try {
			paymentDto.setFirstname(request.getParameter("firstname"));
			paymentDto.setEmail(request.getParameter("email"));
			paymentDto.setPhone(request.getParameter("phone"));
			paymentDto.setPayuMoneyId(request.getParameter("payuMoneyId"));
			paymentDto.setTxnid(request.getParameter("txnid"));
			paymentDto.setAmount(Float.parseFloat(request.getParameter("amount")));
			paymentDto.setStatus(request.getParameter("status"));
			paymentDto.setHash(request.getParameter("hash"));
			paymentDto.setProductInfo(request.getParameter("productinfo"));
			paymentDto.setMode(request.getParameter("mode"));
			paymentDto.setDateTime(CalendarUtil.getISTDate());
			mv.addObject("paymentDto", paymentDto);

			result = paymentServiceImpl.payment(paymentDto);
		} catch (Exception e) {
			logger.error("Exception In PaymentController  --", e);
		}

		logger.info("PaymentController: FailedPayment Method End.");

		return mv;
	}

	
	@GetMapping("/sendOtp/{mono}")
	public  EmployeeDto sendOtp(@PathVariable("mono") String mono, HttpServletRequest request, HttpServletResponse response) {
		 EmployeeDto employeeDto = new EmployeeDto();  
		try {
			employeeDto = loginServiceManager.sendOtp(mono);
			
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in LoginController: sendOtp", _be);
		} catch (Exception e) {
			logger.error("Exception In LoginController sendOtp Method--", e);
		}
		return employeeDto;
	}
	
	
	@GetMapping("/reSendPassword/{mono}")
	public  EmployeeDto reSendPassword(@PathVariable("mono") String mono, HttpServletRequest request, HttpServletResponse response) {
		 EmployeeDto employeeDto = new EmployeeDto();  
		try {
			employeeDto = loginServiceManager.reSendPassword(mono);
			
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in LoginController: reSendPassword", _be);
		} catch (Exception e) {
			logger.error("Exception In LoginController reSendPassword Method--", e);
		}
		return employeeDto;
	}
	
	
	@RequestMapping(value = "/change-password", method = RequestMethod.GET)
	public ModelAndView changePassword(HttpServletRequest request, HttpServletResponse response)
			throws HelthwellExceptionHandler {
		ModelAndView model =new ModelAndView();
		model.setViewName("changePassword");
		model.addObject("", new ChangePasswordDto());
		return model;
	}
	
		
	
	
	@PostMapping(value = "/saveChangePassword")
	public ModelAndView saveChangePassword(@ModelAttribute("changePasswordDto") ChangePasswordDto changePasswordDto, HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		List<EmployeeDto> employeeDtoList = new ArrayList<EmployeeDto>();
		Boolean result = false;

		try {
			Integer companyId =Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			Integer employeeId = Integer.parseInt(flowData.getSessionData(WebAppConstants.EMPLOYEEID));
			
			changePasswordDto.setEmployeeId(employeeId);
			changePasswordDto.setCompanyId(companyId);
			
			result = loginServiceManager.saveChangePassword(changePasswordDto);


		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in EmployeeController: saveChangePassword", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In EmployeeController saveChangePassword Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}

		flowData.setSessionData(WebAppConstants.ISLOGEDIN, "true");
		model = super.getCommonSessionData(flowData, model);
		if (model == null) { 
			return super.loginPage(flowData, request);
		}

		if (result == true) {
			model.addObject("sucessMessage", "Change Password Succesfully");
		}else {
			model.addObject("errormsg", "old password is incorrect");
			
		}

		model.setViewName("changePassword");
		model.addObject("", new ChangePasswordDto());
		return model;
	}

	
	

}
