package com.bcoss.mtrans.controller.admin;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.bcoss.mtrans.controller.BaseController;
import com.bcoss.mtrans.dto.CompanyMargineDto;
import com.bcoss.mtrans.dto.ServiceOperatorsDto;
import com.bcoss.mtrans.dto.ServiceResponseDto;
import com.bcoss.mtrans.dto.WalletDto;
import com.bcoss.mtrans.dto.provider.response.QuickRechargeResponseDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.rest.CrowfinchRestClient;
import com.bcoss.mtrans.service.CompanyMargineServiceManager;
import com.bcoss.mtrans.service.RechargeServiceManager;
import com.bcoss.mtrans.service.ServiceOpertaorsServiceManager;
import com.bcoss.mtrans.service.WalleterviceManager;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@RestController
@RequestMapping("/recharge")
public class RechargeController extends BaseController{

	private static final Logger logger = LoggerFactory.getLogger(RechargeController.class);
		
	@Autowired
	private ServiceOpertaorsServiceManager serviceOpertaorsServiceManager;

	@Autowired
 	private WalleterviceManager walleterviceManager;
	
	@Autowired
 	private RechargeServiceManager rechargeServiceManager;
	
	@Autowired
	private CrowfinchRestClient crowfinchRestClient;
	
	@Autowired
	private CompanyMargineServiceManager companyMargineServiceManager;

	
	@GetMapping(value = "/show-recharge-page")
	public ModelAndView Recharge(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		List<ServiceOperatorsDto> serviceOperatorsDtoList = new ArrayList<ServiceOperatorsDto>();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		try {
			
			model = super.getCommonSessionData(flowData, model);
			serviceOperatorsDtoList = serviceOpertaorsServiceManager.getAllServiceOperators();
			
		} catch (HelthwellExceptionHandler _be) { 
			logger.error("Exception in RechargeController: Recharge", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In RechargeController Recharge Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("serviceOperatorsDtoList",serviceOperatorsDtoList);
		model.addObject("msrgineDto",new CompanyMargineDto());
		model.setViewName("show-recharge-page");
		return model;
	}
	
	@PostMapping(value = "/pre-paid-recharge")
	public @ResponseBody ServiceResponseDto prepaidRecharge(@RequestBody ServiceResponseDto serviceResponseDto,HttpServletRequest request,
			HttpServletResponse response) {
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		WalletDto walletDto = new WalletDto();
		try {
			
			Integer companyId=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			
			double walletBalance = 0.0;
			if (flowData.getSessionData(WebAppConstants.COMPANYTYPE).equals("1")) {
				String messageToRecharge = "BAL";
				QuickRechargeResponseDto crowFinchResponse = crowfinchRestClient.getBalance(messageToRecharge);
				if (null != crowFinchResponse.getBalance()) {
					walletBalance = Double.parseDouble(crowFinchResponse.getBalance());//crowFinchResponse.getData().getBalance();
				}else {
					walletBalance=0.0;
				}
				
			} else {
				Integer walletId=Integer.parseInt(flowData.getSessionData(WebAppConstants.WALLETID));
				walletDto = walleterviceManager.getwalletById(walletId);
				walletBalance = walletDto.getBalance();
				walletBalance=walletBalance-serviceResponseDto.getAmount();
			}
			if(!flowData.getSessionData(WebAppConstants.COMPANYTYPE).equals("1") && walletBalance<=0) {
				serviceResponseDto.setErrorCode("RKSS-001-IN");
				return serviceResponseDto;
			}
			
			if(walletBalance >= serviceResponseDto.getAmount()) {
				//serviceResponseDto.setCircleCode(Integer.parseInt(flowData.getSessionData(WebAppConstants.CIRCLECODE)));
				CompanyMargineDto companyMargineDto= companyMargineServiceManager.getCompanyMargineByCompanyAndOperatorId(companyId,serviceResponseDto.getOperatorId());
				
				Double operatorCommission = 0.0;
				if(null!=companyMargineDto && companyMargineDto.getValue()!=null) {
					operatorCommission = companyMargineDto.getValue();
				}
				
				Double commission = serviceResponseDto.getAmount() * operatorCommission/100;
				
				serviceResponseDto.setAmount(serviceResponseDto.getAmount());
				serviceResponseDto.setMargine(commission);
				if(companyMargineDto.getType().equals(1)) {
					serviceResponseDto.setFinalAmount(serviceResponseDto.getAmount()+ companyMargineDto.getValue());
				}else {
					serviceResponseDto.setFinalAmount(serviceResponseDto.getAmount()-commission);
				}
				serviceResponseDto.setMarginType(companyMargineDto.getType());
				serviceResponseDto.setCompanyId(companyId);
				serviceResponseDto.setRechargeBy(Integer.parseInt(flowData.getSessionData(WebAppConstants.EMPLOYEEID)));
				serviceResponseDto.setWalletBalance(walletBalance+serviceResponseDto.getMargine());
				serviceResponseDto =rechargeServiceManager.recharge(serviceResponseDto);
				serviceResponseDto.setWalletBalance(walletBalance);
			}else {
				serviceResponseDto.setErrorCode("RKSS-001-IN");
			}
			
		} catch (HelthwellExceptionHandler _be) { 
			logger.error("Exception in RechargeController: prepaidRecharge", _be);
			serviceResponseDto.setErrorCode("RKSS-002-IN");
		} catch (Exception e) {
			logger.error("Exception In RechargeController prepaidRecharge Method--", e);
			serviceResponseDto.setErrorCode("RKSS-002-IN");
		}
		
	return serviceResponseDto;
	}
	
	@PostMapping(value = "/post-paid-recharge")
	public @ResponseBody ServiceResponseDto postPaidRecharge(@RequestBody ServiceResponseDto serviceResponseDto,HttpServletRequest request,
			HttpServletResponse response) {
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		WalletDto walletDto = new WalletDto();
		Boolean result=false;
		try {
			Integer companyId=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			
			double walletBalance = 0.0;
			if (flowData.getSessionData(WebAppConstants.COMPANYTYPE).equals("1")) {
				String messageToRecharge = "BAL";
				QuickRechargeResponseDto crowFinchResponse = crowfinchRestClient.getBalance(messageToRecharge);
				if (null != crowFinchResponse.getBalance()) {
					walletBalance = Double.parseDouble(crowFinchResponse.getBalance());//crowFinchResponse.getData().getBalance();
				}else {
					walletBalance=0.0;
				}
				
			} else {
				Integer walletId=Integer.parseInt(flowData.getSessionData(WebAppConstants.WALLETID));
				walletDto = walleterviceManager.getwalletById(walletId);
				walletBalance = walletDto.getBalance();
				walletBalance=walletBalance-serviceResponseDto.getAmount();
			}

			if(!flowData.getSessionData(WebAppConstants.COMPANYTYPE).equals("1") && walletBalance<=0) {
				serviceResponseDto.setErrorCode("RKSS-001-IN");
				return serviceResponseDto;
			}
			if(walletBalance >= serviceResponseDto.getAmount()) {
				//serviceResponseDto.setCircleCode(Integer.parseInt(flowData.getSessionData(WebAppConstants.CIRCLECODE)));
				CompanyMargineDto companyMargineDto= companyMargineServiceManager.getCompanyMargineByCompanyAndOperatorId(companyId,serviceResponseDto.getOperatorId());
				Double operatorCommission = 0.0;
				if(null!=companyMargineDto && companyMargineDto.getValue()!=null) {
					operatorCommission = companyMargineDto.getValue();
				}
				Double commission = serviceResponseDto.getAmount() * operatorCommission/100;
				
				serviceResponseDto.setAmount(serviceResponseDto.getAmount());
				serviceResponseDto.setMargine(commission);
				if(companyMargineDto.getType().equals(1)) {
					serviceResponseDto.setFinalAmount(serviceResponseDto.getAmount()+ companyMargineDto.getValue());
				}else {
					serviceResponseDto.setFinalAmount(serviceResponseDto.getAmount()-commission);
				}
				serviceResponseDto.setMarginType(companyMargineDto.getType());
				
				serviceResponseDto.setCompanyId(companyId);
				serviceResponseDto.setRechargeBy(Integer.parseInt(flowData.getSessionData(WebAppConstants.EMPLOYEEID)));
				serviceResponseDto.setWalletBalance(walletBalance+serviceResponseDto.getMargine());
				serviceResponseDto = rechargeServiceManager.recharge(serviceResponseDto);
				serviceResponseDto.setWalletBalance(walletBalance);
			}else {
				serviceResponseDto.setErrorCode("RKSS-001-IN");
				//throw new HelthwellExceptionHandler(HelthwellServiceErrors.COMPANY_BALANCE_LOW);
			}
		} catch (HelthwellExceptionHandler _be) { 
			logger.error("Exception in RechargeController: postPaidRecharge", _be);
			serviceResponseDto.setErrorCode("RKSS-002-IN");
		} catch (Exception e) {
			logger.error("Exception In RechargeController postPaidRecharge Method--", e);
			serviceResponseDto.setErrorCode("RKSS-002-IN");
		}
	return serviceResponseDto;
	}
	
	@PostMapping(value = "/dth-recharge")
	public @ResponseBody ServiceResponseDto dthRecharge(@RequestBody ServiceResponseDto serviceResponseDto,HttpServletRequest request,
			HttpServletResponse response) {
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		WalletDto walletDto = new WalletDto();
		try {
			Integer companyId=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			
			double walletBalance = 0.0;
			if (flowData.getSessionData(WebAppConstants.COMPANYTYPE).equals("1")) {
				String messageToRecharge = "BAL";
				QuickRechargeResponseDto crowFinchResponse = crowfinchRestClient.getBalance(messageToRecharge);
				if (null != crowFinchResponse.getBalance()) {
					walletBalance = Double.parseDouble(crowFinchResponse.getBalance());//crowFinchResponse.getData().getBalance();
				}else {
					walletBalance=0.0;
				}
			} else {
				Integer walletId=Integer.parseInt(flowData.getSessionData(WebAppConstants.WALLETID));
				walletDto = walleterviceManager.getwalletById(walletId);
				walletBalance = walletDto.getBalance();
				walletBalance=walletBalance-serviceResponseDto.getAmount();
			}
			
			if(!flowData.getSessionData(WebAppConstants.COMPANYTYPE).equals("1") && walletBalance<=0) {
				serviceResponseDto.setErrorCode("RKSS-001-IN");
				return serviceResponseDto;
			}
			
			if(walletBalance >= serviceResponseDto.getAmount()) {
				//serviceResponseDto.setCircleCode(Integer.parseInt(flowData.getSessionData(WebAppConstants.CIRCLECODE)));
				
				CompanyMargineDto companyMargineDto= companyMargineServiceManager.getCompanyMargineByCompanyAndOperatorId(companyId,serviceResponseDto.getOperatorId());
				Double operatorCommission = 0.0;
				if(null!=companyMargineDto && companyMargineDto.getValue()!=null) {
					operatorCommission = companyMargineDto.getValue();
				}
				Double commission = serviceResponseDto.getAmount() * operatorCommission/100;
				
				serviceResponseDto.setAmount(serviceResponseDto.getAmount());
				serviceResponseDto.setMargine(commission);
				if(companyMargineDto.getType().equals(1)) {
					serviceResponseDto.setFinalAmount(serviceResponseDto.getAmount()+ companyMargineDto.getValue());
				}else {
					serviceResponseDto.setFinalAmount(serviceResponseDto.getAmount()-commission);
				}
				serviceResponseDto.setMarginType(companyMargineDto.getType());
				
				serviceResponseDto.setCompanyId(companyId);
				serviceResponseDto.setRechargeBy(Integer.parseInt(flowData.getSessionData(WebAppConstants.EMPLOYEEID)));
				serviceResponseDto.setWalletBalance(walletBalance+serviceResponseDto.getMargine());
				serviceResponseDto =rechargeServiceManager.recharge(serviceResponseDto);
				serviceResponseDto.setWalletBalance(walletBalance);
			}else {
				serviceResponseDto.setErrorCode("RKSS-001-IN");
			}
		} catch (HelthwellExceptionHandler _be) { 
			logger.error("Exception in RechargeController: dthRecharge", _be);
			serviceResponseDto.setErrorCode("RKSS-002-IN");
		} catch (Exception e) {
			logger.error("Exception In RechargeController dthRecharge Method--", e);
			serviceResponseDto.setErrorCode("RKSS-002-IN");
		}
	return serviceResponseDto;
	}
	
	
	
	@GetMapping(value = "/show-utility-bill-page")
	public ModelAndView UtilityBill(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		List<ServiceOperatorsDto> serviceOperatorsDtoList = new ArrayList<ServiceOperatorsDto>();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		try {
			
			model = super.getCommonSessionData(flowData, model);
			serviceOperatorsDtoList = serviceOpertaorsServiceManager.getAllServiceOperators();
			
		} catch (HelthwellExceptionHandler _be) { 
			logger.error("Exception in RechargeController: Recharge", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In RechargeController Recharge Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("serviceOperatorsDtoList",serviceOperatorsDtoList);
		model.addObject("msrgineDto",new CompanyMargineDto());
		model.setViewName("show-utility-bill-page");
		return model;
	}
	
	
	@PostMapping(value = "/get-bill")
	public @ResponseBody ServiceResponseDto getBill(@RequestBody ServiceResponseDto serviceResponseDto,HttpServletRequest request,
			HttpServletResponse response) {

		try {

			serviceResponseDto = rechargeServiceManager.getBill(serviceResponseDto);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in RechargeController: dthRecharge", _be);
			serviceResponseDto.setErrorCode("RKSS-002-IN");
		} catch (Exception e) {
			logger.error("Exception In RechargeController dthRecharge Method--", e);
			serviceResponseDto.setErrorCode("RKSS-002-IN");
		}
		return serviceResponseDto;
	}
	
	@PostMapping(value = "/land-line-recharge")
	public @ResponseBody ServiceResponseDto landlineRecharge(@RequestBody ServiceResponseDto serviceResponseDto,HttpServletRequest request,
			HttpServletResponse response) {
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		WalletDto walletDto = new WalletDto();
		try {
			Integer companyId=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			
			double walletBalance = 0.0;
			if (flowData.getSessionData(WebAppConstants.COMPANYTYPE).equals("1")) {
				String messageToRecharge = "BAL";
				QuickRechargeResponseDto crowFinchResponse = crowfinchRestClient.getBalance(messageToRecharge);
				if (null != crowFinchResponse.getBalance()) {
					walletBalance = Double.parseDouble(crowFinchResponse.getBalance());//crowFinchResponse.getData().getBalance();
				}else {
					walletBalance=0.0;
				}
				
			} else {
				Integer walletId=Integer.parseInt(flowData.getSessionData(WebAppConstants.WALLETID));
				walletDto = walleterviceManager.getwalletById(walletId);
				walletBalance = walletDto.getBalance();
				walletBalance=walletBalance-serviceResponseDto.getAmount();
			}
			
			if(!flowData.getSessionData(WebAppConstants.COMPANYTYPE).equals("1") && walletBalance<=0) {
				serviceResponseDto.setErrorCode("RKSS-001-IN");
				return serviceResponseDto;
			}
			if(walletBalance >= serviceResponseDto.getAmount()) {
				
				CompanyMargineDto companyMargineDto= companyMargineServiceManager.getCompanyMargineByCompanyAndOperatorId(companyId,serviceResponseDto.getOperatorId());
				Double operatorCommission = 0.0;
				if(null!=companyMargineDto && companyMargineDto.getValue()!=null) {
					operatorCommission = companyMargineDto.getValue();
				}
				Double commission = serviceResponseDto.getAmount() * operatorCommission/100;
				
				serviceResponseDto.setAmount(serviceResponseDto.getAmount());
				serviceResponseDto.setMargine(commission);
				if(companyMargineDto.getType().equals(1)) {
					serviceResponseDto.setFinalAmount(serviceResponseDto.getAmount()+ companyMargineDto.getValue());
				}else {
					serviceResponseDto.setFinalAmount(serviceResponseDto.getAmount()-commission);
				}
				serviceResponseDto.setMarginType(companyMargineDto.getType());
				
				serviceResponseDto.setCircleCode(Integer.parseInt(flowData.getSessionData(WebAppConstants.CIRCLECODE)));
				serviceResponseDto.setCompanyId(companyId);
				serviceResponseDto.setRechargeBy(Integer.parseInt(flowData.getSessionData(WebAppConstants.EMPLOYEEID)));
				
				serviceResponseDto.setWalletBalance(walletBalance+serviceResponseDto.getMargine());
				serviceResponseDto =rechargeServiceManager.recharge(serviceResponseDto);
				serviceResponseDto.setWalletBalance(walletBalance);
			}else {
				serviceResponseDto.setErrorCode("RKSS-001-IN");
			}
		} catch (HelthwellExceptionHandler _be) { 
			logger.error("Exception in RechargeController: dthRecharge", _be);
			serviceResponseDto.setErrorCode("RKSS-002-IN");
		} catch (Exception e) {
			logger.error("Exception In RechargeController dthRecharge Method--", e);
			serviceResponseDto.setErrorCode("RKSS-002-IN");
		}
	return serviceResponseDto;
	}
	
	@PostMapping(value = "/data-card-recharge")
	public @ResponseBody ServiceResponseDto dataCardRecharge(@RequestBody ServiceResponseDto serviceResponseDto,HttpServletRequest request,
			HttpServletResponse response) {
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		WalletDto walletDto = new WalletDto();
		ServiceResponseDto result=null;
		try {
			
			Integer companyId=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			
			double walletBalance = 0.0;
			if (flowData.getSessionData(WebAppConstants.COMPANYTYPE).equals("1")) {
				String messageToRecharge = "BAL";
				QuickRechargeResponseDto crowFinchResponse = crowfinchRestClient.getBalance(messageToRecharge);
				if (null != crowFinchResponse.getBalance()) {
					walletBalance = Double.parseDouble(crowFinchResponse.getBalance());//crowFinchResponse.getData().getBalance();
				}else {
					walletBalance=0.0;
				}
			} else {
				Integer walletId=Integer.parseInt(flowData.getSessionData(WebAppConstants.WALLETID));
				walletDto = walleterviceManager.getwalletById(walletId);
				walletBalance = walletDto.getBalance();
			}

			if(!flowData.getSessionData(WebAppConstants.COMPANYTYPE).equals("1") && walletBalance<=0) {
				serviceResponseDto.setErrorCode("RKSS-001-IN");
				return serviceResponseDto;
			}
			if(walletBalance > serviceResponseDto.getAmount()) {
				//serviceResponseDto.setCircleCode(Integer.parseInt(flowData.getSessionData(WebAppConstants.CIRCLECODE)));
				
				CompanyMargineDto companyMargineDto= companyMargineServiceManager.getCompanyMargineByCompanyAndOperatorId(companyId,serviceResponseDto.getOperatorId());
				Double operatorCommission = 0.0;
				if(null!=companyMargineDto && companyMargineDto.getValue()!=null) {
					operatorCommission = companyMargineDto.getValue();
				}
				Double commission = serviceResponseDto.getAmount() * operatorCommission/100;
				
				serviceResponseDto.setAmount(serviceResponseDto.getAmount());
				serviceResponseDto.setMargine(commission);
				if(companyMargineDto.getType().equals(1)) {
					serviceResponseDto.setFinalAmount(serviceResponseDto.getAmount()+ companyMargineDto.getValue());
				}else {
					serviceResponseDto.setFinalAmount(serviceResponseDto.getAmount()-commission);
				}
				serviceResponseDto.setMarginType(companyMargineDto.getType());
				
				serviceResponseDto.setCompanyId(companyId);
				serviceResponseDto.setRechargeBy(Integer.parseInt(flowData.getSessionData(WebAppConstants.EMPLOYEEID)));
				result=rechargeServiceManager.recharge(serviceResponseDto);
				
			}else {
				serviceResponseDto.setErrorCode("RKSS-001-IN");
				//throw new HelthwellExceptionHandler(HelthwellServiceErrors.COMPANY_BALANCE_LOW);
			}
		} catch (HelthwellExceptionHandler _be) { 
			logger.error("Exception in RechargeController: dataCardRecharge", _be);
			serviceResponseDto.setErrorCode("RKSS-002-IN");
		} catch (Exception e) {
			logger.error("Exception In RechargeController dataCardRecharge Method--", e);
			serviceResponseDto.setErrorCode("RKSS-002-IN");
		}
	return result;
	}
	
	
	@PostMapping(value = "electricity-recharge")
	public @ResponseBody ServiceResponseDto electricityBill(@RequestBody ServiceResponseDto serviceResponseDto,HttpServletRequest request,
			HttpServletResponse response) {
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		WalletDto walletDto = new WalletDto();
		try {
			Integer companyId=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			Double surcharge=5.00;
			double walletBalance = 0.0;
			if (flowData.getSessionData(WebAppConstants.COMPANYTYPE).equals("1")) {
				String messageToRecharge = "BAL";
				serviceResponseDto.setSurcharge(1.90);
				serviceResponseDto.setFinalAmount(serviceResponseDto.getAmount()+1.90);
				QuickRechargeResponseDto crowFinchResponse = crowfinchRestClient.getBalance(messageToRecharge);
				if (null != crowFinchResponse.getBalance()) {
					walletBalance = Double.parseDouble(crowFinchResponse.getBalance());//crowFinchResponse.getData().getBalance();
					serviceResponseDto.setWalletBalance(walletBalance+1.90);
				}else {
					walletBalance=0.0;
				}
				
			} else {
				Integer walletId=Integer.parseInt(flowData.getSessionData(WebAppConstants.WALLETID));
				walletDto = walleterviceManager.getwalletById(walletId);
				walletBalance = walletDto.getBalance();
				walletBalance=walletBalance-(serviceResponseDto.getAmount()+surcharge);
				serviceResponseDto.setSurcharge(surcharge);
				serviceResponseDto.setWalletBalance(walletBalance);
				serviceResponseDto.setFinalAmount(serviceResponseDto.getAmount()+surcharge);
			}
			
			if(!flowData.getSessionData(WebAppConstants.COMPANYTYPE).equals("1") && walletBalance<=0) {
				serviceResponseDto.setErrorCode("RKSS-001-IN");
				return serviceResponseDto;
			}
			if(walletBalance >= serviceResponseDto.getAmount()) {
				//serviceResponseDto.setCircleCode(Integer.parseInt(flowData.getSessionData(WebAppConstants.CIRCLECODE)));
				Double commission =  0.0;
				
				serviceResponseDto.setAmount(serviceResponseDto.getAmount());
				serviceResponseDto.setMargine(commission);
				
				
				serviceResponseDto.setCompanyId(companyId);
				serviceResponseDto.setRechargeBy(Integer.parseInt(flowData.getSessionData(WebAppConstants.EMPLOYEEID)));
				serviceResponseDto.setWalletBalance(walletBalance);
				serviceResponseDto =rechargeServiceManager.recharge(serviceResponseDto);
				
			}else {
				serviceResponseDto.setErrorCode("RKSS-001-IN");
			}
		} catch (HelthwellExceptionHandler _be) { 
			logger.error("Exception in RechargeController: electricityBill", _be);
			serviceResponseDto.setErrorCode("RKSS-002-IN");
		} catch (Exception e) {
			logger.error("Exception In RechargeController electricityBill Method--", e);
			serviceResponseDto.setErrorCode("RKSS-002-IN");
		}
	return serviceResponseDto;
	}
}
