package com.bcoss.mtrans.controller;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.bcoss.mtrans.JavaIntegrationKit;
import com.bcoss.mtrans.dto.PaymentDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.service.PaymentServiceManager;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@RestController
@RequestMapping(value ="/get-payment")
public class PaymentController extends BaseController {

	Logger logger = LoggerFactory.getLogger(PaymentController.class);

	@Autowired
	private PaymentServiceManager paymentServiceImpl;
	
	@Value("${mtrans.payumoney.salt}")
	private String salt;
	
	@Value("${mtrans.payumoney.key}")
	private String key;
	
	@Value("${mtrans.payumoney.url}")
	private String url;
	
	@RequestMapping(value = "/payment", method = RequestMethod.GET)
	public ModelAndView addPayment(HttpServletRequest request, HttpServletResponse response)
			throws HelthwellExceptionHandler {
		ModelAndView model =new ModelAndView();
		model.setViewName("payment");
		return model;
	}
	
	
	@RequestMapping(value = "/redirect-to-payment", method = RequestMethod.POST)
	public ModelAndView payment(HttpServletRequest request, HttpServletResponse response) throws Exception {
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		ModelAndView mv = new ModelAndView("");

		HashMap<String, Object> reqDtoObjects = new HashMap<String, Object>();
		Map<String, Object> resDtoObjects = new HashMap<String, Object>();

		logger.info("PaymentController: payment Method Start.");
		request.setAttribute("salt", salt);
		request.setAttribute("key", key);
		request.setAttribute("url", url);
		JavaIntegrationKit integrationKit = new JavaIntegrationKit();
		// request.setAttribute("siteId",flowData.getSessionData(WebAppConstants.SITEID));
		Map<String, String> values = integrationKit.hashCalMethod(request, response);
		PrintWriter writer = response.getWriter();

		try {

			// build HTML code
			String htmlResponse = "<html> <body> \n" + "      \n" + "  \n" + "  \n" + "  \n" + "<div>"
					+ "        <form id=\"payuform\" action=\"" + values.get("action")
					+ "\"  name=\"payuform\" method=POST >\n" + "      <input type=\"hidden\" name=\"key\" value="
					+ values.get("key").trim() + ">" + "      <input type=\"hidden\" name=\"hash\" value="
					+ values.get("hash").trim() + ">" + "      <input type=\"hidden\" name=\"txnid\" value="
					+ values.get("txnid").trim() + ">" + "      "
					+ "          <td><input type=\"hidden\" name=\"amount\" value=" + values.get("amount").trim()
					+ " /></td>\n" + "         "
					+ "          <td><input type=\"hidden\" name=\"firstname\" id=\"firstname\" value="
					+ values.get("firstname").trim() + " /></td>\n" + "        <tr>\n" + "         "
					+ "          <td><input type=\"hidden\" name=\"email\" id=\"email\" value="
					+ values.get("email").trim() + " /></td>\n" + "         "
					+ "          <td><input type=\"hidden\"  name=\"phone\" value=" + values.get("phone") + " ></td>\n"
					+ "        </tr>\n" + "        <tr>\n" + "         " + "<td><input name=\"productinfo\" value="
					+ values.get("productinfo").trim() + " type=\"hidden\"></td>\n" + "        </tr>\n"
					+ "        <tr>\n"
					+ "          <td align=\\\"center\\\"><h3>Your Request Is Processing..... </h3></td>\n"
					+ "          <td colspan=\"3\"><input type=\"hidden\" name=\"surl\"  size=\"64\" value="
					+ values.get("surl") + "></td>\n" + "        </tr>\n" + "        <tr>\n" + "         "
					+ "          <td colspan=\"3\"><input type=\"hidden\" name=\"furl\" value=" + values.get("furl")
					+ " size=\"64\" ></td>\n" + "        </tr>\n" + "\n" + "        <tr>\n"
					+ "          <td colspan=\"3\"><input type=\"hidden\" name=\"service_provider\" value=\"payu_paisa\" /></td>\n"
					+ "        </tr>\n" + "        <td colspan=\"4\"><input type=\"submit\" value=\"Submit\"  /></td>\n"
					+ "      \n" + "    \n" + "      </table>\n" + "    </form>\n" + " <script> "
					+ " document.getElementById(\"payuform\").submit(); " + " </script> " + "       </div>   " + "  \n"
					+ "  </body>\n" + "</html>";
			// return response
			writer.println(htmlResponse);

		} catch (Exception e) {
			logger.error("Exception In PaymentController  --", e);
		}
		return null;

	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/success-payment-transaction", method = RequestMethod.POST)
	public ModelAndView SuccessPayment(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("PaymentController: SuccessPayment Method Start.");
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		ModelAndView mv = new ModelAndView("success_payment");
		HashMap<String, Object> reqDtoObjects = new HashMap<String, Object>();
		Map<String, Object> resDtoObjects = new HashMap<String, Object>();
		Boolean result = false;

		PaymentDto paymentDto = new PaymentDto();
		try {
			paymentDto.setPayuMoneyId(request.getParameter("payuMoneyId"));
			paymentDto.setTxnid(request.getParameter("txnid"));
			paymentDto.setAmount(Float.parseFloat(request.getParameter("amount")));
			paymentDto.setStatus(request.getParameter("status"));
			paymentDto.setHash(request.getParameter("hash"));

			paymentDto.setProductInfo(request.getParameter("productinfo"));
			paymentDto.setMode(request.getParameter("mode"));
			result = paymentServiceImpl.payment(paymentDto);
		} catch (HelthwellExceptionHandler _be) {
			mv.setViewName((String) resDtoObjects.get("viewName"));
			logger.error("Exception in PaymentController: SuccessPayment", _be);
			mv.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());

		} catch (Exception e) {
			mv.setViewName((String) resDtoObjects.get("viewName"));
			logger.error("Exception In PaymentController  --", e);
		}
		return mv;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/failed-payment-transaction", method = RequestMethod.POST)
	public ModelAndView FailedPayment(HttpServletRequest request, HttpServletResponse response) throws Exception {
		logger.info("PaymentController: FailedPayment Method Start.");
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		ModelAndView mv = new ModelAndView("failed_payment");
		HashMap<String, Object> reqDtoObjects = new HashMap<String, Object>();
		Map<String, Object> resDtoObjects = new HashMap<String, Object>();

		Boolean result = false;
		PaymentDto paymentDto = new PaymentDto();
		try {

			paymentDto.setPayuMoneyId(request.getParameter("payuMoneyId"));
			paymentDto.setTxnid(request.getParameter("txnid"));
			paymentDto.setAmount(Float.parseFloat(request.getParameter("amount")));
			paymentDto.setStatus(request.getParameter("status"));
			paymentDto.setHash(request.getParameter("hash"));
			paymentDto.setProductInfo(request.getParameter("productinfo"));
			paymentDto.setMode(request.getParameter("mode"));
			mv.addObject("paymentDto", paymentDto);

			result = paymentServiceImpl.payment(paymentDto);
		} catch (Exception e) {
			logger.error("Exception In PaymentController  --", e);
		}

		logger.info("PaymentController: FailedPayment Method End.");

		return mv;
	}
	
	

}
