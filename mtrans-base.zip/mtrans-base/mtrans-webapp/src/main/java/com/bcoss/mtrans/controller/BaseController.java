package com.bcoss.mtrans.controller;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.bcoss.mtrans.dto.WalletDto;
import com.bcoss.mtrans.dto.provider.response.QuickRechargeResponseDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.rest.CrowfinchRestClient;
import com.bcoss.mtrans.service.WalleterviceManager;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;


/**
 * The Class BaseController.
 */

@Controller
public class BaseController extends AbstractController {

	/** The logger. */
	Logger logger = LoggerFactory.getLogger(BaseController.class);

	/*
	 * @Autowired
	 * 
	 * @Qualifier("userManagementServiceImpl") private IUserManagementService
	 * userManagementServiceImpl;
	 */
	@Autowired
 	WalleterviceManager walleterviceManager;
	
	@Autowired
	private CrowfinchRestClient crowfinchRestClient;


	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();

		if (session.getAttribute(WebAppConstants.FLOWDATA) != null) {
			FlowData flowData = (FlowData) session.getAttribute(WebAppConstants.FLOWDATA);
			/*if ("false".equals(flowData.getSessionData("ISLOGEDIN")) || flowData.getSessionData("ISLOGEDIN") == null) {

				flowData.setSessionData("ISLOGEDIN", "false");
			}*/
			session.setAttribute(WebAppConstants.FLOWDATA, flowData);
		} else {
			FlowData flowData = new FlowData();

			try {
				session.setMaxInactiveInterval(50 * 60);
				session.setAttribute(WebAppConstants.FLOWDATA, flowData);
				//flowData.setSessionData("ISLOGEDIN", "false");
			} catch (Exception e) {
				logger.error("Got error while setting count ", e);
			}

		}
		return null;
	}
	
	

	/**
	 * Gets the nsi.
	 * 
	 * @return the nsi
	 */

	public ModelAndView loginPage(FlowData flowData, HttpServletRequest request) {
		Map<String, Object> resDtoObjects = new HashMap<String, Object>();
		logger.info("started loginPage method ");
		ModelAndView modelRoot = null;
		try {
			String viewName = "login";
			//viewName = (String) resDtoObjects.get(WebAppConstants.VIEW_NAME);
			modelRoot = new ModelAndView(viewName);
			modelRoot.addAllObjects(resDtoObjects);
			request.getSession().setAttribute(WebAppConstants.FLOWDATA, null);
			return modelRoot;
		} catch (Exception ex) {
			logger.error("Exception in loginPage()", ex);
			modelRoot = new ModelAndView((String) resDtoObjects.get(WebAppConstants.VIEW_NAME));

			return modelRoot;
		}
	}

	
	public ModelAndView getCommonSessionData(FlowData flowData , ModelAndView mv){
		mv.addObject(WebAppConstants.CIRCLECODE, flowData.getSessionData(WebAppConstants.CIRCLECODE));
		mv.addObject(WebAppConstants.EMPLOYEEID, flowData.getSessionData(WebAppConstants.EMPLOYEEID));
		mv.addObject(WebAppConstants.WALLETID, flowData.getSessionData(WebAppConstants.WALLETID));
		mv.addObject(WebAppConstants.COMPANYID, flowData.getSessionData(WebAppConstants.COMPANYID));
		mv.addObject(WebAppConstants.IS_READONLY,flowData.getSessionDataObject(WebAppConstants.IS_READONLY));
		mv.addObject(WebAppConstants.FIRSTNAME, flowData.getSessionData(WebAppConstants.FIRSTNAME));
		mv.addObject(WebAppConstants.COMPANYTYPE, flowData.getSessionData(WebAppConstants.COMPANYTYPE));
		mv.addObject(WebAppConstants.PLANID, flowData.getSessionData(WebAppConstants.PLANID));
		mv.addObject(WebAppConstants.EMAIL_ID, flowData.getSessionData(WebAppConstants.EMAIL_ID));
		mv.addObject(WebAppConstants.EMAIL_ID, flowData.getSessionData(WebAppConstants.EMAIL_ID));
		mv.addObject("marginDto", flowData.getSessionDataObject(WebAppConstants.MARGINE));
		
		
		mv.addObject("employeeDto", flowData.getSessionDataObject(WebAppConstants.EMPLOYEE));
		mv.addObject("marginDto", flowData.getSessionDataObject(WebAppConstants.MARGINE));
		mv.addObject("plansDtoList", flowData.getSessionDataObject(WebAppConstants.PLAN_LIST));
		mv.addObject("servicesDtoList", flowData.getSessionDataObject(WebAppConstants.SERVICE_LIST));

		try {

			if (flowData.getSessionData(WebAppConstants.COMPANYTYPE).equals("1")) {
				
				String messageToRecharge = "BAL";
				
				QuickRechargeResponseDto crowFinchResponse = crowfinchRestClient.getBalance(messageToRecharge);
				if(null == crowFinchResponse.getBalance()) {
					mv.addObject("balance", crowFinchResponse.getMessage());
				}else {
					double walletBalance = Double.parseDouble(crowFinchResponse.getBalance());//crowFinchResponse.getData().getBalance();
					mv.addObject("balance", walletBalance);
				}
				
				//System.out.println(response.getStatus());
				//String response = PrepaidRechargeUtil.checkBalance();
				//String balance = response.split(",")[0];
				
				
			} else {
				WalletDto walletDto = walleterviceManager
						.getwalletById(Integer.parseInt(flowData.getSessionData(WebAppConstants.WALLETID)));

				mv.addObject("balance", walletDto.getBalance());
			}

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: getStateById", _be);
			mv.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In WalletController getStateById Method--", e);
			mv.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		
		return mv;
	}
	
	
	
	/**
	 * @return generated token
	 */
	public static String nextToken() {
		long seed = System.currentTimeMillis();
		Random r = new Random();
		r.setSeed(seed);
		String token = Long.toString(seed) + Long.toString(Math.abs(r.nextLong()));
		// logger.debug(BaseController.class.getName() + ".nextToken :" +
		// token);
		return token;
	}

}