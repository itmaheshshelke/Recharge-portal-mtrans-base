package com.bcoss.mtrans.controller.admin;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bcoss.mtrans.controller.BaseController;
import com.bcoss.mtrans.dto.ServicesDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.service.ServicesServiceManager;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@Controller
@RequestMapping("/services")
public class ServicesController extends BaseController{

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(ServicesController.class);

	@Autowired
	private ServicesServiceManager servicesServiceManager;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView getAllServices(HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();

		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		try {
			model = super.getCommonSessionData(flowData, model);

			servicesDtoList = servicesServiceManager.getAllServices(1);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ServicesController: getAllServices", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In ServicesController getAllServices Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("servicesDtoList", servicesDtoList);
		model.setViewName("services");
		return model;
	}

	@RequestMapping(value = "/addServices", method = RequestMethod.GET)
	public ModelAndView addServices(HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		ServicesDto servicesDto = new ServicesDto();
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		
			model = super.getCommonSessionData(flowData, model);
		model.addObject("servicesDto", servicesDto);
		model.setViewName("addServices");
		return model;
	}

	@RequestMapping(value = "/{serviceId}", method = RequestMethod.GET)
	public ModelAndView getServicesById(@PathVariable("serviceId") Integer serviceId,HttpServletRequest request,
			HttpServletResponse response)
			throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		ServicesDto servicesDto = new ServicesDto();
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		try {
			model = super.getCommonSessionData(flowData, model);
			servicesDto = servicesServiceManager.getServicesById(serviceId);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ServicesController: getServicesById", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In ServicesController getServicesById Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("servicesDto", servicesDto);
		model.setViewName("addServices");
		return model;
	}

	@RequestMapping(value = "/saveServices", method = RequestMethod.POST)
	public ModelAndView saveServices(@ModelAttribute("servicesDto") ServicesDto servicesDto,HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		Boolean result = false;

		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		try {
			model = super.getCommonSessionData(flowData, model);
			result = servicesServiceManager.saveServices(servicesDto);

			servicesDtoList = servicesServiceManager.getAllServices(1);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ServicesController: saveServices", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In ServicesController saveServices Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}

		if (result == true)
			model.addObject("sucessMessage", "Record Update Succesfully");

		model.addObject("servicesDtoList", servicesDtoList);
		model.setViewName("services");
		return model;
	}
	
	@RequestMapping(value = "deleteServices/{serviceId}", method = RequestMethod.GET)
	public ModelAndView deleteServices(@PathVariable("serviceId") Integer serviceId,HttpServletRequest request,
			HttpServletResponse response)
			throws HelthwellExceptionHandler {

		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		ModelAndView model = new ModelAndView();
		Boolean result = false;
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		try {
			model = super.getCommonSessionData(flowData, model);
			result = servicesServiceManager.deleteServices(serviceId);

			
			servicesDtoList = servicesServiceManager.getAllServices(1);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ServicesController: deleteServices", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In ServicesController deleteServices Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		if (result == true)
			model.addObject("sucessMessage", "Record Update Succesfully");

		model.addObject("servicesDtoList", servicesDtoList);
		model.setViewName("services");
		return model;
	}

}
