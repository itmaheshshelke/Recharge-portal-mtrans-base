package com.bcoss.mtrans.controller.admin;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bcoss.mtrans.controller.BaseController;
import com.bcoss.mtrans.dto.ServiceOperatorsDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.service.ServiceOpertaorsServiceManager;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@Controller
@RequestMapping("service_operators")
public class ServiceOperatorsController extends BaseController{
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(ServiceOperatorsController.class);
	@Autowired
	private ServiceOpertaorsServiceManager serviceOperatorsServiceManager;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView getAllServiceOperators(HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<ServiceOperatorsDto> serviceOperatorsDtoList = new ArrayList<ServiceOperatorsDto>();

		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		try {
			model = super.getCommonSessionData(flowData, model);
			serviceOperatorsDtoList = serviceOperatorsServiceManager.getAllServiceOperators();

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ServiceOperatorsController: getAllServiceOperators", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In ServiceOperatorsController getAllServiceOperators Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("serviceOperatorsDtoList", serviceOperatorsDtoList);
		model.setViewName("serviceOperators");
		return model;
	}

	@RequestMapping(value = "/addServiceOperators", method = RequestMethod.GET)
	public ModelAndView addServiceOperators(HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		model = super.getCommonSessionData(flowData, model);
		ServiceOperatorsDto serviceOperatorsDto = new ServiceOperatorsDto();
		model.addObject("serviceOperatorsDto", serviceOperatorsDto);
		model.setViewName("addServiceOperators");
		return model;
	}

	@RequestMapping(value = "/{serviceId}", method = RequestMethod.GET)
	public ModelAndView getServiceOperatorsById(@PathVariable("serviceId") Integer serviceId,HttpServletRequest request,
			HttpServletResponse response)
			throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		ServiceOperatorsDto serviceOperatorsDto = new ServiceOperatorsDto();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			
			model = super.getCommonSessionData(flowData, model);
			serviceOperatorsDto = serviceOperatorsServiceManager.getServiceOperatorsById(serviceId);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ServiceOperatorsController: getServiceOperatorsById", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In ServiceOperatorsController getServiceOperatorsById Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("serviceOperatorsDto", serviceOperatorsDto);
		model.setViewName("addServiceOperators");
		return model;
	}

	@RequestMapping(value = "/saveServiceOperators", method = RequestMethod.POST)
	public ModelAndView saveServiceOperators(
			@ModelAttribute("serviceOperatorsDto") ServiceOperatorsDto serviceOperatorsDto,HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		List<ServiceOperatorsDto> serviceOperatorsDtoList = new ArrayList<ServiceOperatorsDto>();
		Boolean result = false;
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		try {
			
			model = super.getCommonSessionData(flowData, model);
			result = serviceOperatorsServiceManager.saveServiceOperators(serviceOperatorsDto);

			serviceOperatorsDtoList = serviceOperatorsServiceManager.getAllServiceOperators();

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ServiceOperatorsController: saveServiceOperators", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In ServiceOperatorsController saveServiceOperators Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}

		if (result == true)
			model.addObject("sucessMessage", "Record Update Succesfully");

		model.addObject("serviceOperatorsDtoList", serviceOperatorsDtoList);
		model.setViewName("serviceOperators");
		return model;
	}

	@RequestMapping(value = "deleteServiceOprators/{serviceId}", method = RequestMethod.GET)
	public ModelAndView deleteServiceOprators(@PathVariable("serviceId") Integer serviceId,HttpServletRequest request,
			HttpServletResponse response)
			throws HelthwellExceptionHandler {

		List<ServiceOperatorsDto> serviceOperatorsDtoList = new ArrayList<ServiceOperatorsDto>();
		ModelAndView model = new ModelAndView();
		Boolean result = false;
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		try {
			
			model = super.getCommonSessionData(flowData, model);
			result = serviceOperatorsServiceManager.deleteServiceOperators(serviceId);

			serviceOperatorsDtoList = serviceOperatorsServiceManager.getAllServiceOperators();

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ServiceOperatorsController: deleteServiceOprators", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In ServiceOperatorsController deleteServiceOprators Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		if (result == true)
			model.addObject("sucessMessage", "Record Update Succesfully");

		model.addObject("serviceOperatorsDtoList", serviceOperatorsDtoList);
		model.setViewName("serviceOperators");
		return model;
	}

}
