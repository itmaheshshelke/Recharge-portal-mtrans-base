package com.bcoss.mtrans.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.bcoss.mtrans.dao.RechargeDao;
import com.bcoss.mtrans.dto.ActivateBenificiaryDto;
import com.bcoss.mtrans.dto.BenificiaryDto;
import com.bcoss.mtrans.dto.CreateUserDto;
import com.bcoss.mtrans.dto.MoneyTransferDto;
import com.bcoss.mtrans.dto.WalletDto;
import com.bcoss.mtrans.dto.provider.response.AddBenificiaryResponseDto;
import com.bcoss.mtrans.dto.provider.response.QRMoneyTransferCheckUserDto;
import com.bcoss.mtrans.dto.provider.response.QuickRechargeResponseDto;
import com.bcoss.mtrans.dto.provider.response.SendMoneyResponseDto;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.rest.CrowfinchRestClient;
import com.bcoss.mtrans.rest.MoneyTransferRestClient;
import com.bcoss.mtrans.service.WalleterviceManager;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@RestController
@RequestMapping("/money-transfer")
public class MoneyTransferController extends BaseController {

	@Autowired
	private MoneyTransferRestClient moneyTransferRestClient;

	@Autowired
	private WalleterviceManager walleterviceManager;

	@Autowired
	private CrowfinchRestClient crowfinchRestClient;

	@Autowired
	private RechargeDao rechargeDao;

	@GetMapping(value = "/show-money-transfer-page")
	public ModelAndView showMoneyTransferPage(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);
		} catch (Exception e) {
			logger.error("Exception In CompanyController AddCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.setViewName("show-money-transfer-page");
		model = super.getCommonSessionData(flowData, model);
		return model;
	}

	@GetMapping(value = "/search-user-by-contact-no/{contactNo}")
	public ModelAndView SearchUserByContactNo(HttpServletRequest request, HttpServletResponse response,
			@PathVariable("contactNo") String contactNo) {
		ModelAndView model = new ModelAndView();

		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);

			QRMoneyTransferCheckUserDto qrMoneyTransferCheckUserDto = moneyTransferRestClient.checkUser(contactNo);

			model.addObject("qrMoneyTransferCheckUserDto", qrMoneyTransferCheckUserDto);
			model.addObject("number", contactNo);
			if (qrMoneyTransferCheckUserDto.getAccountExists() != null
					&& qrMoneyTransferCheckUserDto.getAccountExists().equals("1")) {
				model.setViewName("load-existing-beneficiary");
			} else {
				model.setViewName("add-new-user");
			}
		} catch (Exception e) {
			logger.error("Exception In CompanyController AddCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model = super.getCommonSessionData(flowData, model);
		return model;
	}

	@GetMapping(value = "/create-new-user")
	public ModelAndView createNewUser(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);
			CreateUserDto createUserDto = new CreateUserDto();
			createUserDto.setCustomerName(request.getParameter("userName"));
			createUserDto.setMobileNumber(request.getParameter("contactNo"));
			createUserDto.setPin("411028");
			QRMoneyTransferCheckUserDto qrMoneyTransferCheckUserDto = moneyTransferRestClient.createUser(createUserDto);
			// model.addObject("qrMoneyTransferCheckUserDto", qrMoneyTransferCheckUserDto);

			qrMoneyTransferCheckUserDto = moneyTransferRestClient.checkUser(request.getParameter("contactNo"));

			model.addObject("successmsg", "User added sucessfully");
			model.addObject("qrMoneyTransferCheckUserDto", qrMoneyTransferCheckUserDto);
			model.addObject("number", request.getParameter("contactNo"));

			model.setViewName("load-existing-beneficiary");
		} catch (Exception e) {
			logger.error("Exception In CompanyController AddCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model = super.getCommonSessionData(flowData, model);
		return model;
	}

	@GetMapping(value = "/add-new-beneficiary")
	public ModelAndView addNewBeneficiary(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		String mobileNumber = request.getParameter("mobileNumber");
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);
			QRMoneyTransferCheckUserDto qrMoneyTransferCheckUserDto = moneyTransferRestClient.checkUser(mobileNumber);
			model.addObject("qrMoneyTransferCheckUserDto", qrMoneyTransferCheckUserDto);

			BenificiaryDto benificiaryDto = new BenificiaryDto();
			benificiaryDto.setRemitterId(qrMoneyTransferCheckUserDto.getData().getRemitter().getId());
			benificiaryDto.setParentMobileNumber(mobileNumber);
			model.addObject("mobileNumber", mobileNumber);
			model.addObject("benificiaryDto", benificiaryDto);
			model.setViewName("add-new-beneficiary");
		} catch (Exception e) {
			logger.error("Exception In CompanyController AddCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model = super.getCommonSessionData(flowData, model);
		return model;
	}

	@PostMapping(value = "/save-beneficiary")
	public ModelAndView saveBeneficiary(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute BenificiaryDto benificiaryDto) {
		ModelAndView model = new ModelAndView();

		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);
			AddBenificiaryResponseDto addBenificiaryResponseDto = moneyTransferRestClient
					.addBenificiary(benificiaryDto);

			ActivateBenificiaryDto activateBenificiaryDto = new ActivateBenificiaryDto();
			activateBenificiaryDto.setBenificiaryId(addBenificiaryResponseDto.getData().getBeneficiary().getId());
			activateBenificiaryDto.setRemitterId(addBenificiaryResponseDto.getData().getRemitter().getId());
			activateBenificiaryDto.setParentMobileNumber(benificiaryDto.getParentMobileNumber());
			model.addObject("activateBenificiaryDto", activateBenificiaryDto);
			model.addObject("addBenificiaryResponseDto", addBenificiaryResponseDto);
			model.addObject("successmsg", "Beneficiary added sucessfully. Please enter OTP to activate beneficiary");
			model.setViewName("check-otp-validation");
		} catch (Exception e) {
			logger.error("Exception In CompanyController AddCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model = super.getCommonSessionData(flowData, model);
		return model;
	}

	@GetMapping(value = "/activate-beneficiary")
	public ModelAndView activateBeneficiary(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute BenificiaryDto benificiaryDto) {
		ModelAndView model = new ModelAndView();

		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);
			ActivateBenificiaryDto activateBenificiaryDto = new ActivateBenificiaryDto();
			activateBenificiaryDto.setBenificiaryId(request.getParameter("beneficiaryId"));
			activateBenificiaryDto.setRemitterId(request.getParameter("remitterId"));
			activateBenificiaryDto.setParentMobileNumber(request.getParameter("mobileNumber"));

			QRMoneyTransferCheckUserDto addBenificiaryResponseDto = moneyTransferRestClient
					.resendOtp(activateBenificiaryDto);

			model.addObject("activateBenificiaryDto", activateBenificiaryDto);
			model.addObject("successmsg", "Beneficiary sucessfully activated");
			model.addObject("addBenificiaryResponseDto", addBenificiaryResponseDto);
			model.setViewName("check-otp-validation");
		} catch (Exception e) {
			logger.error("Exception In CompanyController AddCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model = super.getCommonSessionData(flowData, model);
		return model;
	}

	@GetMapping(value = "/check-otp-validation")
	public ModelAndView checkOtpValdiate(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);
			ActivateBenificiaryDto activateBenificiaryDto = new ActivateBenificiaryDto();
			activateBenificiaryDto.setBenificiaryId(request.getParameter("beneficiaryId"));
			activateBenificiaryDto.setOtp(request.getParameter("otp"));
			activateBenificiaryDto.setRemitterId(request.getParameter("remitterId"));
			activateBenificiaryDto.setParentMobileNumber(request.getParameter("mobileNumber"));
			QRMoneyTransferCheckUserDto addBenificiaryResponseDto = moneyTransferRestClient
					.activateBenificiary(activateBenificiaryDto);

			model.addObject("addBenificiaryResponseDto", addBenificiaryResponseDto);

			QRMoneyTransferCheckUserDto qrMoneyTransferCheckUserDto = moneyTransferRestClient
					.checkUser(request.getParameter("mobileNumber"));

			model.addObject("qrMoneyTransferCheckUserDto", qrMoneyTransferCheckUserDto);
			model.setViewName("load-existing-beneficiary");
		} catch (Exception e) {
			logger.error("Exception In CompanyController AddCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model = super.getCommonSessionData(flowData, model);
		return model;
	}

	@GetMapping(value = "/check-otp-validation-cancel")
	public ModelAndView checkOtpValdiateCancel(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);

			QRMoneyTransferCheckUserDto qrMoneyTransferCheckUserDto = moneyTransferRestClient
					.checkUser(request.getParameter("mobileNumber"));

			model.addObject("qrMoneyTransferCheckUserDto", qrMoneyTransferCheckUserDto);
			model.setViewName("load-existing-beneficiary");
		} catch (Exception e) {
			logger.error("Exception In CompanyController AddCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model = super.getCommonSessionData(flowData, model);
		return model;
	}

	@GetMapping(value = "/delete-otp-validation")
	public ModelAndView deleteOtpValdiate(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);
			ActivateBenificiaryDto activateBenificiaryDto = new ActivateBenificiaryDto();
			activateBenificiaryDto.setBenificiaryId(request.getParameter("beneficiaryId"));
			activateBenificiaryDto.setOtp(request.getParameter("otp"));
			activateBenificiaryDto.setRemitterId(request.getParameter("remitterId"));
			activateBenificiaryDto.setParentMobileNumber(request.getParameter("mobileNumber"));
			QRMoneyTransferCheckUserDto addBenificiaryResponseDto = moneyTransferRestClient
					.deleteBenificiaryOtp(activateBenificiaryDto);

			model.addObject("addBenificiaryResponseDto", addBenificiaryResponseDto);

			model.addObject("successmsg", "Beneficiary deleted sucessfully");
			QRMoneyTransferCheckUserDto qrMoneyTransferCheckUserDto = moneyTransferRestClient
					.checkUser(request.getParameter("mobileNumber"));

			model.addObject("qrMoneyTransferCheckUserDto", qrMoneyTransferCheckUserDto);
			model.setViewName("load-existing-beneficiary");
		} catch (Exception e) {
			logger.error("Exception In CompanyController AddCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model = super.getCommonSessionData(flowData, model);
		return model;
	}

	@GetMapping(value = "/delete-benifiery")
	public ModelAndView deleteBenificiary(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);

			ActivateBenificiaryDto activateBenificiaryDto = new ActivateBenificiaryDto();
			activateBenificiaryDto.setBenificiaryId(request.getParameter("beneficiaryId"));
			activateBenificiaryDto.setRemitterId(request.getParameter("remitterId"));
			activateBenificiaryDto.setParentMobileNumber(request.getParameter("mobileNumber"));
			QRMoneyTransferCheckUserDto qrMoneyTransferCheckUserDto = moneyTransferRestClient
					.deleteBenificiary(activateBenificiaryDto);

			qrMoneyTransferCheckUserDto = moneyTransferRestClient.checkUser(request.getParameter("mobileNumber"));

			model.addObject("qrMoneyTransferCheckUserDto", qrMoneyTransferCheckUserDto);

			model.addObject("activateBenificiaryDto", activateBenificiaryDto);
			model.addObject("successmsg", "Enter OTP to delete beneficiary");
			model.setViewName("delete-otp-validation");
		} catch (Exception e) {
			logger.error("Exception In CompanyController AddCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model = super.getCommonSessionData(flowData, model);
		return model;
	}

	@GetMapping(value = "/show-transfer-amount")
	public ModelAndView showSendMoney(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);

			MoneyTransferDto moneyTransferDto = new MoneyTransferDto();
			moneyTransferDto.setBeneficiaryCode(request.getParameter("beneficiaryId"));
			moneyTransferDto.setMobileNo(request.getParameter("mobileNumber"));

			QRMoneyTransferCheckUserDto qrMoneyTransferCheckUserDto = moneyTransferRestClient
					.checkUser(request.getParameter("mobileNumber"));
			model.addObject("qrMoneyTransferCheckUserDto", qrMoneyTransferCheckUserDto);
			model.addObject("moneyTransferDto", moneyTransferDto);

			model.setViewName("show-transfer-amount");
		} catch (Exception e) {
			logger.error("Exception In CompanyController AddCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model = super.getCommonSessionData(flowData, model);
		return model;
	}

	@PostMapping(value = "/send-money")
	public ModelAndView sendMoney(HttpServletRequest request, HttpServletResponse response,
			@ModelAttribute MoneyTransferDto moneyTransferDto) {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		SendMoneyResponseDto sendMoneyResponseDto = null;
		WalletDto walletDto = new WalletDto();
		try {

			model = super.getCommonSessionData(flowData, model);

			Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));

			double walletBalance = 0.0;
			if (flowData.getSessionData(WebAppConstants.COMPANYTYPE).equals("1")) {
				String messageToRecharge = "BAL";
				QuickRechargeResponseDto crowFinchResponse = crowfinchRestClient.getBalance(messageToRecharge);
				if (null != crowFinchResponse.getBalance()) {
					walletBalance = Double.parseDouble(crowFinchResponse.getBalance());// crowFinchResponse.getData().getBalance();
					walletBalance = walletBalance - Double.parseDouble(moneyTransferDto.getAmount());
				} else {
					walletBalance = 0.0;
				}

			} else {
				Integer walletId = Integer.parseInt(flowData.getSessionData(WebAppConstants.WALLETID));
				walletDto = walleterviceManager.getwalletById(walletId);
				walletBalance = walletDto.getBalance();
				walletBalance = walletBalance - Double.parseDouble(moneyTransferDto.getAmount());
			}
			if (walletBalance <= 0) {
				// serviceResponseDto.setErrorCode("RKSS-001-IN");
				model.addObject("errormsg",
						"There is no sufficient amount in your balance. Please recharge and try again");
				// return model;
			} else {

				sendMoneyResponseDto = moneyTransferRestClient.moneyTransfer(moneyTransferDto);
				sendMoneyResponseDto.getData().setAmount(moneyTransferDto.getAmount());

				model.addObject("moneyTransferDto", moneyTransferDto);

				if (sendMoneyResponseDto.getStatus().equals("SUCCESS")) {
					model.addObject("successmsg", "Amount sent sucessfully");
				} else {
					model.addObject("successmsg", "Error Message from provider : " + sendMoneyResponseDto.getMessage());
				}

			}

			QRMoneyTransferCheckUserDto qrMoneyTransferCheckUserDto = moneyTransferRestClient
					.checkUser(moneyTransferDto.getMobileNo());

			model.addObject("qrMoneyTransferCheckUserDto", qrMoneyTransferCheckUserDto);
			model.setViewName("load-existing-beneficiary");
			sendMoneyResponseDto.setWalletBalance(walletBalance);
			rechargeDao.saveMoneyTransferResponse(sendMoneyResponseDto, moneyTransferDto.getBeneficiaryCode(),
					companyId);

		} catch (Exception e) {
			logger.error("Exception In CompanyController AddCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model = super.getCommonSessionData(flowData, model);
		return model;
	}

}
