package com.bcoss.mtrans.controller.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bcoss.mtrans.dto.LiveTransactionReportDto;
import com.bcoss.mtrans.service.DocumentServiceImpl;

/**
 * Created by Mahesh Shelke on 30/09/18.
 */

public class LiveReportExcel {

	static Logger logger = LoggerFactory.getLogger(LiveReportExcel.class);
	private static String[] columns = { "Sr.No",  "Company Name","Company Type", "Service","Operator","Mobile Number", "Recharge Amount", "Margin",
		"Final Amount","Trns No", "Trans Date", "Status" };

	public static String LiveReport(List<LiveTransactionReportDto> liveTransactionReportDtoList)
			throws IOException, InvalidFormatException {
		
		
		//create directory
		String fileUploadPath="C://excel//";
		File file1 = new File(fileUploadPath);
		if (!file1.exists()) {
			if (file1.mkdirs()) {
				logger.info("Directory is created!");
			} else {
				logger.info("Failed to create directory!");
			}
		}
		String path=file1+File.separator +"live-report.xlsx";
		// Create a Workbook
		Workbook workbook = new XSSFWorkbook(); // new HSSFWorkbook() for generating `.xls` file

		/*
		 * CreationHelper helps us create instances for various things like DataFormat,
		 * Hyperlink, RichTextString etc in a format (HSSF, XSSF) independent way
		 */
		CreationHelper createHelper = workbook.getCreationHelper();

		// Create a Sheet
		Sheet sheet = workbook.createSheet("Live Report");

		// Create a Font for styling header cells
		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setFontHeightInPoints((short) 14);
		headerFont.setColor(IndexedColors.RED.getIndex());

		// Create a CellStyle with the font
		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFont(headerFont);

		// Create a Row
		Row headerRow = sheet.createRow(0);

		// Creating cells
		for (int i = 0; i < columns.length; i++) {
			Cell cell = headerRow.createCell(i);
			cell.setCellValue(columns[i]);
			cell.setCellStyle(headerCellStyle);
		}

		// Cell Style for formatting Date
		CellStyle dateCellStyle = workbook.createCellStyle();
		dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd-MM-yyyy"));

		// Create Other rows and cells with employees data
		int rowNum = 1;
		Integer srNo = 1;
		for (LiveTransactionReportDto liveTransactionReportDto : liveTransactionReportDtoList) {
			Row row = sheet.createRow(rowNum++);

			row.createCell(0).setCellValue(srNo);
			row.createCell(1).setCellValue(liveTransactionReportDto.getCopmanyName());
			String type = "";
			if (liveTransactionReportDto.getCopmanyType() == 1) {
				type = "Master";
			} else if (liveTransactionReportDto.getCopmanyType() == 3) {
				type = "Distributor";
			} else {
				type = "Retailer";
			}
			row.createCell(2).setCellValue(liveTransactionReportDto.getServiseName());
			row.createCell(3).setCellValue(liveTransactionReportDto.getServiseName());
			row.createCell(4).setCellValue(liveTransactionReportDto.getOperaterName());
			row.createCell(5).setCellValue(liveTransactionReportDto.getMombileNumber());
			if(liveTransactionReportDto.getAmount()!=null) {
			row.createCell(6).setCellValue(liveTransactionReportDto.getAmount().toString());
			}else {
				row.createCell(6).setCellValue("");
			}
			if(liveTransactionReportDto.getMargine()!=null) {
				row.createCell(7).setCellValue(liveTransactionReportDto.getMargine().toString());
				}else {
					row.createCell(7).setCellValue("");
				}
			
			if(liveTransactionReportDto.getFinalAmount()!=null) {
			row.createCell(8).setCellValue(liveTransactionReportDto.getFinalAmount().toString());}
			else {
				row.createCell(8).setCellValue("");
			}
			
			row.createCell(9).setCellValue(liveTransactionReportDto.getTxId());

			Cell dateOfBirthCell = row.createCell(10);
			dateOfBirthCell.setCellValue(liveTransactionReportDto.getTime());
			dateOfBirthCell.setCellStyle(dateCellStyle);
			row.createCell(11).setCellValue(liveTransactionReportDto.getStatus());
			srNo++;
		}

		// Resize all columns to fit the content size
		for (int i = 0; i < columns.length; i++) {
			sheet.autoSizeColumn(i);
		}

		// Write the output to a file
		FileOutputStream fileOut = new FileOutputStream(path );
		workbook.write(fileOut);
		fileOut.close();

		workbook.close();
		return path;
	}

}
