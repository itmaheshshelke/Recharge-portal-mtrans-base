package com.bcoss.mtrans.controller.admin;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bcoss.mtrans.CompanyDetailsDto;
import com.bcoss.mtrans.controller.BaseController;
import com.bcoss.mtrans.controller.util.LiveReportExcel;
import com.bcoss.mtrans.controller.util.MoneyTransfereReportExcel;
import com.bcoss.mtrans.controller.util.RechargeReportExcel;
import com.bcoss.mtrans.controller.util.UserReportExcel;
import com.bcoss.mtrans.controller.util.WalletExcel;
import com.bcoss.mtrans.dto.LiveTransactionReportDto;
import com.bcoss.mtrans.dto.MoneyTransferResponseDto;
import com.bcoss.mtrans.dto.ServiceResponseDto;
import com.bcoss.mtrans.dto.WalletTransactionDto;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@RestController
@RequestMapping("/excel-report")
public class ExcelReportController extends BaseController {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(ReportController.class);

	@RequestMapping(value = "/get-recharge-history-excel", method = RequestMethod.GET)
	public void downloadExcel(HttpServletRequest request, HttpServletResponse response) throws InvalidFormatException {

		final int BUFFER_SIZE = 4096;
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		try {
			List<ServiceResponseDto> serviceResponseDtoList = (List<ServiceResponseDto>) flowData
					.getSessionDataObject("serviceResponseDtoList");
			String file_path = RechargeReportExcel.RechargeHistory(serviceResponseDtoList);
			//flowData.setSessionDataObject("serviceResponseDtoList", null);
			File downloadFile = new File(file_path);

			FileInputStream inputStream = new FileInputStream(downloadFile);
			String mimeType = "application/octet-stream";
			System.out.println("MIME type: " + mimeType);

			// set content attributes for the response
			response.setContentType(mimeType);
			response.setContentLength((int) downloadFile.length());

			// set headers for the response
			String headerKey = "Content-Disposition";
			String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getName());
			response.setHeader(headerKey, headerValue);

			// get output stream of the response
			OutputStream outStream = response.getOutputStream();

			byte[] buffer = new byte[BUFFER_SIZE];
			int bytesRead = -1;

			while ((bytesRead = inputStream.read(buffer)) != -1) {
				outStream.write(buffer, 0, bytesRead);
			}

			inputStream.close();
			outStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		logger.info("ReportController: getReportInExcel Method End.");
	}

	@RequestMapping(value = "/get-live-report-excel", method = RequestMethod.GET)
	public void downloadLiveReportExcel(HttpServletRequest request, HttpServletResponse response)
			throws InvalidFormatException {

		final int BUFFER_SIZE = 4096;
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		try {
			List<LiveTransactionReportDto> liveTransactionReportDtoList = (List<LiveTransactionReportDto>) flowData
					.getSessionDataObject("liveTransactionReportDtoList");
			String file_path = LiveReportExcel.LiveReport(liveTransactionReportDtoList);
			//flowData.setSessionDataObject("liveTransactionReportDtoList", null);
			File downloadFile = new File(file_path);

			FileInputStream inputStream = new FileInputStream(downloadFile);
			String mimeType = "application/octet-stream";
			System.out.println("MIME type: " + mimeType);

			// set content attributes for the response
			response.setContentType(mimeType);
			response.setContentLength((int) downloadFile.length());

			// set headers for the response
			String headerKey = "Content-Disposition";
			String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getName());
			response.setHeader(headerKey, headerValue);

			// get output stream of the response
			OutputStream outStream = response.getOutputStream();

			byte[] buffer = new byte[BUFFER_SIZE];
			int bytesRead = -1;

			while ((bytesRead = inputStream.read(buffer)) != -1) {
				outStream.write(buffer, 0, bytesRead);
			}

			inputStream.close();
			outStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		logger.info("ReportController: downloadLiveReportExcel Method End.");
	}

	@RequestMapping(value = "/get-money-transfer-report-excel", method = RequestMethod.GET)
	public void downloadMoneyTransferReportExcel(HttpServletRequest request, HttpServletResponse response)
			throws InvalidFormatException {

		final int BUFFER_SIZE = 4096;
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		try {
			List<MoneyTransferResponseDto> moneyTransferResponseDtoList = (List<MoneyTransferResponseDto>) flowData
					.getSessionDataObject("moneyTransferResponseDtoList");
			String file_path = MoneyTransfereReportExcel.MoneyTransfer(moneyTransferResponseDtoList);
			//flowData.setSessionDataObject("moneyTransferResponseDtoList", null);
			File downloadFile = new File(file_path);

			FileInputStream inputStream = new FileInputStream(downloadFile);
			String mimeType = "application/octet-stream";
			System.out.println("MIME type: " + mimeType);

			// set content attributes for the response
			response.setContentType(mimeType);
			response.setContentLength((int) downloadFile.length());

			// set headers for the response
			String headerKey = "Content-Disposition";
			String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getName());
			response.setHeader(headerKey, headerValue);

			// get output stream of the response
			OutputStream outStream = response.getOutputStream();

			byte[] buffer = new byte[BUFFER_SIZE];
			int bytesRead = -1;

			while ((bytesRead = inputStream.read(buffer)) != -1) {
				outStream.write(buffer, 0, bytesRead);
			}

			inputStream.close();
			outStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		logger.info("ReportController: downloadMoneyTransferReportExcel Method End.");
	}

	@RequestMapping(value = "/get-user-report-excel", method = RequestMethod.GET)
	public void downloadUserReportExcel(HttpServletRequest request, HttpServletResponse response)
			throws InvalidFormatException {

		final int BUFFER_SIZE = 4096;
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		try {

			List<CompanyDetailsDto> companyDetailsList = (List<CompanyDetailsDto>) flowData
					.getSessionDataObject("companyDetailsList");
			String comapnyName = (String) flowData.getSessionDataObject("cName");
			String file_path = UserReportExcel.UserReport(companyDetailsList, comapnyName);
			//flowData.setSessionDataObject("companyDetailsList", null);
			//flowData.setSessionDataObject("cName", null);
			File downloadFile = new File(file_path);

			FileInputStream inputStream = new FileInputStream(downloadFile);
			String mimeType = "application/octet-stream";
			System.out.println("MIME type: " + mimeType);

			// set content attributes for the response
			response.setContentType(mimeType);
			response.setContentLength((int) downloadFile.length());

			// set headers for the response
			String headerKey = "Content-Disposition";
			String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getName());
			response.setHeader(headerKey, headerValue);

			// get output stream of the response
			OutputStream outStream = response.getOutputStream();

			byte[] buffer = new byte[BUFFER_SIZE];
			int bytesRead = -1;

			while ((bytesRead = inputStream.read(buffer)) != -1) {
				outStream.write(buffer, 0, bytesRead);
			}

			inputStream.close();
			outStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		logger.info("ReportController: downloadMoneyTransferReportExcel Method End.");
	}

	
	@RequestMapping(value = "/get-wallet-history-excel", method = RequestMethod.GET)
	public void downloadWalletReportExcel(HttpServletRequest request, HttpServletResponse response)
			throws InvalidFormatException {

		final int BUFFER_SIZE = 4096;
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		try {
			
			List<WalletTransactionDto> walletTransactionDtoList = (List<WalletTransactionDto>) flowData
					.getSessionDataObject("walletTransactionDtoList");
			
			String file_path = WalletExcel.WalletRechargeReport(walletTransactionDtoList);
			//flowData.setSessionDataObject("companyDetailsList", null);
			//flowData.setSessionDataObject("cName", null);
			File downloadFile = new File(file_path);

			FileInputStream inputStream = new FileInputStream(downloadFile);
			String mimeType = "application/octet-stream";
			System.out.println("MIME type: " + mimeType);

			// set content attributes for the response
			response.setContentType(mimeType);
			response.setContentLength((int) downloadFile.length());

			// set headers for the response
			String headerKey = "Content-Disposition";
			String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getName());
			response.setHeader(headerKey, headerValue);

			// get output stream of the response
			OutputStream outStream = response.getOutputStream();

			byte[] buffer = new byte[BUFFER_SIZE];
			int bytesRead = -1;

			while ((bytesRead = inputStream.read(buffer)) != -1) {
				outStream.write(buffer, 0, bytesRead);
			}

			inputStream.close();
			outStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		logger.info("ReportController: downloadMoneyTransferReportExcel Method End.");
	}

}
