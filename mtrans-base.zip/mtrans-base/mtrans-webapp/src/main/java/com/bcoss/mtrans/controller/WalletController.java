package com.bcoss.mtrans.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.bcoss.mtrans.CompanyDetailsDto;
import com.bcoss.mtrans.EmployeeDto;
import com.bcoss.mtrans.dto.WalletDto;
import com.bcoss.mtrans.dto.WalletTransactionDto;
import com.bcoss.mtrans.dto.provider.response.QuickRechargeResponseDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.WalletTransaction;
import com.bcoss.mtrans.rest.CrowfinchRestClient;
import com.bcoss.mtrans.service.CompanyDetailsServiceManager;
import com.bcoss.mtrans.service.WalleterviceManager;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.PrepaidRechargeUtil;
import com.bcoss.mtrans.util.WebAppConstants;

@RestController
@RequestMapping("/wallet")
public class WalletController extends BaseController {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(WalletController.class);

	@Autowired
	WalleterviceManager walleterviceManager;

	@Autowired
	private CrowfinchRestClient crowfinchRestClient;

	@Autowired
	private CompanyDetailsServiceManager companyServiceManager;

	@RequestMapping(value = "/{walletId}", method = RequestMethod.GET)
	public ModelAndView getwalletById(@PathVariable("walletId") Integer walletId,HttpServletRequest request, HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		WalletDto walletDto = new WalletDto();
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			walletDto = walleterviceManager.getwalletById(walletId);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: getwalletById", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In WalletController getwalletById Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.addObject("walletDto", walletDto);
		model.setViewName("");
		return model;
	}

	@RequestMapping(value = "/getAllCompanyWallateBalance", method = RequestMethod.GET)
	public ModelAndView getAllCompanyWallateBalance(HttpServletRequest request, HttpServletResponse response)
			throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<>();
		WalletDto walletDto = new WalletDto();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		try {
			Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			companyDetailsDtoList = walleterviceManager.getAllCompanyWallateBalance(companyId);
			walletDto = walleterviceManager.getTotalWalletRecharge(companyId);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: getAllCompanyWallateBalance", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In WalletController getAllCompanyWallateBalance Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		flowData.setSessionData(WebAppConstants.ISLOGEDIN, "true");
		model = super.getCommonSessionData(flowData, model);
		if (model == null) {
			return super.loginPage(flowData, request);
		}
		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.addObject("rechargeAmount", walletDto.getBalance());
		model.addObject("companyDetailsDtoList", companyDetailsDtoList);
		model.setViewName("wallet");
		return model;
	}

	@RequestMapping(value = "/companyRecharge", method = RequestMethod.GET)
	public ModelAndView companyRecharge(HttpServletRequest request, HttpServletResponse response,Model modelAttribute)
			throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<>();

		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		try {
			Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			companyDetailsDtoList = walleterviceManager.companyRecharge(companyId);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: companyRecharge", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In WalletController companyRecharge Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		flowData.setSessionData(WebAppConstants.ISLOGEDIN, "true");
		model = super.getCommonSessionData(flowData, model);
		if (model == null) {
			return super.loginPage(flowData, request);
		}
		model.addObject("successmsg", modelAttribute.asMap().get("successmsg"));
		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.addObject("companyDetailsDtoList", companyDetailsDtoList);
		model.setViewName("companyRecharge");
		return model;
	}

	
	@RequestMapping(value = "/walletTransaction", method = RequestMethod.GET)
	public ModelAndView walletTransaction(HttpServletRequest request, HttpServletResponse response)
			throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<>();

		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		try {
			Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			companyDetailsDtoList = walleterviceManager.companyRecharge(companyId);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: walletTransaction", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In WalletController walletTransaction Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		flowData.setSessionData(WebAppConstants.ISLOGEDIN, "true");
		model = super.getCommonSessionData(flowData, model);
		if (model == null) {
			return super.loginPage(flowData, request);
		}
		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.addObject("companyDetailsDtoList", companyDetailsDtoList);
		model.setViewName("walletTransaction");
		return model;
	}

	@RequestMapping(value = "addRechargeWallet", method = RequestMethod.GET)
	public ModelAndView addRechargeWallet(@RequestParam("distributorsCompanyId") Integer distributorsCompanyId,@RequestParam("companyId") Integer companyId,@RequestParam("viewName") String viewName ,HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		model = super.getCommonSessionData(flowData, model);
		model.addObject("distributorsCompanyId", distributorsCompanyId);
		model.addObject("companyId", companyId);
		model.addObject("viewName", viewName);
		model.setViewName("addRechargeWallet");
		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		return model;
	}

	@RequestMapping(value = "/saveRechargeWallet")
	public ModelAndView saveRechargeWallet(HttpServletRequest request, HttpServletResponse response,RedirectAttributes redirectAttrs) {
		ModelAndView model = new ModelAndView();

		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		model = super.getCommonSessionData(flowData, model);
		model.setViewName("");
		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<>();
		Integer companyId = Integer.parseInt(request.getParameter("companyId"));
		String viewName = request.getParameter("viewName");
		String distributorsCompanyId = request.getParameter("distributorsCompanyId");
		
		Double rechargeamount = Double.parseDouble(request.getParameter("rechargeAmount"));
		Integer loggedCompanyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
		WalletDto rechargeBalanceWalletDto = new WalletDto();
		try {
			// verify the balance ..
			rechargeBalanceWalletDto = walleterviceManager.getTotalWalletRecharge(loggedCompanyId);
			double remainWalletBalance = 0.0;
			if (flowData.getSessionData(WebAppConstants.COMPANYTYPE).equals("1")) {
				String messageToRecharge = "BAL";
				QuickRechargeResponseDto crowFinchResponse = crowfinchRestClient.getBalance(messageToRecharge);
				double walletBalance = 0.0;

				if (null != crowFinchResponse.getBalance()) {
					walletBalance = Double.parseDouble(crowFinchResponse.getBalance());// crowFinchResponse.getData().getBalance();
					// remainWalletBalance=walletBalance-rechargeBalanceWalletDto.getBalance();
				} else {
					walletBalance = 0.0;
				}

				/*if (walletBalance < rechargeamount) {
					throw new HelthwellExceptionHandler(HelthwellServiceErrors.COMPANY_BALANCE_LOW);
				}*/
			} else {

				WalletDto walletDto = walleterviceManager
						.getwalletById(Integer.parseInt(flowData.getSessionData(WebAppConstants.WALLETID)));

				// remainWalletBalance=walletDto.getBalance()-rechargeBalanceWalletDto.getBalance();

				if (walletDto.getBalance() < rechargeamount || (walletDto.getBalance() - rechargeamount) <= 0) {
					redirectAttrs.addFlashAttribute("successmsg", "COMPANY BALANCE LOW");
					throw new HelthwellExceptionHandler(HelthwellServiceErrors.COMPANY_BALANCE_LOW);
					
				}
			}
			char type='C';
			walleterviceManager.saveRechargeWallet(loggedCompanyId, companyId, rechargeamount,type);
			model.addObject("successmsg", "Wallet rechared sucessfully with Rs. " + rechargeamount);
			redirectAttrs.addFlashAttribute("successmsg", "Wallet rechared sucessfully with Rs. " + rechargeamount);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: saveRechargeWallet", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getDescription());
		} catch (Exception e) {
			logger.error("Exception In WalletController saveRechargeWallet Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}

		try {
			Integer login_companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			companyDetailsDtoList = walleterviceManager.companyRecharge(login_companyId);
			model.addObject("companyDetailsDtoList", companyDetailsDtoList);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: saveRechargeWallet", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getDescription());
		} catch (Exception e) {
			logger.error("Exception In WalletController saveRechargeWallet Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.addObject("rechargeAmount", rechargeBalanceWalletDto.getBalance());
		model.setViewName("companyRecharge");
		if(viewName.equals("show-distributors")) {
		return new ModelAndView("redirect:/report/show-all-distributors?pageNumber=1&pageSize=25&searchTerm=");
		}else if(viewName.equals("companyRecharge")) {
		return new ModelAndView("redirect:/wallet/companyRecharge");	
		}else if(viewName.equals("master-retailers")) {
			return new ModelAndView("redirect:/report/get-master-retailers?pageNumber=1&pageSize=25&searchTerm=");	
			}
		else {
			return new ModelAndView("redirect:/report/show-all-retailers-under-distributors?distributorsCompanyId="+distributorsCompanyId+"&pageNumber=1&pageSize=25&searchTerm=");
		}
		
		
	}

	@RequestMapping(value = "/getAllCompanyTransaction/{companyId}", method = RequestMethod.GET)
	public ModelAndView getAllCompanyTransaction(@PathVariable("companyId") Integer companyId,
			HttpServletRequest request, HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<WalletTransactionDto> walletTransactionDtoList = new ArrayList<>();

		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		try {

			walletTransactionDtoList = walleterviceManager.getAllCompanyTransaction(companyId);
			flowData.setSessionDataObject("walletTransactionDtoList", walletTransactionDtoList);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: getAllCompanyTransaction", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In WalletController getAllCompanyTransaction Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model = super.getCommonSessionData(flowData, model);
		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.addObject("walletTransactionDtoList", walletTransactionDtoList);
		model.setViewName("getAllCompanyTransaction");
		return model;
	}

	@RequestMapping(value = "requestRecharge", method = RequestMethod.GET)
	public ModelAndView requestRecharge(HttpServletRequest request, HttpServletResponse response)
			throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		model = super.getCommonSessionData(flowData, model);

		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));

		model.setViewName("requestRecharge");
		return model;
	}

	@RequestMapping(value = "/addRequestRecharge")
	public ModelAndView addRequestRecharge(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();

		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		model = super.getCommonSessionData(flowData, model);
		model.setViewName("");
		String description = request.getParameter("description");
		Double rechargeamount = Double.parseDouble(request.getParameter("rechargeAmount"));

		try {
			EmployeeDto employeeDto = (EmployeeDto) flowData.getSessionDataObject(WebAppConstants.EMPLOYEE);
			WalletTransaction walletTransaction = new WalletTransaction();
			walletTransaction.setTransAmount(rechargeamount);
			walletTransaction.setWalletId(Integer.parseInt(flowData.getSessionData(WebAppConstants.WALLETID)));
			walletTransaction.setParentId(employeeDto.getCreatedBy());
			walletTransaction.setDescription(description);
			walletTransaction.setTransStatus("PENDING");
			walleterviceManager.addRequestRecharge(walletTransaction);
			model.addObject("successmsg", "Wallet rechared sucessfully with Rs. " + rechargeamount);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: addRequestRecharge", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getDescription());
		} catch (Exception e) {
			logger.error("Exception In WalletController addRequestRecharge Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.setViewName("requestRecharge");
		return model;
	}

	@RequestMapping(value = "getRequestRecharge", method = RequestMethod.GET)
	public ModelAndView getRequestRecharge(HttpServletRequest request, HttpServletResponse response)
			throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		model = super.getCommonSessionData(flowData, model);
		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<>();
		try {
			Integer login_companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			companyDetailsDtoList = walleterviceManager.getRequestRecharge(login_companyId);
			model.addObject("companyDetailsDtoList", companyDetailsDtoList);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: saveRechargeWallet", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getDescription());
		} catch (Exception e) {
			logger.error("Exception In WalletController saveRechargeWallet Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.setViewName("getAllRequestRecharge");
		return model;
	}

	@RequestMapping(value = "approveRequest/{transNumber}/{balance}", method = RequestMethod.GET)
	public ModelAndView approveRequest(@PathVariable("transNumber") String transNumber,
			@PathVariable("balance") Double rechargeamount, HttpServletRequest request, HttpServletResponse response)
			throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		model = super.getCommonSessionData(flowData, model);

		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<>();
		try {

			if (flowData.getSessionData(WebAppConstants.COMPANYTYPE).equals("1")) {
				String balanceResponse = PrepaidRechargeUtil.checkBalance();
				String balance = balanceResponse.split(",")[0];
				// mv.addObject("balance", balance);
				if (Double.parseDouble(balance) < rechargeamount) {
					throw new HelthwellExceptionHandler(HelthwellServiceErrors.COMPANY_BALANCE_LOW);
				}
			} else {
				WalletDto walletDto = walleterviceManager
						.getwalletById(Integer.parseInt(flowData.getSessionData(WebAppConstants.WALLETID)));

				if (walletDto.getBalance() < rechargeamount) {
					throw new HelthwellExceptionHandler(HelthwellServiceErrors.COMPANY_BALANCE_LOW);
				}

			}
			Integer login_companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));

			Integer login_walletId = Integer.parseInt(flowData.getSessionData(WebAppConstants.WALLETID));

			Boolean result = walleterviceManager.approveRequest(transNumber, login_walletId, login_companyId);

			companyDetailsDtoList = walleterviceManager.getRequestRecharge(login_companyId);
			model.addObject("companyDetailsDtoList", companyDetailsDtoList);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: saveRechargeWallet", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getDescription());
		} catch (Exception e) {
			logger.error("Exception In WalletController saveRechargeWallet Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.setViewName("getAllRequestRecharge");
		return model;
	}

	@GetMapping("/active-company/{compnayId}")
	public String activeCompany(HttpServletRequest request, HttpServletResponse response,
			@PathVariable("compnayId") Integer compnayId) {
		Boolean result = false;
		try {
			Integer isActive = 1;
			result = walleterviceManager.activeDeactiveCompany(compnayId, isActive);
		} catch (Exception e) {
			logger.error("Exception In WalletController activeCompany  --", e);
		}
		if (result == true) {
			return "Company activate successfully...";
		}

		return null;

	}

	@GetMapping("/deActive-company/{compnayId}")
	public String deactiveCompany(HttpServletRequest request, HttpServletResponse response,
			@PathVariable("compnayId") Integer compnayId) {
		Boolean result = false;
		try {
			Integer isActive = 2;
			result = walleterviceManager.activeDeactiveCompany(compnayId, isActive);
		} catch (Exception e) {
			logger.error("Exception In WalletController deactiveCompany  --", e);
		}
		if (result == true) {
			return "Company deactivate successfully...";
		}
		return null;

	}

	
	
	@GetMapping("/write-only-company/{compnayId}")
	public String writeOnlyCompany(HttpServletRequest request, HttpServletResponse response,
			@PathVariable("compnayId") Integer compnayId) {
		Boolean result = false;
		try {
			 Character isReadOnly = 'N';
			result = walleterviceManager.readWriteCompany(compnayId, isReadOnly);
		} catch (Exception e) {
			logger.error("Exception In WalletController writeOnlyCompany  --", e);
		}
		if (result == true) {
			return "Company write Only successfully...";
		}

		return null;

	}

	@GetMapping("/read-only-company/{compnayId}")
	public String readOnlyCompany(HttpServletRequest request, HttpServletResponse response,
			@PathVariable("compnayId") Integer compnayId) {
		Boolean result = false;
		try {
			Character isReadOnly = 'Y';
			result = walleterviceManager.readWriteCompany(compnayId, isReadOnly);
		} catch (Exception e) {
			logger.error("Exception In WalletController readOnlyCompany  --", e);
		}
		if (result == true) {
			return "Company readOnly successfully...";
		}
		return null;

	}

	
	@RequestMapping(value ="/deductWalletBalance")
	public ModelAndView deductWalletBalance(HttpServletRequest request, HttpServletResponse response,
			@RequestParam("distributorsCompanyId") Integer distributorsCompanyId,
			@RequestParam("walletId") Integer walletId,
			@RequestParam("viewName") String viewName) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		model = super.getCommonSessionData(flowData, model);
		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.addObject("walletId", walletId);
		model.addObject("distributorsCompanyId", distributorsCompanyId);
		model.addObject("viewName", viewName);
		model.setViewName("deductWalletBalance");
		return model;
	}

	@RequestMapping(value = "/saveDeductWalletBalance")
	public ModelAndView saveDeductWalletBalance(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		WalletDto walletDto = new WalletDto();
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		model = super.getCommonSessionData(flowData, model);
		model.setViewName("");
		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<>();
		Integer walletId = Integer.parseInt(request.getParameter("walletId"));
		Double deductAmount = Double.parseDouble(request.getParameter("deductAmount"));
		Integer loggedCompanyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));

		try {
			char type='C';
			walleterviceManager.saveDeductWalletBalance(loggedCompanyId, walletId, deductAmount,type);
			model.addObject("successmsg", "balance deduct sucessfully with Rs. " + deductAmount);
			companyDetailsDtoList = walleterviceManager.getAllCompanyWallateBalance(loggedCompanyId);
			walletDto = walleterviceManager.getTotalWalletRecharge(loggedCompanyId);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: saveDeductWalletBalance", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getDescription());
		} catch (Exception e) {
			logger.error("Exception In WalletController saveRechargeWallet Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}

		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.addObject("rechargeAmount", walletDto.getBalance());
		model.addObject("companyDetailsDtoList", companyDetailsDtoList);
		model.setViewName("wallet");
		return model;
	}

	@RequestMapping(value = "getTotalWalletRecharge", method = RequestMethod.GET)
	public ModelAndView getTotalWalletRecharge(HttpServletRequest request, HttpServletResponse response)
			throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		model = super.getCommonSessionData(flowData, model);
		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<>();
		WalletDto walletDto = new WalletDto();
		try {
			Integer login_companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			walletDto = walleterviceManager.getTotalWalletRecharge(login_companyId);
			model.addObject("companyDetailsDtoList", companyDetailsDtoList);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: getTotalWalletRecharge", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getDescription());
		} catch (Exception e) {
			logger.error("Exception In WalletController getTotalWalletRecharge Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.addObject("rechargeAmount", walletDto.getBalance());
		model.setViewName("getAllRequestRecharge");
		return model;
	}

	@RequestMapping(value = "/aeps", method = RequestMethod.GET)
	public ModelAndView AePS(HttpServletRequest request, HttpServletResponse response)
			throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.setViewName("aeps");
		return model;
	}

}
