package com.bcoss.mtrans.controller.admin;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.bcoss.mtrans.controller.BaseController;
import com.bcoss.mtrans.dto.CompanyMargineDto;
import com.bcoss.mtrans.dto.PlansDto;
import com.bcoss.mtrans.dto.ServiceOperatorsDto;
import com.bcoss.mtrans.dto.ServicesDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.service.CompanyMargineServiceManager;
import com.bcoss.mtrans.service.PlansServiceManager;
import com.bcoss.mtrans.service.ServiceOpertaorsServiceManager;
import com.bcoss.mtrans.service.ServicesServiceManager;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;


@RestController
@RequestMapping("/admin")
public class HomeController extends BaseController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Autowired
	private ServicesServiceManager servicesServiceManager;
		
	@Autowired
	private ServiceOpertaorsServiceManager serviceOpertaorsServiceManager;
	
	@Autowired
	private PlansServiceManager plansServiceManager;
	@Autowired
	private CompanyMargineServiceManager companyMargineServiceManager;
	@GetMapping(value = "/")
	public ModelAndView dashboard(HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		List<PlansDto> plansDtoList=new ArrayList<PlansDto>();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);
			plansDtoList=plansServiceManager.getAllPlans();
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in HomeController: dashboard", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController dashboard Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("marginDto", new CompanyMargineDto());
		model.addObject("servicesDtoList", servicesDtoList);
		model.addObject("plansDtoList", plansDtoList);
		model.setViewName("dashboard");
		return model;
	}
	@GetMapping(value = "/get-all-services-by-plan-id/{id}")
	public ModelAndView getAllServicesByPlanId(@PathVariable("id")Integer planId, HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		List<PlansDto> plansDtoList=new ArrayList<PlansDto>();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		try {
			model = super.getCommonSessionData(flowData, model);
			marginDto.setPlanId(planId);
			
			servicesDtoList = servicesServiceManager.getAllServices(planId);
			plansDtoList=plansServiceManager.getAllPlans();
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in HomeController: getAllServicesByPlanId", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController getAllServicesByPlanId Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("marginDto",marginDto);
		model.addObject("plansDtoList",plansDtoList);
		model.addObject("servicesDtoList", servicesDtoList);
		model.setViewName("dashboard");
		return model;
	}
	@GetMapping(value = "/get-operator-by-service-id/{id}/{planId}")
	public ModelAndView getOperatorByServiceId(@PathVariable("id")Integer serviceId,
			@PathVariable("planId")Integer planId, HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<ServiceOperatorsDto> serviceOperatorsDtoList = new ArrayList<ServiceOperatorsDto>();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		List<PlansDto> plansDtoList=new ArrayList<PlansDto>();
		List<CompanyMargineDto>companyMargineDtoList=new ArrayList<CompanyMargineDto>();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		try {
			
			model = super.getCommonSessionData(flowData, model);
			marginDto.setServiceId(serviceId);
			marginDto.setPlanId(planId);
			serviceOperatorsDtoList = serviceOpertaorsServiceManager.getOperatorByServiceId(serviceId);
			servicesDtoList = servicesServiceManager.getAllServices(planId);
			plansDtoList=plansServiceManager.getAllPlans();
			companyMargineDtoList=companyMargineServiceManager.getAllCompanyMargine(planId);
		} catch (HelthwellExceptionHandler _be) { 
			logger.error("Exception in HomeController: getOperatorByServiceId", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController getOperatorByServiceId Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("plansDtoList",plansDtoList);
		model.addObject("companyMargineDtoList",companyMargineDtoList);
		model.addObject("marginDto",marginDto);
		model.addObject("servicesDtoList", servicesDtoList);
		model.addObject("serviceOperatorsDtoList", serviceOperatorsDtoList);
		model.setViewName("dashboard");
		return model;
	}
	
	



}
