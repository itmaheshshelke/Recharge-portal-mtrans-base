package com.bcoss.mtrans.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.bcoss.mtrans.CompanyDetailsDto;
import com.bcoss.mtrans.dto.WalletDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.rest.CrowfinchRestClient;
import com.bcoss.mtrans.service.CompanyDetailsServiceManager;
import com.bcoss.mtrans.service.WalleterviceManager;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@RestController
@RequestMapping("/search")
public class SearchController extends BaseController {
	
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(SearchController.class);
	
	@Autowired
	WalleterviceManager walleterviceManager;

	@Autowired
	private CrowfinchRestClient crowfinchRestClient;

	@Autowired
	private CompanyDetailsServiceManager companyServiceManager;

	
	@GetMapping("/searchCompanyDetailsOnWallet/{qString}")
	public ModelAndView searchCompanyDetailsOnWallet(HttpServletRequest request, HttpServletResponse response,
			@PathVariable(value = "qString") String qString) {
		ModelAndView model = new ModelAndView();
		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<>();
		WalletDto walletDto = new WalletDto();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		try {
			Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			model.addObject("companyDetailsDtoList", companyServiceManager.searchCompanyDetails(companyId, qString));

			walletDto = walleterviceManager.getTotalWalletRecharge(companyId);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: getAllCompanyWallateBalance", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In WalletController getAllCompanyWallateBalance Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		flowData.setSessionData(WebAppConstants.ISLOGEDIN, "true");
		model = super.getCommonSessionData(flowData, model);
		if (model == null) {
			return super.loginPage(flowData, request);
		}
		model.addObject("qString", qString);
		model.addObject("rechargeAmount", walletDto.getBalance());
		model.setViewName("wallet");
		return model;
	}

	@GetMapping("/searchCompanyDetails/{qString}")
	public ModelAndView searchCompanyDetails(HttpServletRequest request, HttpServletResponse response,
			@PathVariable(value = "qString") String qString) {
		ModelAndView model = new ModelAndView();
		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<>();

		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		try {
			Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			model.addObject("companyDetailsDtoList", companyServiceManager.searchCompanyDetails(companyId, qString));

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: companyRecharge", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In WalletController companyRecharge Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		flowData.setSessionData(WebAppConstants.ISLOGEDIN, "true");
		model = super.getCommonSessionData(flowData, model);
		if (model == null) {
			return super.loginPage(flowData, request);
		}

		model.addObject("qString", qString);
		model.setViewName("companyRecharge");
		return model;

	}
	
	
	@GetMapping("/searchOnWalletTran/{qString}")
	public ModelAndView searchOnWalletTran(HttpServletRequest request, HttpServletResponse response,
			@PathVariable(value = "qString") String qString) {
		ModelAndView model = new ModelAndView();
		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<>();

		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		try {
			Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			model.addObject("companyDetailsDtoList", companyServiceManager.searchCompanyDetails(companyId, qString));

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: walletTransaction", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In WalletController walletTransaction Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		flowData.setSessionData(WebAppConstants.ISLOGEDIN, "true");
		model = super.getCommonSessionData(flowData, model);
		if (model == null) {
			return super.loginPage(flowData, request);
		}
		model.addObject("qString", qString);
		model.setViewName("walletTransaction");
		return model;

	}


	@GetMapping("/searchOnAllCompany/{qString}")
	public ModelAndView searchOnAllCompany(HttpServletRequest request, HttpServletResponse response,
			@PathVariable(value = "qString") String qString) {
		ModelAndView model = new ModelAndView();
		model.setViewName("get-all-company-details");
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);
			Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			model.addObject("companyDetailsList", companyServiceManager.searchCompanyDetails(companyId, qString));

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in CompanyController: searchOnAllCompany", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In CompanyController searchOnAllCompany Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("qString", qString);
		return model;

	}


}
