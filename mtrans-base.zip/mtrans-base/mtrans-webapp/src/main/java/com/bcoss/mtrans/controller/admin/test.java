package com.bcoss.mtrans.controller.admin;

import java.util.Date;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(new Date());
	}

}
