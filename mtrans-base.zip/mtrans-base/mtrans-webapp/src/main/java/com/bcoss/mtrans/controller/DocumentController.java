package com.bcoss.mtrans.controller;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.bcoss.mtrans.dto.EmployeeDocumentDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.service.IDocumentService;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@RestController
@RequestMapping("/document")
public class DocumentController extends BaseController {

	Logger logger = LoggerFactory.getLogger(DocumentController.class);

	@Autowired
	private IDocumentService documentServiceImpl;

	@GetMapping(value = "/{companyId}")
	public ModelAndView employeeDocument(HttpServletRequest request, HttpServletResponse response,
			@PathVariable("companyId")Integer companyId) {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;

		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		model = super.getCommonSessionData(flowData, model);
		List<EmployeeDocumentDto> employeeDocumentList = new ArrayList<EmployeeDocumentDto>();
		try {
			employeeDocumentList = documentServiceImpl.getAllEmployeeDocument(companyId);
			model.addObject("employeeDocumentList", employeeDocumentList);
			model.addObject("companyId", companyId);
			model.setViewName("employeeDocument");

		} catch (HelthwellExceptionHandler e) {
			logger.error("Error in DocumentController- > getAllEmployeeDocument", e);
		} catch (Exception e) {
			logger.error("Error in DocumentController- > getAllEmployeeDocument", e);
		}

		return model;
	}

	@GetMapping(value = "/addEmployeeDocument/{companyId}")
	public ModelAndView addEmployee( HttpServletRequest request,
			HttpServletResponse response,@PathVariable("companyId")Integer companyId) {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;

		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		model = super.getCommonSessionData(flowData, model);
		
		EmployeeDocumentDto employeeDocumentDto=new EmployeeDocumentDto();
		employeeDocumentDto.setCompanyId(companyId);
		model.addObject("employeeDocumentDto", employeeDocumentDto);
		model.setViewName("addEmployeeDocument");		
		return model;
	}

	@RequestMapping(value = "/saveEmployeeDocument", method = RequestMethod.POST)
	public ModelAndView saveEmployeeDocument(@ModelAttribute("employeeDocumentDto") EmployeeDocumentDto employeeDocumentDto, HttpServletRequest request,
			HttpServletResponse response, @RequestParam("file") MultipartFile file) {
		logger.info("DocumentController: saveEmployee Method Start.");
		ModelAndView mv = new ModelAndView();
		FlowData flowData = null;

		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		mv = super.getCommonSessionData(flowData, mv);
		List<EmployeeDocumentDto> employeeDocumentList = new ArrayList<EmployeeDocumentDto>();

		String sucessMessage = "";
		Boolean result = false;
		if (!file.isEmpty()) {
			try {
				// String filePath = getServletContext().getRealPath("/");

				byte[] bytes = file.getBytes();
				String filename = file.getOriginalFilename();
				String extension = filename.split(Pattern.quote("."))[1];
				employeeDocumentDto.setData(bytes);
				employeeDocumentDto.setExtension(extension);
			} catch (Exception e) {
			}
		}
		try {

			result = documentServiceImpl.addEmployeeDocument(employeeDocumentDto);
			if (result == true)
				sucessMessage = "Add  Document Successfully";

			employeeDocumentList = documentServiceImpl.getAllEmployeeDocument(employeeDocumentDto.getCompanyId());
			sucessMessage = "Save Employee Successfully.";
			mv.addObject("employeeDocumentList", employeeDocumentList);
			mv.setViewName("employeeDocument");
			mv.addObject("sucessMessage", sucessMessage);
			mv.addObject(WebAppConstants.SUCESS_MESSAGE, sucessMessage);

			mv.addObject("employeeId", employeeDocumentDto.getCompanyId());
		} catch (Exception e) {
			logger.error("Exception In DocumentController saveCustomer Method--", e);
			mv.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}

		return mv;
	}
	
	@GetMapping(value = "/deleteEmployeeDocument/{emploeeDocumentId}/{companyId}")
	public ModelAndView deleteEmployeeAttendance(HttpServletRequest request, HttpServletResponse response,
			@PathVariable("emploeeDocumentId")Integer emploeeDocumentId,
			@PathVariable("companyId")Integer companyId) {

		logger.info("DocumentController: deleteEmployeeDocument Method Start.");
		String sucessMessage = "";
		
		ModelAndView mv = new ModelAndView("employeeDocument");
		
		FlowData flowData = null;

		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		List<EmployeeDocumentDto> employeeDocumentList = new ArrayList<EmployeeDocumentDto>();

		try {
			mv = super.getCommonSessionData(flowData, mv);
			documentServiceImpl.deleteEmployeeDocument(emploeeDocumentId);
			sucessMessage = "Delete Employee Document Successfully.";
			mv.addObject("sucessMessage", sucessMessage);
			employeeDocumentList = documentServiceImpl.getAllEmployeeDocument(companyId);
			mv.addObject("employeeDocumentList", employeeDocumentList);
			mv.setViewName("employeeDocument");
			mv.addObject("companyId", companyId);
			} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in DocumentController: deleteEmployeeAttendance", _be);
			mv.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In DocumentController deleteEmployee Method--", e);
			mv.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}

		logger.info("DocumentController: deleteEmployeeAttendance Method End.");
		return mv;

	}
	

@RequestMapping(value = "/downloadCustomerDocument", method = RequestMethod.GET)
	public void downloadCustomerDocument(HttpServletRequest request,
			HttpServletResponse response) {
			
		logger.info("customer controller: addCustomerDocument Method Start.");

		  final int BUFFER_SIZE = 4096;
		  String fileUploadPath = System.getProperty("user.dir");
		  Integer documentId=Integer.parseInt( request.getParameter("documentId"));
		
		
        try {
			
        	 EmployeeDocumentDto employeeDocumentDto = documentServiceImpl.getEmployeeDocumentById(documentId);
			
        	String customerDocument=employeeDocumentDto.getUri();
        	
        	String fullPath = fileUploadPath+customerDocument;
    		File downloadFile = new File(fullPath);
        	
			FileInputStream inputStream = new FileInputStream(downloadFile);
			 String mimeType = "application/octet-stream";
	        System.out.println("MIME type: " + mimeType);
	 
	        // set content attributes for the response
	        response.setContentType(mimeType);
	        response.setContentLength((int) downloadFile.length());
	 
	        // set headers for the response
	        String headerKey = "Content-Disposition";
	        String headerValue = String.format("attachment; filename=\"%s\"",
	                downloadFile.getName());
	        response.setHeader(headerKey, headerValue);
	 
	        // get output stream of the response
	        OutputStream outStream = response.getOutputStream();
	 
	        byte[] buffer = new byte[BUFFER_SIZE];
	        int bytesRead = -1;
	 
	        while ((bytesRead = inputStream.read(buffer)) != -1) {
	            outStream.write(buffer, 0, bytesRead);
	        }
	 
	        inputStream.close();
	        outStream.close();
		}catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in DocumentController: deleteEmployeeAttendance", _be);
			//mv.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} 
        catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		logger.info("CustomerController: addCustomerDocument Method End.");
	}


}
