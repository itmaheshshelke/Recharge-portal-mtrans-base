package com.bcoss.mtrans.controller.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bcoss.mtrans.CompanyDetailsDto;

/**
 * Created by Mahesh Shelke on 30/09/18.
 */

public class UserReportExcel {

	static Logger logger = LoggerFactory.getLogger(LiveReportExcel.class);
	
	private static String[] columns = { "Sr.No",  "Company Name", "Company Type", "Balance","Email-Id","Contact No","Address",
			"Status"};

	public static String UserReport(List<CompanyDetailsDto> companyDetailsList,String companyName)
			throws IOException, InvalidFormatException {

		
		String fileUploadPath="C://excel//";
		File file1 = new File(fileUploadPath);
		if (!file1.exists()) {
			if (file1.mkdirs()) {
				logger.info("Directory is created!");
			} else {
				logger.info("Failed to create directory!");
			}
		}
		String path=file1+File.separator +companyName+"-under-user-report.xlsx";
	
		
		
		// Create a Workbook
		Workbook workbook = new XSSFWorkbook(); // new HSSFWorkbook() for generating `.xls` file

		/*
		 * CreationHelper helps us create instances for various things like DataFormat,
		 * Hyperlink, RichTextString etc in a format (HSSF, XSSF) independent way
		 */
		CreationHelper createHelper = workbook.getCreationHelper();
		
		// Create a Sheet
		Sheet sheet = workbook.createSheet(companyName+"-under-user-report");

		// Create a Font for styling header cells
		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setFontHeightInPoints((short) 14);
		headerFont.setColor(IndexedColors.RED.getIndex());

		// Create a CellStyle with the font
		CellStyle headerCellStyle = workbook.createCellStyle();
		headerCellStyle.setFont(headerFont);

		// Create a Row
		Row headerRow = sheet.createRow(0);

		// Creating cells
		for (int i = 0; i < columns.length; i++) {
			Cell cell = headerRow.createCell(i);
			cell.setCellValue(columns[i]);
			cell.setCellStyle(headerCellStyle);
		}

		// Cell Style for formatting Date
		CellStyle dateCellStyle = workbook.createCellStyle();
		dateCellStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd-MM-yyyy : HH-MM-SS"));

		// Create Other rows and cells with employees data
		int rowNum = 1;
		Integer srNo = 1;
		for (CompanyDetailsDto companyDetailsDto : companyDetailsList) {
			Row row = sheet.createRow(rowNum++);

			row.createCell(0).setCellValue(srNo);
			row.createCell(1).setCellValue(companyDetailsDto.getCompanyName());
			
			String type = "";
			if (companyDetailsDto.getCompanyType() == 1) {
				type = "Master";
			} else if (companyDetailsDto.getCompanyType() == 3) {
				type = "Distributor";
			} else {
				type = "Retailer";
			}
			row.createCell(2).setCellValue(type);
			String status = "";
			if (companyDetailsDto.getIsActive() == 1) {
				status = "Active";
				} else {
					status = "De-Active";
			}
			if(companyDetailsDto.getBalance()!=null) {
			row.createCell(3).setCellValue(companyDetailsDto.getBalance());
			}else {
				row.createCell(3).setCellValue(0.0);
			}
			row.createCell(4).setCellValue(companyDetailsDto.getEmailId());
			row.createCell(5).setCellValue(companyDetailsDto.getContactNo());
			row.createCell(6).setCellValue(companyDetailsDto.getCity()+" , "+companyDetailsDto.getAddress());
			row.createCell(7).setCellValue(status);

			srNo++;
		}

		// Resize all columns to fit the content size
		for (int i = 0; i < columns.length; i++) {
			sheet.autoSizeColumn(i);
		}
		
		// Write the output to a file
		FileOutputStream fileOut = new FileOutputStream(path);
		workbook.write(fileOut);
		fileOut.close();

		workbook.close();
		return path;
	}

	
}
