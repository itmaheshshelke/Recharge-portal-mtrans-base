package com.bcoss.mtrans.controller.admin;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.bcoss.mtrans.controller.BaseController;
import com.bcoss.mtrans.dto.CompanyMargineDto;
import com.bcoss.mtrans.dto.MargineDto;
import com.bcoss.mtrans.dto.PlansDto;
import com.bcoss.mtrans.dto.ServiceOperatorsDto;
import com.bcoss.mtrans.dto.ServicesDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.service.CompanyMargineServiceManager;
import com.bcoss.mtrans.service.PlansServiceManager;
import com.bcoss.mtrans.service.ServiceOpertaorsServiceManager;
import com.bcoss.mtrans.service.ServicesServiceManager;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@RestController
@RequestMapping("/company_margine")
public class CompanyMargineController extends BaseController {
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(CompanyMargineController.class);

	@Autowired
	private ServicesServiceManager servicesServiceManager;
		
	@Autowired
	private ServiceOpertaorsServiceManager serviceOpertaorsServiceManager;
	
	@Autowired
	private PlansServiceManager plansServiceManager;
	@Autowired
	private CompanyMargineServiceManager companyMargineServiceManager;

	@GetMapping(value = "/")
	public ModelAndView getAllPlans(HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		List<PlansDto> plansDtoList=new ArrayList<PlansDto>();
		try {
			model = super.getCommonSessionData(flowData, model);
			plansDtoList=plansServiceManager.getAllPlans();
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in HomeController: dashboard", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController dashboard Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.addObject("marginDto", new CompanyMargineDto());
		model.addObject("servicesDtoList", servicesDtoList);
		model.addObject("plansDtoList", plansDtoList);
		model.setViewName("dashboard");
		return model;
	}
	
	
	
	@GetMapping(value = "/get-all-services-by-plan-id/{id}")
	public ModelAndView getAllServicesByPlanId(@PathVariable("id")Integer planId,
			HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		List<PlansDto> plansDtoList=new ArrayList<PlansDto>();
		try {
			model = super.getCommonSessionData(flowData, model);
			marginDto.setPlanId(planId);
			
			servicesDtoList = servicesServiceManager.getAllServices(planId);
			plansDtoList=plansServiceManager.getAllPlans();
			model.addObject("employeeDto", flowData.getSessionDataObject(WebAppConstants.EMPLOYEE));
			
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in HomeController: getAllServicesByPlanId", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController getAllServicesByPlanId Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.addObject("marginDto",marginDto);
		model.addObject("plansDtoList",plansDtoList);
		model.addObject("servicesDtoList", servicesDtoList);
		model.setViewName("show-comapny-margine");
		return model;
	}
	@GetMapping(value = "/get-operator-by-service-id/{id}/{planId}")
	public ModelAndView getOperatorByServiceId(@PathVariable("id")Integer serviceId,
			@PathVariable("planId")Integer planId,HttpServletRequest request, HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		List<ServiceOperatorsDto> serviceOperatorsDtoList = new ArrayList<ServiceOperatorsDto>();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		List<PlansDto> plansDtoList=new ArrayList<PlansDto>();
		List<CompanyMargineDto>companyMargineDtoList=new ArrayList<CompanyMargineDto>();
		try {
			
			model = super.getCommonSessionData(flowData, model);
			marginDto.setServiceId(serviceId);
			marginDto.setPlanId(planId);
			Integer margineType=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE));
			Integer companyId=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			serviceOperatorsDtoList = serviceOpertaorsServiceManager.getOperatorByServiceId(serviceId);
			servicesDtoList = servicesServiceManager.getAllServices(planId);
			plansDtoList=plansServiceManager.getAllPlans();
			companyMargineDtoList=companyMargineServiceManager.getAllCompanyMargineByMargineType(margineType,companyId,serviceId);
			//margineDtoList=companyMargineServiceManager.getMargineData(margineType,companyId);
		} catch (HelthwellExceptionHandler _be) { 
			logger.error("Exception in HomeController: getOperatorByServiceId", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController getOperatorByServiceId Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("plansDtoList",plansDtoList);
		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.addObject("marginDto",marginDto);
		model.addObject("companyMargineDtoList",companyMargineDtoList);
		model.addObject("servicesDtoList", servicesDtoList);
		model.addObject("serviceOperatorsDtoList", serviceOperatorsDtoList);
		model.setViewName("dashboard");
		return model;
	}
	
	
	
	
	
	@GetMapping(value = "/get-all-services-by-partner-margine")
	public ModelAndView getAllServicesByPartnerMargine( HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);
			Integer planId=1;
			marginDto.setPlanId(planId);
			
			servicesDtoList = servicesServiceManager.getAllServices(planId);
			
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in HomeController: getAllServicesByPartnerMargine", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController getAllServicesByPartnerMargine Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("marginDto",marginDto);
		model.addObject("servicesDtoList", servicesDtoList);
		model.setViewName("show-partner-margine");
		return model;
	}
	
	
	@GetMapping(value = "/get-partner-margine-operator-by-service-id/{id}")
	public ModelAndView getPartnerMargineOperatorByServiceId(@PathVariable("id")Integer serviceId,HttpServletRequest request,
			HttpServletResponse response
			) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		Integer companyId=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
		//List<ServiceOperatorsDto> serviceOperatorsDtoList = new ArrayList<ServiceOperatorsDto>();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		List<CompanyMargineDto>companyMargineDtoList=new ArrayList<CompanyMargineDto>();
		try {
			model = super.getCommonSessionData(flowData, model);
			Integer margineType=2;
			Integer planId=1;
			marginDto.setServiceId(serviceId);
			marginDto.setPlanId(planId);
			//serviceOperatorsDtoList = serviceOpertaorsServiceManager.getOperatorByServiceId(serviceId);
			servicesDtoList = servicesServiceManager.getAllServices(planId);
			companyMargineDtoList=companyMargineServiceManager.getAllCompanyMargineByMargineType(margineType,companyId,serviceId);
			
		} catch (HelthwellExceptionHandler _be) { 
			logger.error("Exception in HomeController: getOperatorByServiceId", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController getOperatorByServiceId Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("companyMargineDtoList",companyMargineDtoList);
		model.addObject("marginDto",marginDto);
		model.addObject("servicesDtoList", servicesDtoList);
		model.setViewName("show-partner-margine");
		return model;
	}
	
	@GetMapping(value = "/add-partner-margine")
	public ModelAndView addPartnerMargine(HttpServletRequest request,HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			
			model = super.getCommonSessionData(flowData, model);
			Integer planId=1;
			marginDto.setPlanId(planId);
			
			servicesDtoList = servicesServiceManager.getAllServices(planId);
			
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in HomeController: addPartnerMargine", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController addPartnerMargine Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("marginDto",marginDto);
		model.addObject("servicesDtoList", servicesDtoList);
		model.setViewName("add-partner-margine");
		return model;
	}
	
	
	@GetMapping(value = "/partner-margine-operator-by-service-id/{id}")
	public ModelAndView getPartnerMargineOperatorsByServiceId(@PathVariable("id")Integer serviceId,HttpServletRequest request,HttpServletResponse response
			) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<ServiceOperatorsDto> serviceOperatorsDtoList = new ArrayList<ServiceOperatorsDto>();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		List<CompanyMargineDto>companyMargineDtoList=new ArrayList<CompanyMargineDto>();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		Integer companyId=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
		
		try {
			
			model = super.getCommonSessionData(flowData, model);
			Integer margineType=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE));
			Integer planId=1;
			marginDto.setServiceId(serviceId);
			marginDto.setPlanId(planId);
			serviceOperatorsDtoList = serviceOpertaorsServiceManager.getOperatorByServiceId(serviceId);
			servicesDtoList = servicesServiceManager.getAllServices(planId);
			companyMargineDtoList=companyMargineServiceManager.getAllCompanyMargineByMargineType(margineType,companyId,serviceId);
			
		} catch (HelthwellExceptionHandler _be) { 
			logger.error("Exception in HomeController: getPartnerMargineOperatorsByServiceId", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController getPartnerMargineOperatorsByServiceId Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("companyMargineDtoList",companyMargineDtoList);
		model.addObject("marginDto",marginDto);
		model.addObject("servicesDtoList", servicesDtoList);
		model.addObject("serviceOperatorsDtoList", serviceOperatorsDtoList);
		model.setViewName("add-partner-margine");
		return model;
	}
	
	@GetMapping(value = "/add-distribuitor-margine")
	public ModelAndView addDistribuitorMargine(HttpServletRequest request,HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);
			Integer planId=1;
			marginDto.setPlanId(planId);
			
			servicesDtoList = servicesServiceManager.getAllServices(planId);
			
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in HomeController: addDistribuitorMargine", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController addDistribuitorMargine Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("marginDto",marginDto);
		model.addObject("servicesDtoList", servicesDtoList);
		model.setViewName("add-distribuitor-margine");
		return model;
	}
	
	
	@GetMapping(value = "/distribuitor-margine-operator-by-service-id/{id}")
	public ModelAndView getDistribuitorOperatorsByServiceId(@PathVariable("id")Integer serviceId,HttpServletRequest request,HttpServletResponse response
			) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<ServiceOperatorsDto> serviceOperatorsDtoList = new ArrayList<ServiceOperatorsDto>();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		List<CompanyMargineDto>companyMargineDtoList=new ArrayList<CompanyMargineDto>();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		Integer companyId=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
		try {
			
			model = super.getCommonSessionData(flowData, model);
			Integer margineType=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE));
			Integer planId=1;
			marginDto.setServiceId(serviceId);
			marginDto.setPlanId(planId);
			serviceOperatorsDtoList = serviceOpertaorsServiceManager.getOperatorByServiceId(serviceId);
			servicesDtoList = servicesServiceManager.getAllServices(planId);
			companyMargineDtoList=companyMargineServiceManager.getAllCompanyMargineByMargineType(margineType,companyId,serviceId);
			
		} catch (HelthwellExceptionHandler _be) { 
			logger.error("Exception in HomeController: getDistribuitorOperatorsByServiceId", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController getDistribuitorOperatorsByServiceId Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("companyMargineDtoList",companyMargineDtoList);
		model.addObject("marginDto",marginDto);
		model.addObject("servicesDtoList", servicesDtoList);
		model.addObject("serviceOperatorsDtoList", serviceOperatorsDtoList);
		model.setViewName("add-distribuitor-margine");
		return model;
	}
	
	
	@GetMapping(value = "/add-retailer-margine")
	public ModelAndView addRetailerMargine(HttpServletRequest request,HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);
			Integer planId=1;
			marginDto.setPlanId(planId);
			
			servicesDtoList = servicesServiceManager.getAllServices(planId);
			
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in HomeController: addRetailerMargine", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController addRetailerMargine Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("marginDto",marginDto);
		model.addObject("servicesDtoList", servicesDtoList);
		model.setViewName("add-retailer-margine");
		return model;
	}
	
	
	@GetMapping(value = "/retailer-margine-operator-by-service-id/{id}")
	public ModelAndView getRetailerOperatorsByServiceId(@PathVariable("id")Integer serviceId,HttpServletRequest request,HttpServletResponse response
			) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<ServiceOperatorsDto> serviceOperatorsDtoList = new ArrayList<ServiceOperatorsDto>();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		List<CompanyMargineDto>companyMargineDtoList=new ArrayList<CompanyMargineDto>();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		Integer companyId=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
		try {
			
			model = super.getCommonSessionData(flowData, model);
			Integer margineType=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE));
			Integer planId=1;
			marginDto.setServiceId(serviceId);
			marginDto.setPlanId(planId);
			serviceOperatorsDtoList = serviceOpertaorsServiceManager.getOperatorByServiceId(serviceId);
			servicesDtoList = servicesServiceManager.getAllServices(planId);
			companyMargineDtoList=companyMargineServiceManager.getAllCompanyMargineByMargineType(margineType,companyId,serviceId);
			
		} catch (HelthwellExceptionHandler _be) { 
			logger.error("Exception in HomeController: getRetailerOperatorsByServiceId", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController getRetailerOperatorsByServiceId Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("companyMargineDtoList",companyMargineDtoList);
		model.addObject("marginDto",marginDto);
		model.addObject("servicesDtoList", servicesDtoList);
		model.addObject("serviceOperatorsDtoList", serviceOperatorsDtoList);
		model.setViewName("add-retailer-margine");
		return model;
	}
	

	
	@GetMapping(value = "/get-all-services-by-distribuitor-margine")
	public ModelAndView getAllServicesByDistribuitorMargine(HttpServletRequest request,HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			
			model = super.getCommonSessionData(flowData, model);
			Integer planId=1;
			marginDto.setPlanId(planId);
			
			servicesDtoList = servicesServiceManager.getAllServices(planId);
			
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in HomeController: getAllServicesByDistribuitorMargine", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController getAllServicesByDistribuitorMargine Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("marginDto",marginDto);
		model.addObject("servicesDtoList", servicesDtoList);
		model.setViewName("show-distribuitor-margine");
		return model;
	}
	
	
	@GetMapping(value = "/get-distribuitor-margine-operator-by-service-id/{id}")
	public ModelAndView getDistribuitorMargineOperatorByServiceId(@PathVariable("id")Integer serviceId,HttpServletRequest request,HttpServletResponse response
			) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<ServiceOperatorsDto> serviceOperatorsDtoList = new ArrayList<ServiceOperatorsDto>();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		List<CompanyMargineDto>companyMargineDtoList=new ArrayList<CompanyMargineDto>();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		Integer companyId=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
		try {
			
			model = super.getCommonSessionData(flowData, model);
			Integer margineType=3;
			Integer planId=1;
			marginDto.setServiceId(serviceId);
			marginDto.setPlanId(planId);
			serviceOperatorsDtoList = serviceOpertaorsServiceManager.getOperatorByServiceId(serviceId);
			servicesDtoList = servicesServiceManager.getAllServices(planId);
			companyMargineDtoList=companyMargineServiceManager.getAllCompanyMargineByMargineType(margineType,companyId,serviceId);
		} catch (HelthwellExceptionHandler _be) { 
			logger.error("Exception in HomeController: getDistribuitorMargineOperatorByServiceId", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController getDistribuitorMargineOperatorByServiceId Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("companyMargineDtoList",companyMargineDtoList);
		model.addObject("marginDto",marginDto);
		model.addObject("servicesDtoList", servicesDtoList);
		model.addObject("serviceOperatorsDtoList", serviceOperatorsDtoList);
		model.setViewName("show-distribuitor-margine");
		return model;
	}
	
	
	@GetMapping(value = "/get-all-services-by-retailer-margine")
	public ModelAndView getAllServicesByRetailerMargine(HttpServletRequest request,HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		try {
			
			model = super.getCommonSessionData(flowData, model);
			Integer planId=1;
			marginDto.setPlanId(planId);
			
			servicesDtoList = servicesServiceManager.getAllServices(planId);
			
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in HomeController: getAllServicesByRetailerMargine", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController getAllServicesByRetailerMargine Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("marginDto",marginDto);
		model.addObject("servicesDtoList", servicesDtoList);
		model.setViewName("show-retailer-margine");
		return model;
	}
	
	
	@GetMapping(value = "/get-retailer-margine-operator-by-service-id/{id}")
	public ModelAndView getRetailerMargineOperatorByServiceId(@PathVariable("id")Integer serviceId,HttpServletRequest request,HttpServletResponse response
			) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<ServiceOperatorsDto> serviceOperatorsDtoList = new ArrayList<ServiceOperatorsDto>();
		List<ServicesDto> servicesDtoList = new ArrayList<ServicesDto>();
		CompanyMargineDto marginDto=new CompanyMargineDto();
		List<MargineDto>margineDtoList=new ArrayList<MargineDto>();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		List<CompanyMargineDto>companyMargineDtoList=new ArrayList<CompanyMargineDto>();
		try {
			Integer companyId=Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			model = super.getCommonSessionData(flowData, model);
			Integer margineType=4;
			Integer planId=1;
			marginDto.setServiceId(serviceId);
			marginDto.setPlanId(planId);
			serviceOperatorsDtoList = serviceOpertaorsServiceManager.getOperatorByServiceId(serviceId);
			servicesDtoList = servicesServiceManager.getAllServices(planId);
			companyMargineDtoList=companyMargineServiceManager.getAllCompanyMargineByMargineType(margineType,companyId,serviceId);
			//margineDtoList=companyMargineServiceManager.getMargineData(margineType, serviceId);
		} catch (HelthwellExceptionHandler _be) { 
			logger.error("Exception in HomeController: getDistribuitorMargineOperatorByServiceId", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In HomeController getDistribuitorMargineOperatorByServiceId Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("companyMargineDtoList",companyMargineDtoList);
		model.addObject("marginDto",marginDto);
		model.addObject("servicesDtoList", servicesDtoList);
		model.addObject("serviceOperatorsDtoList", serviceOperatorsDtoList);
		model.setViewName("show-retailer-margine");
		return model;
	}
	
	
	
	
	@GetMapping(value = "/get-all-margine-by-company-id")
	public ModelAndView getAllCompanyMargineBycompanyId(HttpServletRequest request,HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<CompanyMargineDto> companyMargineDtoList = new ArrayList<CompanyMargineDto>();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			
			model = super.getCommonSessionData(flowData, model);
			Integer companyId=1;
			companyMargineDtoList = companyMargineServiceManager.getAllCompanyMargineBycompanyId(companyId);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in CompanyMargineController: getAllCompanyMargine", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In CompanyMargineController getAllCompanyMargine Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("companyMargineDtoList", companyMargineDtoList);
		model.setViewName("companyMargine");
		return model;
	}
	
	
	@GetMapping(value = "/addCompanyMargine")
	public ModelAndView addCompanyMargine(HttpServletRequest request,HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		
		model = super.getCommonSessionData(flowData, model);
		CompanyMargineDto companyMargineDto = new CompanyMargineDto();
		model.addObject("companyMargineDto", companyMargineDto);
		model.setViewName("addCompanyMargine");
		return model;
	}
	
	@GetMapping(value = "/{companyMargineId}")
	public ModelAndView getcompanyMargineById(@PathVariable("companyMargineId") Integer companyMargineId,HttpServletRequest request,HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		CompanyMargineDto companyMargineDto = new CompanyMargineDto();
		
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			model = super.getCommonSessionData(flowData, model);
			companyMargineDto = companyMargineServiceManager.getcompanyMargineById(companyMargineId);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in CompanyMargineController: getcompanyMargineById", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In CompanyMargineController getcompanyMargineById Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("companyMargineDto", companyMargineDto);
		model.setViewName("addCompanyMargine");
		return model;
	}
	
	@PostMapping(value = "/update-margine")
	public @ResponseBody CompanyMargineDto saveCompanyMargine(@RequestBody CompanyMargineDto companyMargineDto, HttpServletRequest request,
			HttpServletResponse response) {
			Boolean result = false;
			
			super.handleRequestInternal(request, response);
			FlowData flowData = null;
			if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
				flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
			}
		try {
			
			companyMargineDto.setCompanyId(Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID)));
			companyMargineDto.setType(2);
			companyMargineDto.setPlanId(1);
			result = companyMargineServiceManager.saveCompanyMargine(companyMargineDto);
			

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in CompanyMargineController: saveCompanyMargine", _be);
		} catch (Exception e) {
			logger.error("Exception In CompanyMargineController saveCompanyMargine Method--", e);
		}

		return companyMargineDto;
	}

}
