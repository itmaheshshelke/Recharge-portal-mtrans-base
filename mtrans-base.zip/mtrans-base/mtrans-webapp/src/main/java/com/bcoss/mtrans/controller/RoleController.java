package com.bcoss.mtrans.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.bcoss.mtrans.RoleDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.service.RoleServiceManager;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@Controller
@RequestMapping("/role")
public class RoleController extends BaseController{

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(RoleController.class);

	@Autowired
	RoleServiceManager roleServiceManager;

	
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView getAllRole(HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<RoleDto> roleDtoList =null;
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			roleDtoList = roleServiceManager.getAllRole();

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in RoleController: getRoleById", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In RoleController getRoleById Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("roleDtoList", roleDtoList);
		model.setViewName("role");
		model = super.getCommonSessionData(flowData, model);
		
		return model;
	}
	
	@RequestMapping(value = "/{roleId}", method = RequestMethod.GET)
	public ModelAndView getRoleById(@PathVariable("roleId") Integer roleId, HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		RoleDto roleDto = new RoleDto();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		try {
			roleDto = roleServiceManager.getRoleById(roleId);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in RoleController: getRoleById", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In RoleController getRoleById Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("roleDto", roleDto);
		model.setViewName("addrole");
		model = super.getCommonSessionData(flowData, model);
		
		return model;
	}

		
}
