package com.bcoss.mtrans.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.bcoss.mtrans.DistrictDto;
import com.bcoss.mtrans.EmployeeDto;
import com.bcoss.mtrans.RoleDto;
import com.bcoss.mtrans.StateDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.service.EmployeeServiceManager;
import com.bcoss.mtrans.service.RoleServiceManager;
import com.bcoss.mtrans.service.StateServiceManager;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@RestController
@RequestMapping("/employee")
public class EmployeeController extends BaseController {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(EmployeeController.class);

	@Autowired
	EmployeeServiceManager employeeServiceManager;
	
	@Autowired
	RoleServiceManager roleServiceManager;
	
	@Autowired
	StateServiceManager stateServiceManager;

	@GetMapping(value = "/")
	public ModelAndView getAllEmployee(HttpServletRequest request, HttpServletResponse response)
			throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		List<EmployeeDto> employeeDtoList = new ArrayList<EmployeeDto>();

		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		try {
			model = super.getCommonSessionData(flowData, model);
			if (model == null) {
				return super.loginPage(flowData, request);
			}

			Integer companyId =Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			employeeDtoList = employeeServiceManager.getAllEmployee(companyId);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in EmployeeController: getAllEmployee", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In EmployeeController getAllEmployee Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		flowData.setSessionData(WebAppConstants.ISLOGEDIN, "true");
		
		model.addObject("employeeDtoList", employeeDtoList);
		model.setViewName("employee");
		model = super.getCommonSessionData(flowData, model);
		return model;
	}

	@GetMapping(value = "/addemployee")
	public ModelAndView addemployee(HttpServletRequest request, HttpServletResponse response)
			throws HelthwellExceptionHandler {

		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		ModelAndView model = new ModelAndView();
		EmployeeDto employeeDto = new EmployeeDto();
		
		List<RoleDto> roleDtoList = new ArrayList<RoleDto>();
		List<DistrictDto> districtDtoList = new ArrayList<DistrictDto>();
		List<StateDto> stateDtoList = new ArrayList<StateDto>();

		try {
			Integer stateId = 1;
			stateDtoList = stateServiceManager.getAllState();
			districtDtoList = stateServiceManager.getAllDistrict(stateId);
			roleDtoList = roleServiceManager.getAllRole();
			
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in RoleController: getRoleById", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In RoleController getRoleById Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		

		flowData.setSessionData(WebAppConstants.ISLOGEDIN, "true");
		model = super.getCommonSessionData(flowData, model);
		if (model == null) {
			return super.loginPage(flowData, request);
		}
		
		model.addObject("roleDtoList", roleDtoList);
		model.addObject("stateDtoList", stateDtoList);
		model.addObject("districtDtoList", districtDtoList);
		
		model.setViewName("addemployee");
		model = super.getCommonSessionData(flowData, model);
		model.addObject("employeeDto", employeeDto);
		return model;
	}

	@GetMapping(value = "/{employeeId}")
	public ModelAndView getEmployeeById(@PathVariable("employeeId") Integer employeeId, HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();

		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		EmployeeDto employeeDto = new EmployeeDto();
		List<RoleDto> roleDtoList = new ArrayList<RoleDto>();
		List<DistrictDto> districtDtoList = new ArrayList<DistrictDto>();
		List<StateDto> stateDtoList = new ArrayList<StateDto>();
		try {
			employeeDto = employeeServiceManager.getEmployeeById(employeeId);
			stateDtoList = stateServiceManager.getAllState();
			districtDtoList = stateServiceManager.getAllDistrict(employeeDto.getStateId());
			roleDtoList = roleServiceManager.getAllRole();
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in EmployeeController: getEmployeeById", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In EmployeeController getEmployeeById Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}

		flowData.setSessionData(WebAppConstants.ISLOGEDIN, "true");
		model = super.getCommonSessionData(flowData, model);
		if (model == null) {
			return super.loginPage(flowData, request);
		}
		model.addObject("roleDtoList", roleDtoList);
		model.addObject("stateDtoList", stateDtoList);
		model.addObject("districtDtoList", districtDtoList);
		model.addObject("employeeDto", employeeDto);
		model.setViewName("addemployee");
		model = super.getCommonSessionData(flowData, model);
		
		return model;
	}

	@PostMapping(value = "/saveEmployee")
	public ModelAndView saveEmployee(@ModelAttribute("employeeDto") EmployeeDto employeeDto, HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		List<EmployeeDto> employeeDtoList = new ArrayList<EmployeeDto>();
		Boolean result = false;

		try {
			Integer companyId =Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			Integer employeeId = Integer.parseInt(flowData.getSessionData(WebAppConstants.EMPLOYEEID));
			employeeDto.setCreatedBy(employeeId);
			employeeDto.setCompanyId(companyId);

			if (employeeDto.getEmployeeId() != null)
				employeeDto.setUpdatedBy(employeeId);

			result = employeeServiceManager.saveEmployee(employeeDto);

			employeeDtoList = employeeServiceManager.getAllEmployee(companyId);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in EmployeeController: saveEmployee", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In EmployeeController saveEmployee Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}

		flowData.setSessionData(WebAppConstants.ISLOGEDIN, "true");
		model = super.getCommonSessionData(flowData, model);
		if (model == null) {
			return super.loginPage(flowData, request);
		}

		if (result == true)
			model.addObject("sucessMessage", "Record Update Succesfully");

		model.addObject("employeeDtoList", employeeDtoList);
		model.setViewName("employee");
		return model;
	}

	@DeleteMapping(value = "/deleteEmployee/{employeeId}")
	public ModelAndView deleteEmployee(@PathVariable("employeeId") Integer employeeId, HttpServletRequest request,
			HttpServletResponse response) throws HelthwellExceptionHandler {

		List<EmployeeDto> employeeDtoList = new ArrayList<EmployeeDto>();
		ModelAndView model = new ModelAndView();

		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		Boolean result = false;
		try {

			result = employeeServiceManager.deleteEmployee(employeeId);

			Integer companyId =Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			employeeDtoList = employeeServiceManager.getAllEmployee(companyId);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in EmployeeController: deleteEmployee", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In EmployeeController deleteEmployee Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		flowData.setSessionData(WebAppConstants.ISLOGEDIN, "true");
		model = super.getCommonSessionData(flowData, model);
		if (model == null) {
			return super.loginPage(flowData, request);
		}

		if (result == true)
			model.addObject("sucessMessage", "Record Update Succesfully");

		model.addObject("employeeDtoList", employeeDtoList);
		model.setViewName("employee");
		model = super.getCommonSessionData(flowData, model);
		
		return model;
	}

}
