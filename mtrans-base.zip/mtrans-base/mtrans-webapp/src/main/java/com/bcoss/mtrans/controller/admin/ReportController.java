package com.bcoss.mtrans.controller.admin;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.bcoss.mtrans.CompanyDetailsDto;
import com.bcoss.mtrans.controller.BaseController;
import com.bcoss.mtrans.dto.CompanyMargineDto;
import com.bcoss.mtrans.dto.DashbordDto;
import com.bcoss.mtrans.dto.LiveTransactionReportDto;
import com.bcoss.mtrans.dto.MargineDto;
import com.bcoss.mtrans.dto.MoneyTransferResponseDto;
import com.bcoss.mtrans.dto.ServiceResponseDto;
import com.bcoss.mtrans.dto.WalletDto;
import com.bcoss.mtrans.dto.WalletTransactionDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.service.CompanyDetailsServiceManager;
import com.bcoss.mtrans.service.ReportServiceManager;
import com.bcoss.mtrans.service.ServicesServiceManager;
import com.bcoss.mtrans.service.WalleterviceManager;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@RestController
@RequestMapping("/report")
public class ReportController extends BaseController {

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(ReportController.class);

	@Autowired
	private ReportServiceManager reportServiceManager;
	@Autowired
	private ServicesServiceManager servicesServiceManager;
	
	@Autowired
	WalleterviceManager walleterviceManager;

	@Autowired
	CompanyDetailsServiceManager companyDetailsServiceImpl;

	@RequestMapping(value = "/show-recharge-history")
	public ModelAndView showRechargeHistory(HttpServletRequest request, HttpServletResponse response,
			@RequestParam Integer pageNumber, @RequestParam Integer pageSize) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		List<ServiceResponseDto> serviceResponseDtoList = new ArrayList<>();
		Map<String, Object> resultListPaginated = null;
		Pageable pageable = new PageRequest(pageNumber - 1, pageSize);
		try {
			model = super.getCommonSessionData(flowData, model);
			Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));

			resultListPaginated = reportServiceManager.showRechargeHistory(companyId,pageable);
			serviceResponseDtoList = (List<ServiceResponseDto>) resultListPaginated.get(WebAppConstants.LIST);
			model.addObject("serviceResponseDtoList", serviceResponseDtoList);
			model.addObject("totalElements", Integer.parseInt(resultListPaginated.get("TOTAL_ELEMENTS").toString()));
			model.addObject("totalPages", Integer.parseInt(resultListPaginated.get("TOTAL_PAGES").toString()));
			model.addObject("pageSize", pageSize);
			model.addObject("currentPage", pageNumber);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ReportController: showRechargeHistory", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In ReportController showRechargeHistory Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		Integer planId = Integer.parseInt(flowData.getSessionData(WebAppConstants.PLANID));
		model.addObject("servicesDtoList", servicesServiceManager.getAllServices(planId));
		model.addObject("url", 1);
		model.addObject("marginDto", new CompanyMargineDto());
		model.setViewName("recharge-history");
		return model;
	}

	@RequestMapping(value = "/show-recharge-report-by-date")
	public ModelAndView showReportByDate(@RequestParam("serviceId") Integer serviceId,
			@RequestParam("startDate") String Sdate, @RequestParam("endDate") String Edate, HttpServletRequest request,
			@RequestParam Integer pageNumber, @RequestParam Integer pageSize, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		List<ServiceResponseDto> serviceResponseDtoList = new ArrayList<>();
		CompanyMargineDto marginDto = new CompanyMargineDto();
		Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
		Map<String, Object> resultListPaginated = null;
		Pageable pageable = new PageRequest(pageNumber - 1, pageSize);
		try {
			model = super.getCommonSessionData(flowData, model);
			marginDto.setServiceId(serviceId);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			
			Date startDate = sdf.parse(Sdate);
			Date endDate = sdf.parse(Edate);
			resultListPaginated = reportServiceManager.showRechargeReportByDate(serviceId, startDate, endDate,
					companyId, pageable);

			serviceResponseDtoList = (List<ServiceResponseDto>) resultListPaginated.get(WebAppConstants.LIST);
			model.addObject("serviceResponseDtoList", serviceResponseDtoList);
			model.addObject("totalElements", Integer.parseInt(resultListPaginated.get("TOTAL_ELEMENTS").toString()));
			model.addObject("totalPages", Integer.parseInt(resultListPaginated.get("TOTAL_PAGES").toString()));
			model.addObject("pageSize", pageSize);
			model.addObject("currentPage", pageNumber);

			Integer planId = Integer.parseInt(flowData.getSessionData(WebAppConstants.PLANID));
			model.addObject("servicesDtoList", servicesServiceManager.getAllServices(planId));
			
			DashbordDto dashbordDto=reportServiceManager.getDashbordData(companyId);
			model.addObject("dashbordDto", dashbordDto);	
			flowData.setSessionDataObject("serviceResponseDtoList", serviceResponseDtoList);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ReportController: showReportByDate", _be);
		} catch (Exception e) {
			logger.error("Exception In ReportController showReportByDate Method--", e);
		}
		if (serviceResponseDtoList.isEmpty()) {
			model.addObject("errormsg", "No record found");

		}
		model.addObject("url", 2);
		
		model.addObject("marginDto", marginDto);
		model.addObject("serviceId", serviceId);
		model.addObject("startDate", Sdate);
		model.addObject("endDate", Edate);
		model.setViewName("recharge-history");
		return model;
	}

	@RequestMapping(value = "/get-operator-by-service-id")
	public ModelAndView showReportByServiceId(@RequestParam Integer serviceId,@RequestParam Integer pageNumber, @RequestParam Integer pageSize, HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		List<ServiceResponseDto> serviceResponseDtoList = new ArrayList<>();
		CompanyMargineDto marginDto = new CompanyMargineDto();
		Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
		Map<String, Object> resultListPaginated = null;
		Pageable pageable = new PageRequest(pageNumber - 1, pageSize);
		try {
			model = super.getCommonSessionData(flowData, model);
			marginDto.setServiceId(serviceId);
			//with pagination
			resultListPaginated = reportServiceManager.showReportByServiceId(serviceId, companyId,pageable);
				
			DashbordDto dashbordDto=reportServiceManager.getDashbordData(companyId);
			model.addObject("dashbordDto", dashbordDto);
			
			serviceResponseDtoList = (List<ServiceResponseDto>) resultListPaginated.get(WebAppConstants.LIST);
			model.addObject("serviceResponseDtoList", serviceResponseDtoList);
			model.addObject("totalElements", Integer.parseInt(resultListPaginated.get("TOTAL_ELEMENTS").toString()));
			model.addObject("totalPages", Integer.parseInt(resultListPaginated.get("TOTAL_PAGES").toString()));
			model.addObject("pageSize", pageSize);
			model.addObject("currentPage", pageNumber);
			Integer planId = Integer.parseInt(flowData.getSessionData(WebAppConstants.PLANID));
			model.addObject("servicesDtoList", servicesServiceManager.getAllServices(planId));
			flowData.setSessionDataObject("serviceResponseDtoList", serviceResponseDtoList);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ReportController: showReportByServiceId", _be);
		} catch (Exception e) {
			logger.error("Exception In ReportController showReportByServiceId Method--", e);
		}
		model.addObject("url", 1);
		model.addObject("serviceResponseDtoList", serviceResponseDtoList);
		model.addObject("marginDto", marginDto);
		model.addObject("serviceId", serviceId);
		model.setViewName("recharge-history");
		return model;
	}

	
	@GetMapping(value = "/show-all-transaction-report")
	public List<WalletTransactionDto> showAllTransactionReport() {

		List<WalletTransactionDto> walletTransactionDtoList = new ArrayList<>();
		try {

			Integer companyType = 1;
			walletTransactionDtoList = reportServiceManager.showAllTransactionReport(companyType);

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ReportController: showAllTransactionReport", _be);
		} catch (Exception e) {
			logger.error("Exception In ReportController showAllTransactionReport Method--", e);
		}

		return walletTransactionDtoList;
	}

	@RequestMapping(value = "/get-live-report")
	public ModelAndView showLiveReportPage(HttpServletRequest request, HttpServletResponse response,
			@RequestParam Integer pageNumber, @RequestParam Integer pageSize) {
		List<LiveTransactionReportDto> liveTransactionReportDtoList = new ArrayList<>();
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		Map<String, Object> resultListPaginated = null;
		Pageable pageable = new PageRequest(pageNumber - 1, pageSize);
		try {
			Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));

			resultListPaginated = reportServiceManager.getLiveReport(null, null, companyId, pageable);
			liveTransactionReportDtoList = (List<LiveTransactionReportDto>) resultListPaginated
					.get(WebAppConstants.LIST);
			model.addObject("liveTransactionReportDtoList", liveTransactionReportDtoList);
			model.addObject("totalElements", Integer.parseInt(resultListPaginated.get("TOTAL_ELEMENTS").toString()));
			model.addObject("totalPages", Integer.parseInt(resultListPaginated.get("TOTAL_PAGES").toString()));
			model.addObject("pageSize", pageSize);
			model.addObject("currentPage", pageNumber);
			flowData.setSessionDataObject("liveTransactionReportDtoList", liveTransactionReportDtoList);
			
			DashbordDto dashbordDto=reportServiceManager.getDashbordData(companyId);
			model.addObject("dashbordDto", dashbordDto);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ReportController: getLiveReport", _be);
		} catch (Exception e) {
			logger.error("Exception In ReportController getLiveReport Method--", e);
		}
		model = super.getCommonSessionData(flowData, model);
		model.addObject("url", 1);
		
		model.setViewName("show-live-report");
		return model;
	}

	@GetMapping(value = "/get-live-report-by-date")
	public ModelAndView getLiveReport(@RequestParam("startDate") String Sdate, @RequestParam("endDate") String Edate,
			@RequestParam Integer pageNumber, @RequestParam Integer pageSize, HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		List<LiveTransactionReportDto> liveTransactionReportDtoList = new ArrayList<>();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		Map<String, Object> resultListPaginated = null;
		Pageable pageable = new PageRequest(pageNumber - 1, pageSize);

		try {
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			Date startDate = sdf.parse(Sdate);
			Date endDate = sdf.parse(Edate);
			resultListPaginated = reportServiceManager.getLiveReport(startDate, endDate, companyId, pageable);

			
			
			liveTransactionReportDtoList = (List<LiveTransactionReportDto>) resultListPaginated
					.get(WebAppConstants.LIST);
			model.addObject("liveTransactionReportDtoList", liveTransactionReportDtoList);
			model.addObject("totalElements", Integer.parseInt(resultListPaginated.get("TOTAL_ELEMENTS").toString()));
			model.addObject("totalPages", Integer.parseInt(resultListPaginated.get("TOTAL_PAGES").toString()));
			model.addObject("pageSize", pageSize);
			model.addObject("currentPage", pageNumber);

			flowData.setSessionDataObject("liveTransactionReportDtoList", liveTransactionReportDtoList);
			DashbordDto dashbordDto=reportServiceManager.getDashbordData(companyId);
			model.addObject("dashbordDto", dashbordDto);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ReportController: getLiveReport", _be);
		} catch (Exception e) {
			logger.error("Exception In ReportController getLiveReport Method--", e);
		}
		model = super.getCommonSessionData(flowData, model);
		model.setViewName("show-live-report");
		model.addObject("url", 2);
		model.addObject("startDate", Sdate);
		model.addObject("endDate", Edate);
		
		return model;
	}

	@RequestMapping(value = "/show-money-transfer-history")
	public ModelAndView showMoneyTransferHistory(HttpServletRequest request, HttpServletResponse response,
			@RequestParam Integer pageNumber, @RequestParam Integer pageSize) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		Map<String, Object> resultListPaginated = null;
		Pageable pageable = new PageRequest(pageNumber - 1, pageSize);
		List<MoneyTransferResponseDto> moneyTransferResponseDtoList = new ArrayList<>();
		try {
			model = super.getCommonSessionData(flowData, model);
			Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));

			resultListPaginated = reportServiceManager.showMoneyTransferHistory(companyId, pageable);
			moneyTransferResponseDtoList = (List<MoneyTransferResponseDto>) resultListPaginated
					.get(WebAppConstants.LIST);
			
			DashbordDto dashbordDto=reportServiceManager.getDashbordData(companyId);
			model.addObject("dashbordDto", dashbordDto);
			model.addObject("moneyTransferResponseDtoList", moneyTransferResponseDtoList);
			model.addObject("totalElements", Integer.parseInt(resultListPaginated.get("TOTAL_ELEMENTS").toString()));
			model.addObject("totalPages", Integer.parseInt(resultListPaginated.get("TOTAL_PAGES").toString()));
			model.addObject("pageSize", pageSize);
			model.addObject("currentPage", pageNumber);
			flowData.setSessionDataObject("moneyTransferResponseDtoList", moneyTransferResponseDtoList);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ReportController: showMoneyTransferHistory", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In ReportController showMoneyTransferHistory Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("url", 1);
		model.addObject("marginDto", new MargineDto());
		model.setViewName("show-money-transfer-history");
		return model;
	}

	@RequestMapping(value = "/show-money-transfer-history-by-date")
	public ModelAndView showMoneyTransferHistoryByDate(@RequestParam("startDate") String Sdate,
			@RequestParam("endDate") String Edate, @RequestParam Integer pageNumber, @RequestParam Integer pageSize,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		List<MoneyTransferResponseDto> moneyTransferResponseDtoList = new ArrayList<>();
		Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));

		Map<String, Object> resultListPaginated = null;
		Pageable pageable = new PageRequest(pageNumber - 1, pageSize);
		try {
			model = super.getCommonSessionData(flowData, model);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

			Date startDate = sdf.parse(Sdate);
			Date endDate = sdf.parse(Edate);
			resultListPaginated = reportServiceManager.showMoneyTransferHistoryByDate(companyId, startDate, endDate,
					pageable);
			moneyTransferResponseDtoList = (List<MoneyTransferResponseDto>) resultListPaginated
					.get(WebAppConstants.LIST);
			model.addObject("moneyTransferResponseDtoList", moneyTransferResponseDtoList);
			model.addObject("totalElements", Integer.parseInt(resultListPaginated.get("TOTAL_ELEMENTS").toString()));
			model.addObject("totalPages", Integer.parseInt(resultListPaginated.get("TOTAL_PAGES").toString()));
			model.addObject("pageSize", pageSize);
			model.addObject("currentPage", pageNumber);
			DashbordDto dashbordDto=reportServiceManager.getDashbordData(companyId);
			model.addObject("dashbordDto", dashbordDto);
			
			flowData.setSessionDataObject("moneyTransferResponseDtoList", moneyTransferResponseDtoList);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ReportController: showMoneyTransferHistoryByDate", _be);
		} catch (Exception e) {
			logger.error("Exception In ReportController showMoneyTransferHistoryByDate Method--", e);
		}
		if (moneyTransferResponseDtoList.isEmpty()) {
			model.addObject("errormsg", "No record found");

		}
		model.addObject("url", 2);
		model.addObject("startDate", Sdate);
		model.addObject("endDate", Edate);
		model.setViewName("show-money-transfer-history");
		return model;
	}

	@RequestMapping(value = "/show-all-distributors")
	public ModelAndView showAlldistributors(HttpServletRequest request, HttpServletResponse response,
			@RequestParam Integer pageNumber, @RequestParam Integer pageSize, @RequestParam String searchTerm ,Model modelAttribute) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		Map<String, Object> resultListPaginated = null;
		Pageable pageable = new PageRequest(pageNumber - 1, pageSize);
		try {
			model = super.getCommonSessionData(flowData, model);
			Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
			resultListPaginated = companyDetailsServiceImpl.getAllDistributors(pageable,companyId,searchTerm);
			model.addObject("companyDetailsList", resultListPaginated.get(WebAppConstants.LIST));
			model.addObject("totalElements", Integer.parseInt(resultListPaginated.get("TOTAL_ELEMENTS").toString()));
			model.addObject("totalPages", Integer.parseInt(resultListPaginated.get("TOTAL_PAGES").toString()));
			model.addObject("pageSize", pageSize);
			model.addObject("currentPage", pageNumber);
			
    		flowData.setSessionDataObject("companyDetailsList", resultListPaginated.get(WebAppConstants.LIST));
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ReportController: showRechargeHistory", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In ReportController showRechargeHistory Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("successmsg", modelAttribute.asMap().get("successmsg"));
		model.addObject("qString", searchTerm);
		model.setViewName("show-distributors");
		return model;
	}

	@RequestMapping(value = "/show-all-retailers-under-distributors")
	public ModelAndView showAllRetailersUnderDistributor(HttpServletRequest request, HttpServletResponse response,Model modelAttribute,
			@RequestParam Integer distributorsCompanyId, @RequestParam Integer pageNumber, @RequestParam Integer pageSize,@RequestParam String searchTerm)
			throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		Map<String, Object> resultListPaginated = null;
		Pageable pageable = new PageRequest(pageNumber - 1, pageSize);
		try {
			model = super.getCommonSessionData(flowData, model);
			
			resultListPaginated = companyDetailsServiceImpl.getAllRetailers(distributorsCompanyId, pageable,searchTerm);
			List<CompanyDetailsDto> companyDetailsList = (List<CompanyDetailsDto>) resultListPaginated
					.get(WebAppConstants.LIST);
			model.addObject("companyDetailsList", companyDetailsList);
			if (companyDetailsList == null) {
				model.addObject("errorMessage", "No retailers found...");
			}
			model.addObject("totalElements", Integer.parseInt(resultListPaginated.get("TOTAL_ELEMENTS").toString()));
			model.addObject("totalPages", Integer.parseInt(resultListPaginated.get("TOTAL_PAGES").toString()));
			model.addObject("pageSize", pageSize);
			model.addObject("currentPage", pageNumber);
			flowData.setSessionDataObject("companyDetailsList", resultListPaginated.get(WebAppConstants.LIST));
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ReportController: showRechargeHistory", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In ReportController showRechargeHistory Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("successmsg", modelAttribute.asMap().get("successmsg"));
		model.addObject("qString", searchTerm);
		model.setViewName("show-retailers");
		model.addObject("distributorsCompanyId", distributorsCompanyId);
		return model;
	}
	
	@RequestMapping(value = "/show-all-retailers-under-distributors-byId")
	public ModelAndView showAllRetailersUnderDistributorById(HttpServletRequest request, HttpServletResponse response,
			 @RequestParam Integer pageNumber, @RequestParam Integer pageSize,@RequestParam String searchTerm)
			throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}

		Map<String, Object> resultListPaginated = null;
		Pageable pageable = new PageRequest(pageNumber - 1, pageSize);
		Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
		try {
			model = super.getCommonSessionData(flowData, model);
			
			resultListPaginated = companyDetailsServiceImpl.getAllRetailers(companyId, pageable,searchTerm);
			List<CompanyDetailsDto> companyDetailsList = (List<CompanyDetailsDto>) resultListPaginated
					.get(WebAppConstants.LIST);
			model.addObject("companyDetailsList", companyDetailsList);
			if (companyDetailsList == null) {
				model.addObject("errorMessage", "No retailers found...");
			}
			model.addObject("totalElements", Integer.parseInt(resultListPaginated.get("TOTAL_ELEMENTS").toString()));
			model.addObject("totalPages", Integer.parseInt(resultListPaginated.get("TOTAL_PAGES").toString()));
			model.addObject("pageSize", pageSize);
			model.addObject("currentPage", pageNumber);
			CompanyDetailsDto companyDetailsDto = companyDetailsServiceImpl.getCompanyDetailsById(companyId);
			flowData.setSessionDataObject("cName", companyDetailsDto.getCompanyName());
			
			flowData.setSessionDataObject("companyDetailsList", companyDetailsList);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in ReportController: showRechargeHistory", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In ReportController showRechargeHistory Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("qString", searchTerm);
		model.setViewName("show-retailers");
		model.addObject("distributorsCompanyId", companyId);
		return model;
	}
	
	
			@RequestMapping(value = "/get-master-retailers")
			public ModelAndView getMasterRetailers(HttpServletRequest request, HttpServletResponse response,
					 @RequestParam Integer pageNumber, @RequestParam Integer pageSize,@RequestParam String searchTerm)
					throws HelthwellExceptionHandler {
				ModelAndView model = new ModelAndView();
				super.handleRequestInternal(request, response);
				FlowData flowData = null;
				if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
					flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
				}

				Map<String, Object> resultListPaginated = null;
				Pageable pageable = new PageRequest(pageNumber - 1, pageSize);
				Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
				try {
					model = super.getCommonSessionData(flowData, model);
					
					resultListPaginated = companyDetailsServiceImpl.getAllRetailers(companyId, pageable,searchTerm);
					List<CompanyDetailsDto> companyDetailsList = (List<CompanyDetailsDto>) resultListPaginated
							.get(WebAppConstants.LIST);
					model.addObject("companyDetailsList", companyDetailsList);
					if (companyDetailsList == null) {
						model.addObject("errorMessage", "No retailers found...");
					}
					model.addObject("totalElements", Integer.parseInt(resultListPaginated.get("TOTAL_ELEMENTS").toString()));
					model.addObject("totalPages", Integer.parseInt(resultListPaginated.get("TOTAL_PAGES").toString()));
					model.addObject("pageSize", pageSize);
					model.addObject("currentPage", pageNumber);
				} catch (HelthwellExceptionHandler _be) {
					logger.error("Exception in ReportController: getMasterRetailers", _be);
					model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
				} catch (Exception e) {
					logger.error("Exception In ReportController getMasterRetailers Method--", e);
					model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
				}
				model.addObject("qString", searchTerm);
				model.setViewName("master-retailers");
				model.addObject("distributorsCompanyId", companyId);
				return model;
			}
			
			
			
			
	@RequestMapping(value = "/saveDeductBalance")
	public ModelAndView saveDeductBalance(HttpServletRequest request, HttpServletResponse response,RedirectAttributes redirectAttrs) {
		ModelAndView model = new ModelAndView();
		WalletDto walletDto = new WalletDto();
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);

		model = super.getCommonSessionData(flowData, model);
		model.setViewName("");
		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<>();
		Integer walletId = Integer.parseInt(request.getParameter("walletId"));
		Double deductAmount = Double.parseDouble(request.getParameter("deductAmount"));
		String viewName = request.getParameter("viewName");
		String distributorsCompanyId = request.getParameter("distributorsCompanyId");
		Integer loggedCompanyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));

		try {
			char type='D';
			walleterviceManager.saveDeductWalletBalance(loggedCompanyId, walletId, deductAmount,type);
			model.addObject("successmsg", "balance deduct sucessfully with Rs. " + deductAmount);
			redirectAttrs.addFlashAttribute("successmsg", "balance deduct sucessfully with Rs. " + deductAmount);
			companyDetailsDtoList = walleterviceManager.getAllCompanyWallateBalance(loggedCompanyId);
			walletDto = walleterviceManager.getTotalWalletRecharge(loggedCompanyId);
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in WalletController: saveDeductWalletBalance", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getDescription());
		} catch (Exception e) {
			logger.error("Exception In WalletController saveRechargeWallet Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}

		model.addObject("companyType",Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYTYPE)));
		model.addObject("rechargeAmount", walletDto.getBalance());
		model.addObject("companyDetailsDtoList", companyDetailsDtoList);
		model.setViewName("wallet");
		if(viewName.equals("show-distributors")) {
			return new ModelAndView("redirect:/report/show-all-distributors?pageNumber=1&pageSize=25&searchTerm=");
			}else if(viewName.equals("companyRecharge")) {
			return new ModelAndView("redirect:/wallet/companyRecharge");	
			}else if(viewName.equals("master-retailers")) {
				return new ModelAndView("redirect:/report/get-master-retailers?pageNumber=1&pageSize=25&searchTerm=");	
			}else {
				return new ModelAndView("redirect:/report/show-all-retailers-under-distributors?distributorsCompanyId="+distributorsCompanyId+"&pageNumber=1&pageSize=25&searchTerm=");
			}
	}

	
	
}
