package com.bcoss.mtrans.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.bcoss.mtrans.ChangePasswordDto;
import com.bcoss.mtrans.CompanyDetailsDto;
import com.bcoss.mtrans.DistrictDto;
import com.bcoss.mtrans.PanCardDto;
import com.bcoss.mtrans.StateDto;
import com.bcoss.mtrans.dto.CategoryDto;
import com.bcoss.mtrans.dto.EmployeeDocumentDto;
import com.bcoss.mtrans.dto.PlansDto;
import com.bcoss.mtrans.dto.WalletDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.PanCard;
import com.bcoss.mtrans.repository.PanCardRepository;
import com.bcoss.mtrans.service.PancardServiceManager;
import com.bcoss.mtrans.util.FlowData;
import com.bcoss.mtrans.util.WebAppConstants;

@RequestMapping("/pan-card")
@Controller
public class PancardController extends BaseController{

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(PancardController.class);
	
	@Autowired
	PancardServiceManager serviceManager;
	
	@Value("mtrans.app.url")
	private String appUrl;
	@Value("${mtarns.doc.path}")
    private String docPath;
	
	@Autowired
	private PanCardRepository panCardRepository;
	@RequestMapping(value = "/pan-card")
	public ModelAndView getAllPancardRequest(HttpServletRequest request, HttpServletResponse response,
			@RequestParam Integer pageNumber, @RequestParam Integer pageSize, @RequestParam Integer appType,Model modelRedirect) throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		super.handleRequestInternal(request, response);
		FlowData flowData = null;
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		List<PanCardDto> serviceResponseDtoList = new ArrayList<>();
		Map<String, Object> resultListPaginated = null;
		Pageable pageable = new PageRequest(pageNumber - 1, pageSize);
		try {
			model = super.getCommonSessionData(flowData, model);
			Integer companyId = Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));

			resultListPaginated = serviceManager.getAllPancardRequest(companyId,appType,pageable);
			serviceResponseDtoList = (List<PanCardDto>) resultListPaginated.get(WebAppConstants.LIST);
			
			model.addObject("panCardDtoList", serviceResponseDtoList);
			model.addObject("totalElements", Integer.parseInt(resultListPaginated.get("TOTAL_ELEMENTS").toString()));
			model.addObject("totalPages", Integer.parseInt(resultListPaginated.get("TOTAL_PAGES").toString()));
			model.addObject("pageSize", pageSize);
			model.addObject("appType", appType);
			model.addObject("currentPage", pageNumber);
			model.addObject("errorMessage1", modelRedirect.asMap().get("msg1"));
			if(serviceResponseDtoList==null ||serviceResponseDtoList.isEmpty())
				model.addObject("errorMessage", "No record Found");
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in PancardController: showRechargeHistory", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In PancardController showRechargeHistory Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		
		model.addObject("successmsg", modelRedirect.asMap().get("msg"));
		model.setViewName("pan-card");
		return model;
	}

	
	@GetMapping("/get-pan-by-id/{panId}")
	public ModelAndView getPanCardById(HttpServletRequest request, HttpServletResponse response,
			@PathVariable(value = "panId") Integer panId) {
		ModelAndView model = new ModelAndView();

		PanCardDto panCardDto = new PanCardDto();

		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		List<CategoryDto> categoryDtoList = null;
		try {
			model = super.getCommonSessionData(flowData, model);
			panCardDto = serviceManager.getPanCardById(panId);
			if (panCardDto.getApplicantCategoryId() != null) {

				try {
					categoryDtoList = serviceManager
							.getCategoryByApplicationTypeId(panCardDto.getApplicantCategoryId());

				} catch (Exception e) {
					// TODO: handle exception
				}
			}

		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in PancardController: getPanCardById", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
		} catch (Exception e) {
			logger.error("Exception In PancardController getPanCardById Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}
		model.addObject("panCardDto", panCardDto);
		if (panCardDto.getApplicationType() == 1) {
			model.setViewName("new-pan-card");
		} else {
			model.setViewName("pan-correction");
		}
		model.addObject("categoryDtoList", categoryDtoList);
		return model;
	}

	@RequestMapping(value = "/new-pan-card", method = RequestMethod.GET)
	public ModelAndView newpanregister(HttpServletRequest request, HttpServletResponse response)
			throws HelthwellExceptionHandler {
		ModelAndView model = new ModelAndView();
		model.setViewName("new-pan-card");
		model.addObject("panCardDto", new PanCardDto());
		return model;
	}
	
	@RequestMapping(value = "/save-new-pan-card",method = RequestMethod.POST)
	public ModelAndView SaveNewPancard(@ModelAttribute("panCardDto") PanCardDto panCardDto, HttpServletRequest request, RedirectAttributes attribute,
			HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);
		Integer companyId =Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
		Boolean result= false;
		Double walletBalance=0.0;
		try {
			panCardDto.setCreatedBy(companyId);
			panCardDto.setApplicationType(1);
			panCardDto.setStatus(1);
			if(companyId!=1) {
				
			Integer walletId = Integer.parseInt(flowData.getSessionData(WebAppConstants.WALLETID));
			WalletDto	walletDto = walleterviceManager.getwalletById(walletId);
			walletBalance = walletDto.getBalance();
			walletBalance = walletBalance - (150.00);
		
		if (walletBalance <= 150) {
			// serviceResponseDto.setErrorCode("RKSS-001-IN");
			attribute.addFlashAttribute("msg1",
					"There is no sufficient amount in your balance. Please recharge and try again");
			// return model;
		} else {
			result=serviceManager.SaveNewPancard(panCardDto);
			attribute.addFlashAttribute("msg", "Record added successfully");
		}
			}else {
				result=serviceManager.SaveNewPancard(panCardDto);
				attribute.addFlashAttribute("msg", "Record added successfully");
			}
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in PancardController: SaveNewPancard", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
			attribute.addFlashAttribute("msg1",_be.getDescription());
		} catch (Exception e) {
			logger.error("Exception In PancardController SaveNewPancard Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}

			
		
		return new ModelAndView("redirect:" + "/pan-card/pan-card?pageNumber=1&pageSize=25&appType=1");
	}

	@RequestMapping(value = "/pan-correction", method = RequestMethod.GET)
	public ModelAndView pancardcorrection(HttpServletRequest request, HttpServletResponse response)
			throws HelthwellExceptionHandler {
		ModelAndView model =new ModelAndView();
		model.setViewName("pan-correction");
		model.addObject("panCardDto", new PanCardDto());
		return model;
	}
	@RequestMapping(value = "/save-pan-card-correction",method = RequestMethod.POST)
	public ModelAndView SavePancardCorrection(@ModelAttribute("panCardDto") PanCardDto panCardDto, HttpServletRequest request, RedirectAttributes attribute,
			HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		FlowData flowData = null;
		super.handleRequestInternal(request, response);
		if (request.getSession().getAttribute(WebAppConstants.FLOWDATA) != null) {
			flowData = (FlowData) request.getSession().getAttribute(WebAppConstants.FLOWDATA);
		}
		if (!flowData.isLoggedIn())
			return super.loginPage(flowData, request);
		Integer companyId =Integer.parseInt(flowData.getSessionData(WebAppConstants.COMPANYID));
		Boolean result= false;
		try {
			panCardDto.setCreatedBy(companyId);
			panCardDto.setApplicationType(2);
			panCardDto.setStatus(1);
			result=serviceManager.SaveNewPancard(panCardDto);
			attribute.addFlashAttribute("msg", "Record added successfully");
		} catch (HelthwellExceptionHandler _be) {
			logger.error("Exception in PancardController: SavePancardCorrection", _be);
			model.addObject(WebAppConstants.ERROR_CODE, _be.getErrorCode());
			attribute.addFlashAttribute("msg1",_be.getDescription());
		} catch (Exception e) {
			logger.error("Exception In PancardController SavePancardCorrection Method--", e);
			model.addObject(WebAppConstants.ERROR_CODE, HelthwellServiceErrors.GENERIC_EXCEPTION.getErrorCode());
		}

		
			
		
		return new ModelAndView("redirect:" +  "/pan-card/pan-card?pageNumber=1&pageSize=25&appType=2");
	}

	
	@RequestMapping(value = "/download-document", method = RequestMethod.GET)
	public void downloadDocument(HttpServletRequest request,
			HttpServletResponse response) {
			
		logger.info("customer controller: addCustomerDocument Method Start.");

		  final int BUFFER_SIZE = 4096;
		  Integer panId =Integer.parseInt( request.getParameter("panId"));
		  Integer type=Integer.parseInt( request.getParameter("type"));
		String url="";
        try {
        	PanCard panCard=panCardRepository.findOne(panId);
        		if(type==1)
        			url=panCard.getAddressUri();
        		if(type==2)
        			url=panCard.getDobUri();
        		if(type==3)
        			url=panCard.getIdentityUri();
        		if(type==4)
        			url=panCard.getScanCopyUri();
        		
        		  String fileUploadPath = System.getProperty("user.dir");
        	String fullPath = fileUploadPath+url;
    		File downloadFile = new File(fullPath);
        	
			FileInputStream inputStream = new FileInputStream(downloadFile);
			 String mimeType = "application/octet-stream";
	        System.out.println("MIME type: " + mimeType);
	 
	        // set content attributes for the response
	        response.setContentType(mimeType);
	        response.setContentLength((int) downloadFile.length());
	 
	        // set headers for the response
	        String headerKey = "Content-Disposition";
	        String headerValue = String.format("attachment; filename=\"%s\"",
	                downloadFile.getName());
	        response.setHeader(headerKey, headerValue);
	 
	        // get output stream of the response
	        OutputStream outStream = response.getOutputStream();
	 
	        byte[] buffer = new byte[BUFFER_SIZE];
	        int bytesRead = -1;
	 
	        while ((bytesRead = inputStream.read(buffer)) != -1) {
	            outStream.write(buffer, 0, bytesRead);
	        }
	 
	        inputStream.close();
	        outStream.close();
        }
        catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		logger.info("PancardController: downloadDocument Method End.");
	}

	
	
	@RequestMapping(value = "/get-category-by-application-type-id", method = RequestMethod.GET)
	public @ResponseBody List<CategoryDto> getCategoryByApplicationTypeId(HttpServletRequest request, HttpServletResponse response,
			@RequestParam Integer applicationTypeId) throws HelthwellExceptionHandler {
		List<CategoryDto> categoryDtoList = null;
		try {
			categoryDtoList = serviceManager.getCategoryByApplicationTypeId(applicationTypeId);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return categoryDtoList;
	}
}
