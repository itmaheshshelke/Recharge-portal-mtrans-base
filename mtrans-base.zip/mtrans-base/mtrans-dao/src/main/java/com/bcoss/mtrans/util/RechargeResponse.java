package com.bcoss.mtrans.util;

public class RechargeResponse {

	private String time;

	private String status;

	private String txid;

	private String error_code;

	private String operator_ref;

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTxid() {
		return txid;
	}

	public void setTxid(String txid) {
		this.txid = txid;
	}

	public String getError_code() {
		return error_code;
	}

	public void setError_code(String error_code) {
		this.error_code = error_code;
	}

	public String getOperator_ref() {
		return operator_ref;
	}

	public void setOperator_ref(String operator_ref) {
		this.operator_ref = operator_ref;
	}

	@Override
	public String toString() {
		return "ClassPojo [time = " + time + ", status = " + status + ", txid = " + txid + ", error_code = "
				+ error_code + ", operator_ref = " + operator_ref + "]";
	}
}
