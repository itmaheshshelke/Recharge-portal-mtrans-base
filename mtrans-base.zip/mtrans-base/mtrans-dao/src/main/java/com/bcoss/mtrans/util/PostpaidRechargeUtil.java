package com.bcoss.mtrans.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.bcoss.mtrans.constant.RechargeSettingConstant;
import com.bcoss.mtrans.dto.ServiceResponseDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;

public class PostpaidRechargeUtil {
	


	public static String postpaidRecharge(ServiceResponseDto serviceResponseDto) throws HelthwellExceptionHandler{
		String result = "";
		
		Long randomPass = Math.round(Math.random() * 1000000);
		String transactionId="rkss"+String.valueOf(randomPass);	
		
		try {
			StringBuilder sb = new StringBuilder(RechargeSettingConstant.URL);
			sb.append("memberid=");
			sb.append(RechargeSettingConstant.MEMBERID);
			sb.append("&pin=");
			sb.append(RechargeSettingConstant.PIN);
			sb.append("&number=");
			sb.append(serviceResponseDto.getMombileNumber());
			sb.append("&operator=");
			sb.append(serviceResponseDto.getOperatorCode());
			sb.append("&circle=");
			sb.append(serviceResponseDto.getCircleCode());
			sb.append("&amount=");
			sb.append(serviceResponseDto.getAmount());
			sb.append("&account=");
			sb.append(serviceResponseDto.getAccountNumber());
			sb.append("&usertx=");
			sb.append(transactionId);
			URL obj = new URL(sb.toString().replace(" ", ""));
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();

			con.setRequestMethod("GET");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			result = response.toString();
			
		} catch (Exception e) {
			throw new HelthwellExceptionHandler(
					HelthwellServiceErrors.SMS_SENDING_FAIL);
		}

		return result;
	}
	
	public static RechargeResponse transactionResponse(String response) {
		RechargeResponse rechargeResponse=new RechargeResponse();
		try {
			//txid,status,error_code,operator_ref,time
			//3110317,SUCCESS,,Transaction successful.Amount Debited,05-07-2013 16:07:36
			
			String transactionNo=response.split(",")[0];
			String status=response.split(",")[1];
			String error_code=response.split(",")[2];
			String operator_ref=response.split(",")[3];
			String time=response.split(",")[4].substring(0, 18);
			rechargeResponse.setTxid(transactionNo);
			rechargeResponse.setError_code(error_code);
			rechargeResponse.setOperator_ref(operator_ref);
			rechargeResponse.setTime(time);
			rechargeResponse.setStatus(status);
		} catch (Exception e) {
			
		}
		return rechargeResponse;
		
	}

}
