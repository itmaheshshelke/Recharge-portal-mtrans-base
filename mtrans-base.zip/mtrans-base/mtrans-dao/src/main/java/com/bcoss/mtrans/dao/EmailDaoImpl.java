package com.bcoss.mtrans.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.sms.EmailInbox;
import com.bcoss.mtrans.jpa.sms.EmailSetting;
import com.bcoss.mtrans.repository.EmailRepository;

@Transactional
@Repository
public class EmailDaoImpl implements EmailDao{


	private Logger logger = LoggerFactory.getLogger(EmailDaoImpl.class);
	
	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private EmailRepository emailRepository;

	@Override
	@Transactional
	public Boolean saveEmail(EmailInbox emailInbox) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {
			Long transactionId = Math.round(Math.random() * 1000000);
			String no=String.valueOf(transactionId);
			emailInbox.setEmailTransactionId(Integer.parseInt(no));
			entityManager.persist(emailInbox);
			entityManager.flush();
			result = true;

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ClinicEmailSettingDaoImpl - > saveEmail ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ClinicEmailSettingDaoImpl - > saveEmail ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public EmailSetting getEmailSettingById(Integer emailSettingId) throws HelthwellExceptionHandler {
		EmailSetting clinicEmailSetting=new EmailSetting();
		try {
			clinicEmailSetting =emailRepository.findOne(emailSettingId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ClinicEmailSettingDaoImpl - > getEmailSettingById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ClinicEmailSettingDaoImpl - > getEmailSettingById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return clinicEmailSetting;
	}
}
