package com.bcoss.mtrans.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.bcoss.mtrans.CompanyDetails;
import com.bcoss.mtrans.PanCardDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.Category;
import com.bcoss.mtrans.jpa.PanCard;
import com.bcoss.mtrans.jpa.Wallet;
import com.bcoss.mtrans.jpa.WalletTransaction;
import com.bcoss.mtrans.mapper.PancardMapper;
import com.bcoss.mtrans.repository.CategoryRepository;
import com.bcoss.mtrans.repository.PanCardRepository;
import com.bcoss.mtrans.util.CalendarUtil;

@Repository
@Transactional
public class PancardDaoImpl implements PancardDao {

	private Logger logger = LoggerFactory.getLogger(PancardDaoImpl.class);

	@Autowired
	PanCardRepository pranCardRepository;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private CompanyDetailsRepository companyDetailsRepository;

	@Autowired
	private CategoryRepository repository;
	@Override
	public Integer saveNewPancard(PanCardDto panCardDto) throws HelthwellExceptionHandler {
		try {

			if (panCardDto.getCreatedBy() != 1 && panCardDto.getPanId() != null) {
				Long txnNumber = Math.round(Math.random() * 10000000);
				Double chargeAmount = 150.00;
				CompanyDetails companyDetails = companyDetailsRepository.findOne(panCardDto.getCreatedBy());
				Wallet wallet = entityManager.find(Wallet.class, companyDetails.getWalletId());
				if (wallet.getBalance() < chargeAmount) {
					throw new HelthwellExceptionHandler(HelthwellServiceErrors.COMPANY_BALANCE_LOW);
				}
				wallet.setBalance(wallet.getBalance() - chargeAmount);
				entityManager.merge(wallet);
				entityManager.flush();

				WalletTransaction parentWalletTransaction = new WalletTransaction();
				parentWalletTransaction.setTransAmount(chargeAmount);
				parentWalletTransaction.setCreatedBy(panCardDto.getCreatedBy());
				parentWalletTransaction.setCreatedOn(CalendarUtil.getISTDate());
				parentWalletTransaction.setTransDate(CalendarUtil.getISTDate());
				parentWalletTransaction.setTransNumber(txnNumber.toString());
				parentWalletTransaction.setTransType('D');
				parentWalletTransaction.setWalletId(wallet.getWalletId());
				parentWalletTransaction.setTransStatus("sucess");
				entityManager.merge(parentWalletTransaction);
				entityManager.flush();
			}

			PanCard panCard = PancardMapper._toJpa(panCardDto);
			panCard.setDelFlag('N');
			pranCardRepository.save(panCard);

			return panCard.getPanId();
		} catch (HibernateException he) {
			logger.error("HibernateException Error in PancardDaoImpl - > saveNewPancard ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (HelthwellExceptionHandler hew) {
			throw hew;
		} catch (Exception e) {
			logger.error("Exception Error in PancardDaoImpl - > saveNewPancard ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

	}

	@Override
	public Page<PanCard> getAllPancardRequest(Integer companyId, Integer appType, Pageable pageable)
			throws HelthwellExceptionHandler {
		Page<PanCard> serviceResponseList = null;
		try {

			/*
			 * java.sql.Date startSqlDate=new java.sql.Date(startDate.getTime());
			 * java.sql.Date endSqlDate=new java.sql.Date(endDate.getTime());
			 */
			if (companyId == 1) {
				serviceResponseList = pranCardRepository.getAllPancardRequestForMaster(appType, pageable);
			} else {
				serviceResponseList = pranCardRepository.getAllPancardRequest(companyId, appType, pageable);

			}

		} catch (HibernateException he) {
			logger.error("HibernateException Error in PancardDaoImpl - > getAllPancardRequest ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PancardDaoImpl - > getAllPancardRequest ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return serviceResponseList;
	}

	@Override
	public void UpdatePancard(PanCardDto panCardDto) throws HelthwellExceptionHandler {

		try {

			PanCard panCard = PancardMapper._toJpa(panCardDto);
			panCard.setDelFlag('N');
			pranCardRepository.save(panCard);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in PancardDaoImpl - > saveNewPancard ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PancardDaoImpl - > saveNewPancard ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

	}

	@Override
	public PanCard getPanCardById(Integer panId) throws HelthwellExceptionHandler {
		PanCard panCard = new PanCard();
		try {
			panCard = pranCardRepository.findOne(panId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in PancardDaoImpl - > getPanCardById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PancardDaoImpl - > getPanCardById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return panCard;

	}

	@Override
	public List<Category> getCategoryByApplicationTypeId(Integer applicationTypeId) throws HelthwellExceptionHandler {
		List<Category> categoryList = new ArrayList<>();
		try {
			categoryList = repository.getCategoryByApplicationTypeId(applicationTypeId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in PancardDaoImpl - > getCategoryByApplicationTypeId ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PancardDaoImpl - > getCategoryByApplicationTypeId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return categoryList;
	}
}
