package com.bcoss.mtrans.dao;

import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.jpa.sms.SmsProviderSetting;
import com.bcoss.mtrans.jpa.sms.Template;

public interface SmsDao {

	
	public SmsProviderSetting getSmsConfig(int siteId) throws HelthwellExceptionHandler;

	public boolean saveSms(String mobileNo, String route, String vendorId, String messageId, int templateId,Integer clinicId)
			throws HelthwellExceptionHandler;

	public String getDeliveryReport(String vendorId, String messageId, String status) throws HelthwellExceptionHandler;

	public Template getSmsTempalte(Integer templateId)throws HelthwellExceptionHandler;

	
	

}
