package com.bcoss.mtrans.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bcoss.mtrans.jpa.ServiceOperators;

public interface ServiceOperatorsRepository extends JpaRepository<ServiceOperators, Integer>{

	@Query("select u from ServiceOperators u where  u.serviceId= :serviceId ORDER BY operator ASC")
	public List<ServiceOperators>getOperatorByServiceId(@Param("serviceId") Integer serviceId);
	

}
