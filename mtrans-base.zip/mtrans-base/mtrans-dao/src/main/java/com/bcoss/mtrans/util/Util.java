package com.bcoss.mtrans.util;

import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.apache.commons.codec.binary.Base64;

public class Util {

	public static String getUniqueToken() {
		/*
		 * UUID idOne = UUID.randomUUID();
		 * 
		 * return idOne.toString().replaceAll("-", "");
		 */
		Random r = new Random();
		String number = String.valueOf((1000 + r.nextInt(9000)));
		long millis = System.currentTimeMillis();
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(millis);
		return (number + c.get(Calendar.SECOND) + c.get(Calendar.MILLISECOND));
	}
	
	public static String generatePIN() {
		List<Integer> numbers = new ArrayList<Integer>();
		for (int i = 0; i < 10; i++) {
			numbers.add(i);
		}
		Collections.shuffle(numbers);
		String result = "";
		for (int i = 0; i < 6; i++) {
			result += numbers.get(i).toString();
		}
		return result;
	}
	
	public static String roundTwoDecimal(String amount) {
		Float floatAmt = Float.parseFloat(amount);
		DecimalFormat df = new DecimalFormat("#0.00");
		df.setMaximumFractionDigits(2);
		amount = df.format(floatAmt);
		return amount;
	}
	
	public static String generateSalt() {
		String saltString = null;

		try {

			// Generate Random Salt
			org.jasypt.salt.RandomSaltGenerator rg = new org.jasypt.salt.RandomSaltGenerator();

			saltString = org.jasypt.contrib.org.apache.commons.codec_1_3.binary.Base64
					.encodeBase64(rg.generateSalt(8)).toString();
			// return new
			// String(org.jasypt.contrib.org.apache.commons.codec_1_3.binary.Base64.encodeBase64(rg.generateSalt(8)));

		} catch (Exception e) {
		}
		return saltString;
	}
	
	public static String generatePassword(String salt,
			String userEnteredPasswordInClearText) {

		String generatedPassword = null;
		MessageDigest sha256 = null;
		try {
			// Create SHA-256 hashing...
			sha256 = MessageDigest.getInstance("SHA-256");
			// Concat password and salt
			byte[] passBytes = (salt.concat(userEnteredPasswordInClearText))
					.getBytes();
			// Hash both
			byte[] passHash = sha256.digest(passBytes);
			String hashedPassword = new String(
					org.jasypt.contrib.org.apache.commons.codec_1_3.binary.Base64
							.encodeBase64(passHash));
			// / This should go in database as a hashed password
			generatedPassword = new String(hashedPassword);

		} catch (Exception e) {
		} finally {
			sha256 = null;
		}

		return generatedPassword;
	}
	
	public static boolean verifyPassword(String saltInDatabase,
			String passwordInDatabase, String userEnteredPasswordInClearText) {

		boolean isValidUser = false;
		try {
			String generatedPassword = generatePassword(saltInDatabase,
					userEnteredPasswordInClearText);
			if (generatedPassword.equals(passwordInDatabase)) {
				// System.out.println("Password Matched!");
				isValidUser = true;
			} else if (!generatedPassword.equals(passwordInDatabase)) {
				// System.out.println("Password Not Matched!");
				isValidUser = false;
			}

		} catch (Exception e) {
		}

		return isValidUser;
	}
	
	public static String encodeImage(byte[] imageByteArray) {
		  return Base64.encodeBase64URLSafeString(imageByteArray);
		 }

		 public static byte[] decodeImage(String imageDataString) {
		  return Base64.decodeBase64(imageDataString);
		 }
		 
		 public static void main(String[] args) {
			 //System.out.println(Util.generatePIN());
			// System.out.println(Util.generatePassword(Util.generateSalt(),"Amol"));
			 System.out.println(Util.generatePassword("[B@1d9a3be", "ez/h92VWNG/SmEerXnZvXW8XvmNP+qIkmkKInL6yvZk="));
		 }
		 
		 public static Double calculateSuracharge(String amount) {
				
				Double total=Double.valueOf(amount);
				Double charge=0.0;
				if(total>=1 && total <=9) {
					charge=5.0;
				}else if(total>=10   && total <=1000) {
					charge=10.0;
				}else if(total>=1001 && total <=2000) {
					charge=15.0;
				}else if(total>=2001 && total <=3000) {
					charge=20.0;
				}else if(total>=3001 && total <=4000) {
					charge=30.0;
				}else {
					charge=40.0;
				}
				
				return charge;
		}

		public static Double calculateSurachargeForMaster(String amount) {
			Double total=Double.valueOf(amount);
			Double charge=0.0;
			if(total>=1 && total <=9) {
				charge=5.0;
			}else if(total>=10   && total <=1000) {
				charge=6.0;
			}else if(total>=1001 && total <=2000) {
				charge=10.0;
			}else if(total>=2001 && total <=3000) {
				charge=14.0;
			}else if(total>=3001 && total <=4000) {
				charge=18.0;
			}else {
				charge=22.0;
			}
			
			return charge;
		}
}
