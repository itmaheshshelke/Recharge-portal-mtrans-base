package com.bcoss.mtrans.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bcoss.mtrans.jpa.ServiceResponse;
import com.bcoss.mtrans.jpa.WalletTransaction;

public interface ServiceResponseRepository extends JpaRepository<ServiceResponse, Integer>{

	@Query("select u from ServiceResponse u where u.companyId = :companyId and u.serviceId = :serviceId and u.createdOn BETWEEN :startDate  and :endDate ORDER BY u.time DESC")
	public Page<ServiceResponse>  showRechargeReportByDate(@Param("serviceId") Integer serviceId, @Param("startDate")Date startDate,@Param("endDate") Date endDate, @Param("companyId")Integer companyId, Pageable pageable);

	@Query("select u from ServiceResponse u where u.serviceId = :serviceId and u.createdOn BETWEEN :startDate  and :endDate ORDER BY u.time DESC")
	public Page<ServiceResponse>  showRechargeReportByDate(@Param("serviceId") Integer serviceId, @Param("startDate")Date startDate,@Param("endDate") Date endDate, Pageable pageable);

	
	@Query("SELECT cwt.transNumber, cwt.transDate, cwt.transAmount, cwt.transType, cwt.transMethod, cwt.transRef, cwt.transStatus FROM WalletTransaction cwt ORDER BY cwt.createdOn DESC")
	public List<WalletTransaction> showAllTransactionReport(@Param("companyType") Integer companyType);
	
	@Query("select u from ServiceResponse u where u.serviceId = :serviceId and u.companyId = :companyId and DATE(u.time) = :curDate ORDER BY u.time DESC")
	public Page<ServiceResponse> showReportByServiceId(@Param("serviceId")Integer serviceId,@Param("companyId") Integer companyId,Pageable pageable,@Param("curDate")Date curDate);
	
	@Query("select u from ServiceResponse u where u.serviceId = :serviceId and DATE(u.time) = :curDate ORDER BY u.time DESC")
	public Page<ServiceResponse> showReportByServiceId(@Param("serviceId")Integer serviceId,Pageable pageable,@Param("curDate") Date curDate);
	
	@Query("select u from ServiceResponse u where u.dataStatus = 'PENDING' ORDER BY u.createdOn DESC")
	public List<ServiceResponse> findAllPendingTransaction();

	
	@Query("select u from ServiceResponse u where u.companyId = :companyId and u.createdOn=CURDATE() ORDER BY u.time DESC")
	public Page<ServiceResponse> findAll(@Param("companyId")Integer companyId, Pageable pageable);

	@Query("select u from ServiceResponse u where u.createdOn BETWEEN :startDate  and :endDate ORDER BY u.time DESC")
	public Page<ServiceResponse> getLiveReport(@Param("startDate")Date startDate,@Param("endDate") Date endDate, Pageable pageable);

	@Query("select u from ServiceResponse u where  u.createdOn BETWEEN :startDate  and :endDate and u.companyId = :companyId ORDER BY u.time DESC")
	public Page<ServiceResponse> getLiveReportByDate(@Param("startDate")Date startDate,@Param("endDate") Date endDate,@Param("companyId")Integer companyId, Pageable pageable);

	@Query("select u from ServiceResponse u where u.companyId = :companyId and DATE(u.time) = :curDate ORDER BY u.time DESC")
	public Page<ServiceResponse> findAllBycompanyId(@Param("companyId")Integer companyId, Pageable pageable,@Param("curDate") Date curDate);

	@Query("select u from ServiceResponse u ORDER BY u.time DESC")
	public List<ServiceResponse> findAll();

	@Query("select u from ServiceResponse u where DATE(u.time) = :curDate ORDER BY u.time DESC")
	public Page<ServiceResponse> findAll(Pageable pageable,@Param("curDate") Date curDate);
	
	//used for creating excel report
	@Query("select u from ServiceResponse u where u.serviceId = :serviceId and u.companyId = :companyId ORDER BY u.time DESC")
	public List<ServiceResponse> showAllReportByServiceId(@Param("serviceId")Integer serviceId, @Param("companyId")Integer companyId);
	//used for creating excel report
	@Query("select u from ServiceResponse u where u.serviceId = :serviceId ORDER BY u.time DESC")
	public List<ServiceResponse> showAllReportByServiceId(@Param("serviceId")Integer serviceId);

	@Query("select u from ServiceResponse u where u.companyId = :companyId ORDER BY u.time DESC")
	public List<ServiceResponse> findAllBycompanyId(@Param("companyId")Integer companyId);

	@Query("select u from ServiceResponse u where DATE(u.time) = :curDate ORDER BY u.time DESC")
	public Double getRechargeAmount(@Param("curDate") Date curDate);

	

	

	
	
//	@Query("SELECT cwt.transNumber, cwt.transDate, cwt.transAmount, cwt.transType, cwt.transMethod, cwt.transRef, cwt.transStatus FROM WalletTransaction cwt  INNER JOIN Wallet cw ON (cwt.walletId = cw.walletId) INNER JOIN CompanyDetails cd ON (cd.walletId = cw.walletId)where cd.companyType=:companyType")
}
