package com.bcoss.mtrans.mapper;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.State;
import com.bcoss.mtrans.StateDto;


public class StateMapper {
	
	public static StateDto _toDto(State state) {

		ModelMapper mapper = new ModelMapper();
		StateDto dtoObject = mapper.map(state, StateDto.class);
		return dtoObject;
	}

	public static State _toJpa(StateDto stateDto) {

		ModelMapper mapper = new ModelMapper();
		State jpaObject = mapper.map(stateDto, State.class);
		return jpaObject;
	}


}
