package com.bcoss.mtrans.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bcoss.mtrans.Role;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.repository.RoleRepository;
@Repository
public class RoleDaoImpl implements RoleDao {
	
	private Logger logger = LoggerFactory.getLogger(RoleDaoImpl.class);

	@Autowired
	RoleRepository roleRepository;

	@Override
	public List<Role> getAllRole() throws HelthwellExceptionHandler {
		List<Role> roleList=new ArrayList<Role>();
		try {
			
			roleList = roleRepository.findAll();
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in RoleDaoImpl - > getAllRole ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in RoleDaoImpl - > getAllRole ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return roleList;
	}
	
	@Override
	public Role getRoleById(Integer roleId) throws HelthwellExceptionHandler {
		Role role=new Role();
		try {
			
			role = roleRepository.findOne(roleId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in RoleDaoImpl - > getRoleById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in RoleDaoImpl - > getRoleById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return role;
	}
	
	
}
