package com.bcoss.mtrans.mapper;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.dto.MoneyTransferResponseDto;
import com.bcoss.mtrans.jpa.MoneyTransferResponse;

public class MoneyTransferResponseMapper {

	public static MoneyTransferResponseDto _toDto(MoneyTransferResponse moneyTransferResponse) {

		ModelMapper mapper = new ModelMapper();
		MoneyTransferResponseDto dtoObject = mapper.map(moneyTransferResponse, MoneyTransferResponseDto.class);
		return dtoObject;
	}

	public static MoneyTransferResponse _toJpa(MoneyTransferResponseDto moneyTransferResponseDto) {

		ModelMapper mapper = new ModelMapper();
		MoneyTransferResponse jpaObject = mapper.map(moneyTransferResponseDto, MoneyTransferResponse.class);
		return jpaObject;
	}
}
