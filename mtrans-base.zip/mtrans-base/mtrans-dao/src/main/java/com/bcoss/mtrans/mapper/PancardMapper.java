package com.bcoss.mtrans.mapper;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.PanCardDto;
import com.bcoss.mtrans.jpa.PanCard;

public class PancardMapper {

	public static PanCardDto _toDto(PanCard panCard) {

		ModelMapper mapper = new ModelMapper();
		PanCardDto dtoObject = mapper.map(panCard, PanCardDto.class);
		return dtoObject;
	}

	public static PanCard _toJpa(PanCardDto panCardDto) {

		ModelMapper mapper = new ModelMapper();
		PanCard jpaObject = mapper.map(panCardDto, PanCard.class);
		return jpaObject;
	}
	
}
