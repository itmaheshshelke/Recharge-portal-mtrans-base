package com.bcoss.mtrans.mapper.sysadmin;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.Recharge;
import com.bcoss.mtrans.RechargeDto;


public class RechargeMapper {

	public static RechargeDto _toDto(Recharge recharge) {

		ModelMapper mapper = new ModelMapper();
		RechargeDto dtoObject = mapper.map(recharge, RechargeDto.class);
		return dtoObject;
	}

	public static Recharge _toJpa(RechargeDto rechargeDto) {

		ModelMapper mapper = new ModelMapper();
		Recharge jpaObject = mapper.map(rechargeDto, Recharge.class);
		return jpaObject;
	}
	
	
	
}
