package com.bcoss.mtrans.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bcoss.mtrans.District;
import com.bcoss.mtrans.State;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.repository.DistrictRepository;
import com.bcoss.mtrans.repository.StateRepository;

@Repository
public class StateDaoImpl implements StateDao{
	
	private Logger logger = LoggerFactory.getLogger(StateDaoImpl.class);
	
	@Autowired
	StateRepository stateRepository;
	
	@Autowired
	DistrictRepository districtRepository;
	
	@Override
	public List<State> getAllState() throws HelthwellExceptionHandler {
		
		List<State> stateList=new ArrayList<State>();
		try {
			
			stateList = stateRepository.findAll();
			
		}catch(HibernateException he) {
			logger.error("HibernateException Error in StateDaoImpl - > getAllState ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		}catch(Exception e) {
			
			logger.error("Exception Error in StateDaoImpl - > getAllState ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		
		return stateList;
	}
	
	@Override
	public State getStateById(Integer stateId) throws HelthwellExceptionHandler{
		State state=new State();
		try {
			
			state = stateRepository.findOne(stateId);
			
		}catch(HibernateException he) {
			logger.error("HibernateException Error in StateDaoImpl - > getStateById ", he);
		throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in StateDaoImpl - > getStateById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return state;
		
	}
	
	@Override
	public List<District> getAllDistrict(Integer stateId) throws HelthwellExceptionHandler {
		
		List<District> districtList=new ArrayList<District>();
		try {
			
			districtList = districtRepository.findAll(stateId);
			
		}catch(HibernateException he) {
			logger.error("HibernateException Error in StateDaoImpl - > getAllDistrict ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		}catch(Exception e) {
			
			logger.error("Exception Error in StateDaoImpl - > getAllDistrict ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		
		return districtList;
	}

}
