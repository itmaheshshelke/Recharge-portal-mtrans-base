package com.bcoss.mtrans.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bcoss.mtrans.jpa.MoneyTransferResponse;

public interface MoneyTransferResponseRepo extends JpaRepository<MoneyTransferResponse, Integer>{

	@Query("select u from MoneyTransferResponse u where u.companyId= :companyId and DATE(u.createdOn) BETWEEN :startDate  and :endDate ORDER BY u.createdOn DESC")
	Page<MoneyTransferResponse> showMoneyTransferHistoryByDateAndCompanyId(@Param("companyId")Integer companyId, @Param("startDate")Date startSqlDate, @Param("endDate")Date endSqlDate, Pageable pageable);
	
	@Query("select u from MoneyTransferResponse u where  DATE(u.createdOn) BETWEEN :startDate  and :endDate ORDER BY DATE(u.createdOn) DESC")
	Page<MoneyTransferResponse> showMoneyTransferHistoryByDate(@Param("startDate")Date startSqlDate, @Param("endDate")Date endSqlDate, Pageable pageable);

	@Query("select u from MoneyTransferResponse u where u.companyId = :companyId and DATE(u.createdOn)=:curDate")
	Page<MoneyTransferResponse> findAllByCompanyId(@Param("companyId")Integer companyId, Pageable pageable,@Param("curDate") Date curDate);

	@Query("select u from MoneyTransferResponse u ORDER BY DATE(u.createdOn) DESC")
	List<MoneyTransferResponse> findAll();

	@Query("select u from MoneyTransferResponse u where  DATE(u.createdOn)=:curDate")
	Page<MoneyTransferResponse> findAllMoneyTransferReport(Pageable pageable,@Param("curDate")Date curDate);

	@Query("select u from MoneyTransferResponse u where u.companyId = :companyId ORDER BY DATE(u.createdOn) DESC")
	List<MoneyTransferResponse> findAllByCompanyId(@Param("companyId")Integer companyId);

}
