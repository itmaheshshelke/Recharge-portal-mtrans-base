package com.bcoss.mtrans.mapper;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.Role;
import com.bcoss.mtrans.RoleDto;

public class RoleMapper {

	public static RoleDto _toDto(Role role) {

		ModelMapper mapper = new ModelMapper();
		RoleDto dtoObject = mapper.map(role, RoleDto.class);
		return dtoObject;
	}

	public static Role _toJpa(RoleDto roleDto) {

		ModelMapper mapper = new ModelMapper();
		Role jpaObject = mapper.map(roleDto, Role.class);
		return jpaObject;
	}
	
	
}
