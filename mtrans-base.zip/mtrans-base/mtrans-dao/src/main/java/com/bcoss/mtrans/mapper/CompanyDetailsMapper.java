package com.bcoss.mtrans.mapper;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.CompanyDetails;
import com.bcoss.mtrans.CompanyDetailsDto;

public class CompanyDetailsMapper {
	
	public static CompanyDetailsDto _toDto(CompanyDetails companyDetails) {

		ModelMapper mapper = new ModelMapper();
		CompanyDetailsDto dtoObject = mapper.map(companyDetails, CompanyDetailsDto.class);
		return dtoObject;
	}

	public static CompanyDetails _toJpa(CompanyDetailsDto companyDetailsDto) {

		ModelMapper mapper = new ModelMapper();
		CompanyDetails jpaObject = mapper.map(companyDetailsDto, CompanyDetails.class);
		return jpaObject;
	}
	

}
