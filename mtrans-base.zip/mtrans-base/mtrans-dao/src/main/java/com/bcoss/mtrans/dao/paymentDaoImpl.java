package com.bcoss.mtrans.dao;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bcoss.mtrans.dto.PaymentDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.Payment;
import com.bcoss.mtrans.mapper.PaymentMapper;
import com.bcoss.mtrans.repository.PaymentRepository;

@Repository
public class paymentDaoImpl implements paymentDao{

	
	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(paymentDaoImpl.class);

	@Autowired
	PaymentRepository paymentRepository;
	
	
	@Override
	@Transactional
	public Boolean payment(PaymentDto paymentDto) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			Payment payment = PaymentMapper._toJpa(paymentDto);

			paymentRepository.save(payment);

			result = true;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in paymentDaoImpl - > payment ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in paymentDaoImpl - > payment ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

}
