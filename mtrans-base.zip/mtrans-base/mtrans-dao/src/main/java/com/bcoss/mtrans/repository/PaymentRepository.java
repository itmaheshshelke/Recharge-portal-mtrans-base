package com.bcoss.mtrans.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bcoss.mtrans.jpa.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Integer> {

	@Query("select u from Payment u where  u.dateTime BETWEEN :startDate  and :endDate")
	List<Payment> showMoneyTransferHistoryByDate(@Param("startDate")Date startSqlDate,@Param("endDate") Date endSqlDate);

}
