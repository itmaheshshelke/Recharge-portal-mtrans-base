package com.bcoss.mtrans.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bcoss.mtrans.CompanyDetails;
import com.bcoss.mtrans.dao.repository.CompanyMargineRepository;
import com.bcoss.mtrans.dto.ServiceResponseDto;
import com.bcoss.mtrans.dto.provider.response.SendMoneyResponseDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.CompanyMargine;
import com.bcoss.mtrans.jpa.MoneyTransferResponse;
import com.bcoss.mtrans.jpa.ServiceResponse;
import com.bcoss.mtrans.jpa.Wallet;
import com.bcoss.mtrans.jpa.WalletTransaction;
import com.bcoss.mtrans.mapper.ServiceResponseMapper;
import com.bcoss.mtrans.repository.ServiceResponseRepository;
import com.bcoss.mtrans.repository.WalletRepository;
import com.bcoss.mtrans.repository.WalletTransactionRepository;
import com.bcoss.mtrans.util.CalendarUtil;
import com.bcoss.mtrans.util.Util;


@Repository
@Transactional
public class RechargeDaoImpl implements RechargeDao{

	private Logger logger = LoggerFactory.getLogger(RechargeDaoImpl.class);
	
	
	@Autowired
	private ServiceResponseRepository serviceResponseRepository;
	
	
	@Autowired
	WalletRepository walletRepository;
	
	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	CompanyDetailsRepository companyDetailsRepository;
	
	@Autowired
	WalletTransactionRepository walletTransactionRepository;
	
	@Autowired
	private CompanyMargineRepository companyMargineRepository;

	@Override
	public Boolean saveRechargeResponse(ServiceResponseDto serviceResponseDto) throws HelthwellExceptionHandler {
		Boolean result = false;
		WalletTransaction walletTransaction=new WalletTransaction();
		try {
			ServiceResponse serviceResponse=ServiceResponseMapper._toJpa(serviceResponseDto);
			
			
			CompanyDetails companyDetails=companyDetailsRepository.findOne(serviceResponse.getCompanyId());
			
			if(companyDetails.getCompanyType()!=1) {
				
				CompanyDetails parentCompany=companyDetailsRepository.findOne(companyDetails.getParentId());
				
			if(parentCompany.getCompanyId()!=1 && serviceResponseDto.getServiceId()!=7) {
				List<CompanyMargine> companyMargineList = companyMargineRepository.findAllByOperatorAndComopanyId(companyDetails.getParentId(),serviceResponse.getOperatorId());
				Double distributorcommission=0.0;
				Double margine=companyMargineList.get(0).getValue();
				distributorcommission=serviceResponseDto.getAmount()*margine/100;
				
				distributorcommission=distributorcommission-serviceResponse.getMargine();
				
				Wallet walletParent=walletRepository.findOne(parentCompany.getWalletId());
				walletParent.setBalance(walletParent.getBalance()+distributorcommission);
				walletRepository.save(walletParent);
				
				WalletTransaction	parentWalletTransaction=new WalletTransaction();
				parentWalletTransaction.setTransAmount(distributorcommission);
				parentWalletTransaction.setCreatedBy(parentCompany.getCompanyId());
				parentWalletTransaction.setCreatedOn(CalendarUtil.getISTDate());
				parentWalletTransaction.setTransDate(CalendarUtil.getISTDate());
				parentWalletTransaction.setTransNumber(serviceResponse.getTxId());
				parentWalletTransaction.setTransType('C');
				parentWalletTransaction.setWalletId(walletParent.getWalletId());
				parentWalletTransaction.setTransStatus("sucess");
				walletTransactionRepository.save(parentWalletTransaction);
				}
				
				
				Wallet wallet=walletRepository.findOne(companyDetails.getWalletId());
				walletTransaction=new WalletTransaction();
				if(serviceResponseDto.getServiceId()==7) {
					wallet.setBalance(wallet.getBalance() - serviceResponseDto.getFinalAmount());
					walletTransaction.setTransAmount(serviceResponseDto.getFinalAmount());
				}else {
				wallet.setBalance(wallet.getBalance() - serviceResponseDto.getFinalAmount());
				walletTransaction.setTransAmount(serviceResponseDto.getFinalAmount());
				}
				walletRepository.save(wallet);
				
				
				walletTransaction.setCreatedBy(companyDetails.getCompanyId());
				walletTransaction.setCreatedOn(CalendarUtil.getISTDate());
				walletTransaction.setTransDate(CalendarUtil.getISTDate());
				walletTransaction.setTransNumber(serviceResponse.getTxId());
				walletTransaction.setTransType('D');
				walletTransaction.setWalletId(companyDetails.getWalletId());
				if(serviceResponse.getStatus().equals("FAILED")) {
					walletTransaction.setTransStatus("FAILED");
				}else {
				walletTransaction.setTransStatus("sucess");
				}
				walletTransactionRepository.save(walletTransaction);
				
				result = true;
			}
			
			
			serviceResponseRepository.save(serviceResponse);
			

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineDaoImpl - > saveRechargeResponse ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineDaoImpl - > saveRechargeResponse ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return result;
	}
	
	@Override
	public Boolean saveMoneyTransferResponse(SendMoneyResponseDto sendMoneyResponseDto,String benificiaryId,Integer companyId) throws HelthwellExceptionHandler {
		Boolean result = false;
		Double surcharge = 0.0;
		try {
			
			MoneyTransferResponse moneyTransferResponse =new MoneyTransferResponse();
			if(sendMoneyResponseDto.getData()!=null) {
				moneyTransferResponse.setAmount(sendMoneyResponseDto.getData().getAmount());
				moneyTransferResponse.setBankAlias(sendMoneyResponseDto.getData().getBankAlias());
				moneyTransferResponse.setChargedAmt(sendMoneyResponseDto.getData().getChargedAmt());
				moneyTransferResponse.setIpayId(sendMoneyResponseDto.getData().getIpay_id());
				moneyTransferResponse.setOprId(sendMoneyResponseDto.getData().getOprId());
				moneyTransferResponse.setRefNo(sendMoneyResponseDto.getData().getRefNo());
			}
			moneyTransferResponse.setBeneficiaryCode(benificiaryId);
			
			moneyTransferResponse.setCompanyId(companyId);
			moneyTransferResponse.setCreatedOn(CalendarUtil.getISTDate());
			
			moneyTransferResponse.setStatus(sendMoneyResponseDto.getStatus());
			moneyTransferResponse.setTxnNumber(sendMoneyResponseDto.getTrnxNo());
			moneyTransferResponse.setWalletBalance(sendMoneyResponseDto.getWalletBalance()+5.50);
			
			
			CompanyDetails companyDetails=companyDetailsRepository.findOne(companyId);
			// calculate charged amount of master/admin
			surcharge=Util.calculateSurachargeForMaster(moneyTransferResponse.getAmount());
			moneyTransferResponse.setChargedAmt(surcharge.toString());
			
			if(companyDetails.getCompanyType()!=1) {	
				
				
				surcharge=Util.calculateSuracharge(moneyTransferResponse.getAmount());
				moneyTransferResponse.setChargedAmt(surcharge.toString());
				
				Wallet wallet=walletRepository.findOne(companyDetails.getWalletId());
				wallet.setBalance(wallet.getBalance() - (Double.parseDouble(sendMoneyResponseDto.getData().getAmount())+surcharge));
				moneyTransferResponse.setWalletBalance(wallet.getBalance());
				entityManager.persist(wallet);
				entityManager.flush();
				
				WalletTransaction walletTransaction=new WalletTransaction();
				walletTransaction.setCreatedBy(companyDetails.getCompanyId());
				walletTransaction.setCreatedOn(CalendarUtil.getISTDate());
				walletTransaction.setTransAmount((Double.parseDouble(sendMoneyResponseDto.getData().getAmount())+surcharge));
				walletTransaction.setTransDate(CalendarUtil.getISTDate());
				walletTransaction.setTransNumber(sendMoneyResponseDto.getTrnxNo());
				walletTransaction.setTransType('D');
				walletTransaction.setWalletId(companyDetails.getWalletId());
				walletTransaction.setTransStatus("sucess");
				entityManager.persist(walletTransaction);
				entityManager.flush();
				
				
				
				result = true;
			}
			
			entityManager.persist(moneyTransferResponse);
			entityManager.flush();
			entityManager.close();
			
			

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineDaoImpl - > saveRechargeResponse ", he);
			//throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineDaoImpl - > saveRechargeResponse ", e);
			//.getClass(//throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return result;
	}

	

}
