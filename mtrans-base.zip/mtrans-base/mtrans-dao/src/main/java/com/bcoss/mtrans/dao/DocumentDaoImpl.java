package com.bcoss.mtrans.dao;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bcoss.mtrans.dto.EmployeeDocumentDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.EmployeeDocument;
import com.bcoss.mtrans.mapper.EmployeeDocumentMapper;

@Repository
public class DocumentDaoImpl implements IDocumentDao {

	private Logger logger = LoggerFactory.getLogger(DocumentDaoImpl.class);

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<EmployeeDocument> getAllEmployeeDocument(Integer companyId) throws HelthwellExceptionHandler {

		CriteriaBuilder criteriaBuilder = null;
		List<EmployeeDocument> employeeDocumentList = new ArrayList<EmployeeDocument>();

		try {
			criteriaBuilder = entityManager.getCriteriaBuilder();
			CriteriaQuery<EmployeeDocument> criteriaQuery = criteriaBuilder.createQuery(EmployeeDocument.class);
			TypedQuery<EmployeeDocument> typedQuery = null;

			Root<EmployeeDocument> root = criteriaQuery.from(EmployeeDocument.class);
			criteriaQuery.select(root);
			Predicate delFlg = criteriaBuilder.and(criteriaBuilder.equal(root.get("delflag"), 'N'));
			Predicate roleFlag = criteriaBuilder.and(criteriaBuilder.equal(root.get("companyId"), companyId));

			criteriaQuery.where(delFlg, roleFlag);
			criteriaQuery.orderBy(criteriaBuilder.desc(root.get("companyId")));
			typedQuery = entityManager.createQuery(criteriaQuery);

			employeeDocumentList = typedQuery.getResultList();
			return employeeDocumentList;

		} catch (HibernateException he) {
			logger.error("HibernateException Error in DocumentDaoImpl - > getAllEmployeeDocument ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in DocumentDaoImpl - > getAllEmployeeDocument ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			criteriaBuilder = null;
			entityManager.close();
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public Integer addEmployeeDocument(EmployeeDocumentDto employeeDocumentDto, Integer empDocId)
			throws HelthwellExceptionHandler {

		try {
			EmployeeDocument employeeDocument = EmployeeDocumentMapper._toJpa(employeeDocumentDto);
			if (empDocId == 0) {
				employeeDocument.setDelflag('N');
				entityManager.persist(employeeDocument);
				entityManager.flush();
				if (employeeDocument.getDocumentId() != null || employeeDocument.getDocumentId() != 0) {
					empDocId = employeeDocument.getDocumentId();
				}
			} else {
				Query query = entityManager
						.createQuery("UPDATE EmployeeDocument SET  uri = :uri WHERE documentId = :empDocId");
				query.setParameter("uri", employeeDocumentDto.getUri());
				query.setParameter("empDocId", empDocId);
				query.executeUpdate();

			}
			return empDocId;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in DocumentDaoImpl - > addEmployeeDocument", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in DocumentDaoImpl  - > addEmployeeDocument ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public boolean deleteEmployeeDocument(Integer emploeeDocumentId) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			Query query = entityManager
					.createQuery("UPDATE EmployeeDocument SET  delflag = 'Y' WHERE documentId = :id");
			query.setParameter("id", emploeeDocumentId);
			int updateResult = query.executeUpdate();

			if (updateResult != 0) {
				result = true;
			} else {
				return result;

				// throw new
				// SpinExceptionHandler(SpinServiceErrors.NO_ASSETS_FOUND);
			}
			return result;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in DocumentDaoImpl - > deleteEmployeeDocument", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in DocumentDaoImpl  - > deleteEmployeeDocument", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}
	}

	@Override
	public EmployeeDocument getEmployeeDocumentById(Integer documentId) throws HelthwellExceptionHandler {
		try {

			TypedQuery<EmployeeDocument> employeeQuery = entityManager
					.createQuery("SELECT r FROM EmployeeDocument r WHERE document_id= :id", EmployeeDocument.class);
			employeeQuery.setParameter("id", documentId);
			EmployeeDocument employee = employeeQuery.getSingleResult();
			return employee;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in EmployeeDaoImpl - > getEmployeeById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in EmployeeDaoImpl - > getEmployeeById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}
	}

}
