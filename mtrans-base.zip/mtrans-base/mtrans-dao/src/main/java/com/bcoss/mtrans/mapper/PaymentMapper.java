package com.bcoss.mtrans.mapper;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.dto.PaymentDto;
import com.bcoss.mtrans.jpa.Payment;

public class PaymentMapper {
	
	public static PaymentDto _toDto(Payment payment) {

		ModelMapper mapper = new ModelMapper();
		PaymentDto dtoObject = mapper.map(payment, PaymentDto.class);
		return dtoObject;
	}

	public static Payment _toJpa(PaymentDto paymentDto) {

		ModelMapper mapper = new ModelMapper();
		Payment jpaObject = mapper.map(paymentDto, Payment.class);
		return jpaObject;
	}

}
