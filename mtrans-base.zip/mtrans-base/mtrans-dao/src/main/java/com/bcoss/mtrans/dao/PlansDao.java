package com.bcoss.mtrans.dao;

import java.util.List;

import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.jpa.Plans;

public interface PlansDao {
	List<Plans> getAllPlans()throws HelthwellExceptionHandler;

	Plans getPlansById(Integer plansId)throws HelthwellExceptionHandler;


}
