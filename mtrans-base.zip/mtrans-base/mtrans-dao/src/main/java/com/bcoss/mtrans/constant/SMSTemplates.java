package com.bcoss.mtrans.constant;

public class SMSTemplates {

	//template id used 2
	public static String ORDER_RECEIVED = "Order Received: We have received your order with order id #1 amounting Rs.#2. You can expect delivery within #3 days. Payment mode is #4. We will send you an update when your order is packed.";
	//template id used 3
	public static String ORDER_PACKED = "Packed: Your order #1 has been packed by shopsway and will be shipped soon. We will send you details soon.";
	//template id used 4
	public static String ORDER_SHIPPED = "Shipped : Your order #1 has been shipped by shopsway and will be delivered soon. You will received sms/call when courier executive is out to deliver it";
	//template id used 5
	public static String ORDER_DELIVERED = "Delivered : Your order #1 has been delivered successfully.If case any cashback, amount will get add soon in your wallet. Thank you";
	//template id used 6
	public static String ORDER_CLOSED_WALLET_RECHARGE_1 = "Agrikatta added  Rs. #1 cashback in your wallet for order #2. Your updated wallet balance is #3.";
	public static String ORDER_CLOSED_WALLET_RECHARGE_2 = "Shopsway India added  Rs. #1 cashback in your wallet for order #2. Your updated wallet balance is #3.";
	
	//template id 8
	public static String ORDER_DEALER_COMMISSION_RECHARGE = "Shopsway India added  Rs. #1 commission in your wallet for order #2. Your updated wallet balance is #3.";
	
	//template id 9
	public static String WALLET_DEBIT_ORDER = "Rs #1 debited from your wallet for order #2. Your updated wallet balance is #3.";
	
	public static String DC_REQUEST = "Dear Customer Your Account Activated ,Please Use This Reference Code to give Your Agent-#1,\n and	 #2";
	
	//template id used 7
	public static String CUSOMER_REGISTRE = "Dear #1 Your Account is Activated ,Your customer code is : #2 .Please keep your code for further use";
	
	//template id used 1
	public static String OTP_SENT = "#1 is your OTP. We never calls you asking for OTP. Please do not share this information to others";
	
}
