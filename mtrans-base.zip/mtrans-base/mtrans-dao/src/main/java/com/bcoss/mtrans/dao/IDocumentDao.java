package com.bcoss.mtrans.dao;


import java.util.List;

import com.bcoss.mtrans.dto.EmployeeDocumentDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.jpa.EmployeeDocument;

public interface IDocumentDao {

	List<EmployeeDocument> getAllEmployeeDocument(Integer employeeId)throws HelthwellExceptionHandler;

	Integer addEmployeeDocument(EmployeeDocumentDto employeeDocumentDto, Integer empDocId)throws HelthwellExceptionHandler;

	boolean deleteEmployeeDocument(Integer emploeeDocumentId)throws HelthwellExceptionHandler;

	EmployeeDocument getEmployeeDocumentById(Integer documentId)throws HelthwellExceptionHandler;

}
