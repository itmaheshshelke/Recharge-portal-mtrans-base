package com.bcoss.mtrans.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bcoss.mtrans.District;

public interface DistrictRepository extends JpaRepository<District, Integer> {


	@Query("select u from District u where u.delFlag = 'N' and u.stateId= :stateId ORDER BY u.name ASC")
	public List<District> findAll(@Param("stateId") Integer stateId);
	
}
