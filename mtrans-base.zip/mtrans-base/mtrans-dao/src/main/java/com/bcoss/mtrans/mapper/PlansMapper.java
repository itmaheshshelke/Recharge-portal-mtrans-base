package com.bcoss.mtrans.mapper;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.dto.PlansDto;
import com.bcoss.mtrans.jpa.Plans;

public class PlansMapper {
	public static PlansDto _toDto(Plans plans) {
		ModelMapper mapper = new ModelMapper();
		PlansDto dtoObject = mapper.map(plans, PlansDto.class);
		return dtoObject;

	}
	public static Plans _toJpa(PlansDto plansDto) {
		ModelMapper mapper=new ModelMapper();
		Plans jpaObject=mapper.map(plansDto, Plans.class);
		return jpaObject;
	}

}
