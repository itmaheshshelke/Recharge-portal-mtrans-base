package com.bcoss.mtrans.mapper.sysadmin;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.Address;
import com.bcoss.mtrans.AddressDto;


public class AddressMapper {

	public static AddressDto _toDto(Address address) {

		ModelMapper mapper = new ModelMapper();
		AddressDto dtoObject = mapper.map(address, AddressDto.class);
		return dtoObject;
	}

	public static Address _toJpa(AddressDto addressDto) {

		ModelMapper mapper = new ModelMapper();
		Address jpaObject = mapper.map(addressDto, Address.class);
		return jpaObject;
	}
	
	
	
}
