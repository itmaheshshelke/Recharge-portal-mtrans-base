package com.bcoss.mtrans.dao;

import java.util.List;

import com.bcoss.mtrans.District;
import com.bcoss.mtrans.State;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface StateDao {
	List<State> getAllState()throws HelthwellExceptionHandler;

	State getStateById(Integer stateId)throws HelthwellExceptionHandler;
	
	List<District> getAllDistrict(Integer stateId)throws HelthwellExceptionHandler;

}
