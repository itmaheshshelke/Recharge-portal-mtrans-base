package com.bcoss.mtrans.constant;

public class RechargeSettingConstant {

	public static final String MEMBERID = "CF101775";
	public static final String PIN = "BEBD1B8E5D";
	
	public static final String URL = "http://crowdfinchapi.com/api/recharge.aspx?";
	
	public static final String BALANCE_URL = "http://crowdfinchapi.com/api/balance.aspx?memberid=CF101775&pin=BEBD1B8E5D";
	public static final String URLSTATUS = "http://crowdfinchapi.com/api/rechargestatus.aspx?";

	
	/*
	  <?xml version='1.0' encoding='UTF-8'?>
	  
	  <RechargeResponse>  
	 	<txid>0</txid>  
	 	<status>Unknown</status> 
	 	<error_code>Invalid Request!!Request has been forwarded to Admin.</error_code>
		<operator_ref>There is no row at position 0. </operator_ref>
		<time>24-04-2018 05:03:00 PM</time>
	 </RechargeResponse>*/
	
	
}
