package com.bcoss.mtrans.util;

// TODO: Auto-generated Javadoc
/**
 * The Interface WebAppConstants.
 */
public interface HelthwellConstants {
	
	public String SUCESS = "0000";
	public String UNAUTHORISED = "403";
	
	public String UPLOAD_PATH="C://imp//documents";
	public String DOWNLOAD_PATH="http://localhost:8081/images";
	public String SEPERATOR="/";
	//public String UPLOAD_DIRECTORY="documents";

}