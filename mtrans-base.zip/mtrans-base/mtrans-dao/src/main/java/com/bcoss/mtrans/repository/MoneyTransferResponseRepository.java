package com.bcoss.mtrans.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bcoss.mtrans.jpa.MoneyTransferResponse;

public interface MoneyTransferResponseRepository extends JpaRepository<MoneyTransferResponse, Integer>{

}
