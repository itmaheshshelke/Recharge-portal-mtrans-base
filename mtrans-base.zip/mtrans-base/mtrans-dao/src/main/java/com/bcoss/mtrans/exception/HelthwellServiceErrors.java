package com.bcoss.mtrans.exception;

/**
 * @author 
 * 
 */
public enum HelthwellServiceErrors {

	
	/**
	 * SUCCESS Response
	 */
	SUCCESS("0000", "Success"),

	/**
	 * FAILED Response
	 */

	GENERIC_EXCEPTION("EP0001", "Generic exception"),
	
	GENERIC_EXCEPTION_HIBERNATE("EP0002", "Generic exception"),
		
	RECHARGE_FAIL("HW-SMS-001","Recharge failed..."), 
	SMS_SENDING_FAIL("HW-SMS-001","SMS Sending failed..."), 
	SMS_BALANCE_FEATCHING_FAIL("HW-SMS-002","SMS Balance fetching failed..."),
	SMS_DELIVERY_REPORT_FEATCHING_FAIL("HW-SMS-001","SMS Sending failed..."), 
	NO_ADDRESS_FOUND("DS-AS-001","Address Record Not Found...."),
	ADDRESS_ALREADY_EXIST("DS-AS-002","Address Record Already Exist....."), 
	NO_CERTIFICATE_FOUND("DS-CS-001","Certificate Record not found....."),
	CEITIFICATE_ALREADY_EXIST("DS-CS-002","Certificate Record already Exist....."),
	NO_PATIENT_FOUND("DS-PS-001","Patient Record Not Found......"),
	PATIENT_ALREADY_EXIST("DS-PS-002","Patient Record Already Exist....."),
	INVALID_CREDENTIALS("DS-US-001","Invalid Credentials...."),
	INVALID_USER("DS-US-002","Invalid User...."),
	NO_DOCTOR_FOUND("DS-DS-001","Doctor Record Not Found..."),
	DOCTOR_ALREADY_EXIST("DS-DS-002","Doctor Record Already Exist..."),
	NO_PRESCRIPTION_FOUND("DS-PS-001", "Prescription Record Not Found..."),
	PRESCRIPTION_ALREADY_EXIST("DS-PS-002","Prescription Record Already Exist..."), 
	NO_ROLE_FOUND("DS-RS-001","User Role Record Not Found...."),
	ROLE_ALREADY_EXIST("DS-RS-002","Role Already Exist..."),
	NO_STAFF_FOUND("DS-SS-001","Staff Record Not Found...."),
	STAFF_ALREADY_EXIST("DS-SS-002","Staff Record Already Exist..."), 
	INVALID_INPUT("LD-LD-001","Invalid Input..."),
	SMS_CONFIG_NOT_FOUND("LD-LD-001","Invalid SMS COnfiguration..."),
	COMPANY_BALANCE_LOW("LD-LD-111","There is no sufficient balance. Please recharge wallet and try again!!"),
	COMPANY_NOT_CREATED("CC-CD-002","There some problem occured during company creation...."), 
	DEACTIVE_COMPANY("CC-CD-003","deactive company ....");
	/**
	 * variable for error code
	 */
	private String errorCode;
	/**
	 * variable for error code
	 */
	private String errorDescription;

	/**
	 * @param errorCode
	 * @param errorDescription
	 */
	private HelthwellServiceErrors(String errorCode, String errorDescription) {
		this.errorCode = errorCode;
		this.errorDescription = errorDescription;
	}

	/**
	 * @return error description
	 */
	public String getErrorDescription() {
		return this.errorDescription;
	}

	/**
	 * @return error code
	 */
	public String getErrorCode() {
		return this.errorCode;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Enum#toString()
	 */
	public String toString() {
		return this.errorCode + ":" + this.errorDescription;
	}
}
