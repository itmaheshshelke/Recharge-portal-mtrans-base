package com.bcoss.mtrans.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Synchronization;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bcoss.mtrans.CompanyDetails;
import com.bcoss.mtrans.dao.repository.CompanyMargineRepository;
import com.bcoss.mtrans.dto.MargineDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.CompanyMargine;

@Repository
@Transactional
public class CompanyMargineDaoImpl implements CompanyMargineDao {
	private Logger logger = LoggerFactory.getLogger(CompanyMargineDaoImpl.class);

	@Autowired
	private CompanyMargineRepository companyMargineRepository;
	@Autowired
	private CompanyDetailsRepository companyDetailsRepository;
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<CompanyMargine> getAllCompanyMargine(Integer planId)throws HelthwellExceptionHandler {
		List<CompanyMargine> companyMargineList=new ArrayList<CompanyMargine>();
		try {
		
			companyMargineList = companyMargineRepository.findAllByPlanId(planId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineDaoImpl - > getAllCompanyMargine ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineDaoImpl - > getAllCompanyMargine ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return companyMargineList;
	}

	@Override
	public CompanyMargine getCompanyMargineById(Integer companyMargineId)throws HelthwellExceptionHandler {
		CompanyMargine companyMargine=new CompanyMargine();
		try {
			
			companyMargine = companyMargineRepository.findOne(companyMargineId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineDaoImpl - > getCompanyMargineById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineDaoImpl - > getCompanyMargineById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return companyMargine;
	}
	
	@Override
	public CompanyMargine getCompanyMargineByCompanyAndOperatorId(Integer companyId ,Integer operatorId)throws HelthwellExceptionHandler {
		List<CompanyMargine> companyMargine;//=new CompanyMargine();
		try {
			
			companyMargine = companyMargineRepository.findAllByOperatorAndComopanyId(companyId,operatorId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineDaoImpl - > getCompanyMargineById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineDaoImpl - > getCompanyMargineById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		if(null!=companyMargine && !companyMargine.isEmpty()) {
			return companyMargine.get(0);
		}
		return null;
	}

	@Override
	public Boolean saveCompanyMargine(CompanyMargine companyMargine) throws HelthwellExceptionHandler {
		Boolean result = false;

		try {
			synchronized (companyMargine) {

				{
					List<CompanyMargine> companyMargineList = companyMargineRepository.checkExist(
							companyMargine.getCompanyId(), companyMargine.getServiceId(),
							companyMargine.getOperatorId(), companyMargine.getMargineType());

					if (companyMargineList != null && companyMargineList.size() != 0) {
						for (CompanyMargine companyMargine2 : companyMargineList) {

							companyMargine2.setValue(companyMargine.getValue());
							entityManager.merge(companyMargine2);
							entityManager.flush();
						}
					} else {

						entityManager.detach(companyMargine);
						companyMargine.setCompanyMargineId(null);
						entityManager.persist(companyMargine);
						entityManager.flush();
					}
				}
				List<CompanyDetails> companyDetailsList = companyDetailsRepository
						.findAllActive(companyMargine.getCompanyId());
				if (companyDetailsList != null && companyDetailsList.size() != 0) {
					for (CompanyDetails companyDetails : companyDetailsList) {
						List<CompanyMargine> companyMargineList = companyMargineRepository.checkExist(
								companyDetails.getCompanyId(), companyMargine.getServiceId(),
								companyMargine.getOperatorId(), companyMargine.getMargineType());

						if (companyMargineList != null && companyMargineList.size() != 0) {
							for (CompanyMargine companyMargine2 : companyMargineList) {
								if (companyMargine.getMargineType() == companyDetails.getCompanyType()) {
									companyMargine2.setValue(companyMargine.getValue());
									entityManager.merge(companyMargine2);
									entityManager.flush();
								}
							}
						} else {
							if (companyMargine.getMargineType() == companyDetails.getCompanyType()) {
								companyMargine.setCompanyId(companyDetails.getCompanyId());
								entityManager.detach(companyMargine);
								companyMargine.setCompanyMargineId(null);
								entityManager.persist(companyMargine);
								entityManager.flush();

							}
						}
					}
				}

			}

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineDaoImpl - > saveCompanyMargine ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineDaoImpl - > saveCompanyMargine ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}
		return result;
	}

	@Override
	public List<CompanyMargine> getMarginByPlanId(Integer planId) throws HelthwellExceptionHandler {
		List<CompanyMargine> companyMargineList=new ArrayList<CompanyMargine>();
		try {
		
			companyMargineList = companyMargineRepository.findAllByPlanId(planId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineDaoImpl - > getAllCompanyMargine ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineDaoImpl - > getAllCompanyMargine ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return companyMargineList;
	}

	@Override
	public List<CompanyMargine> getAllCompanyMargineBycompanyId(Integer companyId) throws HelthwellExceptionHandler {
		List<CompanyMargine> companyMargineList=new ArrayList<CompanyMargine>();
		try {
		
			companyMargineList = companyMargineRepository.findAllByCompanyId(companyId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineDaoImpl - > getAllCompanyMargine ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineDaoImpl - > getAllCompanyMargine ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return companyMargineList;
	}

	@Override
	public List<CompanyMargine> getAllCompanyMargineByMargineType(Integer margineType,Integer companyId, Integer serviceId)
			throws HelthwellExceptionHandler {
		List<CompanyMargine> companyMargineList=new ArrayList<CompanyMargine>();
		try {
		
			companyMargineList = companyMargineRepository.getMargineData(margineType,companyId,serviceId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineDaoImpl - > getAllCompanyMargineByMargineType ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineDaoImpl - > getAllCompanyMargineByMargineType ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return companyMargineList;
	}

	@Override
	public List<MargineDto> getMargineData(Integer margineType, Integer serviceId) throws HelthwellExceptionHandler {
		List<Object> objectList = new ArrayList<Object>();
		List<MargineDto> margineDtoList=new ArrayList<>();
		try {
			Query query = entityManager.createNativeQuery("SELECT sp.operator, cm.type, cm.value FROM service_operators sp INNER JOIN company_margine cm ON (sp.operator_id= cm.operator_id) where cm.margine_type=:margineType and cm.service_id=:serviceId ");
		
			query.setParameter("margineType", margineType);
			query.setParameter("serviceId", serviceId);
		objectList = query.getResultList();
		
		if (objectList != null && objectList.size() > 0) {
			Iterator itr=objectList.iterator();
			while(itr.hasNext()) {
				MargineDto margineDto=new MargineDto();
				Object[] element = (Object[]) itr.next();
				margineDto.setOperatorName((element[0].toString()));
				margineDto.setType(Integer.parseInt(element[1].toString()));
				margineDto.setMargineValue(Double.parseDouble(element[2].toString()));
				margineDtoList.add(margineDto);
			}
		} 
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyMargineDaoImpl - > getAllCompanyMargineByMargineType ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyMargineDaoImpl - > getAllCompanyMargineByMargineType ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return margineDtoList;
	}
}


/*
TypedQuery<CompanyMargine> employeeQuery = entityManager
		.createQuery("select e from CompanyMargine e where  e.margineType= :margineType and e.companyId= :companyId and e.serviceId= :serviceId and e.operatorId= :operatorid", CompanyMargine.class);
employeeQuery.setParameter("margineType", companyMargine.getMargineType());
employeeQuery.setParameter("companyId", companyMargine.getCompanyId());
employeeQuery.setParameter("serviceId", companyMargine.getServiceId());
employeeQuery.setParameter("operatorid", companyMargine.getOperatorId());
List<CompanyMargine> companyMargineList = employeeQuery.getResultList();
*/	


/*//companyMargine.getCompanyId(),
List<CompanyMargine> companyMargineList = companyMargineRepository.checkExist(companyMargine.getCompanyId(),
		companyMargine.getServiceId(), companyMargine.getOperatorId(), companyMargine.getMargineType());
if (companyMargineList != null && !companyMargineList.isEmpty()) {
	for (CompanyMargine companyMargine2 : companyMargineList) {
		companyMargine.setCompanyMargineId(companyMargine2.getCompanyMargineId());
		entityManager.merge(companyMargine);
		entityManager.flush();
	}
} else {
	entityManager.persist(companyMargine);
	entityManager.flush();
}

*/
