package com.bcoss.mtrans.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bcoss.mtrans.Employee;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.repository.EmployeeRepository;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	private Logger logger = LoggerFactory.getLogger(EmployeeDaoImpl.class);

	@Autowired
	EmployeeRepository employeeRepository;

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Employee> getAllEmployee(Integer compnayId) throws HelthwellExceptionHandler {
		List<Employee> employeeList = new ArrayList<Employee>();
		try {

			employeeList = employeeRepository.findAll(compnayId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in EmployeeDaoImpl - > getAllEmployee ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in EmployeeDaoImpl - > getAllEmployee ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return employeeList;
	}

	@Override
	public Employee getEmployeeById(Integer employeeId) throws HelthwellExceptionHandler {
		Employee employee = new Employee();
		try {

			employee = employeeRepository.findOne(employeeId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in EmployeeDaoImpl - > getEmployeeById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in EmployeeDaoImpl - > getEmployeeById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return employee;
	}

	@Override
	@Transactional
	public Boolean saveEmployee(Employee employee) throws HelthwellExceptionHandler {
		Boolean result = false;

		try {

			entityManager.persist(employee);
			entityManager.flush();

		} catch (HibernateException he) {
			entityManager.getTransaction().rollback();
			logger.error("HibernateException Error in EmployeeDaoImpl - > saveEmployee ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			entityManager.getTransaction().rollback();
			logger.error("Exception Error in EmployeeDaoImpl - > saveEmployee ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return result;
	}

	@Override
	public Boolean updateEmployee(Employee employee) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {

			employeeRepository.save(employee);
			result = true;

		} catch (HibernateException he) {
			logger.error("HibernateException Error in EmployeeDaoImpl - > saveEmployee ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in EmployeeDaoImpl - > saveEmployee ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return result;
	}

	@Override
	public Boolean deleteEmployee(Integer employeeId) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			Employee employee = employeeRepository.findOne(employeeId);
			employee.setDelFlag('Y');

			employeeRepository.save(employee);
			result = true;

		} catch (HibernateException he) {
			logger.error("HibernateException Error in EmployeeDaoImpl - > deleteEmployee ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in EmployeeDaoImpl - > deleteEmployee ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;

	}

}
