package com.bcoss.mtrans.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bcoss.mtrans.jpa.Plans;

public interface PlansRepository extends JpaRepository<Plans, Integer> {

}
