package com.bcoss.mtrans.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bcoss.mtrans.CompanyDetails;
import com.bcoss.mtrans.Employee;
import com.bcoss.mtrans.dao.repository.CompanyMargineRepository;
import com.bcoss.mtrans.dao.repository.PlansRepository;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.CompanyMargine;
import com.bcoss.mtrans.jpa.Plans;
import com.bcoss.mtrans.jpa.Wallet;
import com.bcoss.mtrans.repository.EmployeeRepository;
import com.bcoss.mtrans.repository.WalletRepository;
import com.bcoss.mtrans.util.CalendarUtil;

@Repository
@Transactional
public class CompanyDetailsDaoImpl implements CompanyDetailsDao {

	private Logger logger = LoggerFactory.getLogger(CompanyDetailsDaoImpl.class);

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	EmployeeRepository employeeRepository;

	@Autowired
	CompanyDetailsRepository reposiotory;
	
	@Autowired
	WalletRepository walletRepository;

	@Autowired
	private PlansRepository plansRepository;
	
	@Autowired
	private CompanyDetailsRepository companyDetailsRepository;
	
	@Autowired
	private CompanyMargineRepository companyMargineRepository;

	public List<CompanyDetails> getAllCompanyDetails(Integer companyId) throws HelthwellExceptionHandler {

		List<CompanyDetails> companyDetailsList = new ArrayList<CompanyDetails>();

		try {
			companyDetailsList = reposiotory.findAllActive(companyId);

			if (companyDetailsList != null && companyDetailsList.size() > 0) {
				return companyDetailsList;
			} else {
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.NO_ADDRESS_FOUND);
			}
		} catch (HelthwellExceptionHandler ex) {
			throw ex;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > getCompanyDetailss ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > getCompanyDetailss ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}
	}

	public CompanyDetails getCompanyDetailsById(int companyDetailsId) throws HelthwellExceptionHandler {

		try {
			CompanyDetails companyDetails = reposiotory.findOne(companyDetailsId);
			return companyDetails;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > getCompanyDetailsById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > getCompanyDetailsById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public Employee addCompanyDetails(CompanyDetails companyDetails) throws HelthwellExceptionHandler {
		Boolean result = false;
		Employee employee = new Employee();
		Integer companyId;
		try {
			Long randomPass = Math.round(Math.random() * 10000000);
			final String rdpass = String.valueOf(randomPass);

			Plans plans = plansRepository.findOne(companyDetails.getPlanId());
			
			Wallet wallet=new Wallet();
			wallet.setBalance(0.0);
			wallet.setCreatedOn(CalendarUtil.getISTDate());
			wallet.setWalletNumber(rdpass);
			walletRepository.save(wallet);

			companyDetails.setSetupFee(plans.getSetupFee());
			companyDetails.setWalletId(wallet.getWalletId());
			companyDetails.setDelFlag('N');
			companyDetails.setIsActive(1);
			companyDetails.setIsReadOnly('N');
			reposiotory.save(companyDetails);

			if (companyDetails.getCompanyId() != null) {

				employee.setCompanyId(companyDetails.getCompanyId());
				employee.setContactNo(companyDetails.getContactNo());
				employee.setName(companyDetails.getContactPersonName());
				employee.setEmailId(companyDetails.getEmailId());
				employee.setRoleId(1);
				employee.setPassword(rdpass);
				employee.setDelFlag('N');
				employee.setCreatedOn(CalendarUtil.getISTDate());

				employeeRepository.save(employee);
				//set default margin to new company 

				List<CompanyMargine> companyMargineList = companyMargineRepository
						.getDefaultMargine(companyDetails.getParentId(), companyDetails.getCompanyType());
				for (CompanyMargine companyMargine : companyMargineList) {

					entityManager.detach(companyMargine);
					companyMargine.setCompanyMargineId(null);
					companyMargine.setCompanyId(companyDetails.getCompanyId());
					companyMargine.setMargineType(companyDetails.getCompanyType());
					entityManager.persist(companyMargine);
					entityManager.flush();
				}

				return employee;
			} else {
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.COMPANY_NOT_CREATED);
			}
			
		} catch (HelthwellExceptionHandler ex) {
			throw ex;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > addCompanyDetails ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > addCompanyDetails ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public boolean updateCompanyDetails(CompanyDetails companyDetails) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			
			entityManager.merge(companyDetails);
			entityManager.flush();
			
			//reposiotory.save(companyDetails);
			result = true;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > updateCompanyDetails ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > updateCompanyDetails ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;

	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public boolean deleteCompanyDetails(int companyDetailsId) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			Query query = entityManager.createQuery("UPDATE CompanyDetails SET  delFlag = 'Y' WHERE companyId = :id");
			query.setParameter("id", companyDetailsId);
			int updateResult = query.executeUpdate();
			
			List<Employee> employeeList = employeeRepository.findAll(companyDetailsId);
			for (Employee employeeTemp : employeeList) {
				
				Employee employee = employeeRepository.findOne(employeeTemp.getEmployeeId());
				employee.setDelFlag('Y');

				employeeRepository.save(employee);
				result = true;

				
			}
			CompanyDetails companyDetailsTemp = reposiotory.findOne(companyDetailsId);
			if(companyDetailsTemp.getCompanyType()==3) {
			List<CompanyDetails> companyDetailsList = reposiotory.getAllRetailersUnderDistributor(companyDetailsId);
			for (CompanyDetails companyDetails : companyDetailsList) {
				Query query1 = entityManager
						.createQuery("UPDATE CompanyDetails SET  parentId = '1' WHERE companyId = :id");
				query1.setParameter("id", companyDetails.getCompanyId());
				query1.executeUpdate();

			}
			}

			if (updateResult != 0) {
				result = true;
			} else {
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.NO_ADDRESS_FOUND);
			}
			return result;
		} catch (HelthwellExceptionHandler ex) {
			throw ex;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > deleteCompanyDetails ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > deleteCompanyDetails ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

	}

	@Override
	public List<CompanyDetails> searchCompanyDetails(Integer companyId, String qString)
			throws HelthwellExceptionHandler {
		List<CompanyDetails> companyDetailsList = new ArrayList<CompanyDetails>();

		try {
			companyDetailsList = reposiotory.searchCompanyDetails(companyId,qString);

			if (companyDetailsList != null && companyDetailsList.size() > 0) {
				return companyDetailsList;
			} else {
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.NO_ADDRESS_FOUND);
			}
		} catch (HelthwellExceptionHandler ex) {
			throw ex;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > getCompanyDetailss ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > getCompanyDetailss ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}

	}

	public Page<CompanyDetails> getAllDistributors(Pageable pageable,Integer companyId,String searchTerm) throws HelthwellExceptionHandler {
		Page<CompanyDetails> companyDetailsList=null;
		try {
			if(companyId!=1) {
				if(searchTerm!="") 
					companyDetailsList = reposiotory.getcompany(companyId,pageable,searchTerm);
				else
					companyDetailsList = reposiotory.getcompany(companyId,pageable);
			}else {
				if(searchTerm!="") 
					companyDetailsList = reposiotory.getAllDistributors(pageable,searchTerm);
				else
					companyDetailsList = reposiotory.getAllDistributors(pageable);
				
			}
			return companyDetailsList;
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > getCompanyDetailss ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > getCompanyDetailss ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}
	}

	@Override
	public Page<CompanyDetails> getAllRetailers(Integer id,Pageable pageable,String searchTerm) throws HelthwellExceptionHandler {

		try {
			Page<CompanyDetails> companyDetailsList = reposiotory.getAllRetailers(id,pageable,searchTerm);

				return companyDetailsList;
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > getCompanyDetailss ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > getCompanyDetailss ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}
	}

	@Override
	public Boolean isMobileNoExits(String mobileNo) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			List<CompanyDetails> companyDetailsList=reposiotory.isMobileNoExits(mobileNo);
			if(companyDetailsList!=null && !companyDetailsList.isEmpty())
			result = true;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > mobileNo ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > mobileNo ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
		
	}

}
