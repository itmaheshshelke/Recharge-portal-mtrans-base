package com.bcoss.mtrans.dao;

import java.util.List;

import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.jpa.Services;

public interface ServicesDao {
	List<Services> getAllServices(Integer planId)throws HelthwellExceptionHandler;

	Services getServicesById(Integer serviceId)throws HelthwellExceptionHandler;

	Boolean saveServices(Services services)throws HelthwellExceptionHandler;

	Boolean deleteServices(Integer serviceId)throws HelthwellExceptionHandler;

}
