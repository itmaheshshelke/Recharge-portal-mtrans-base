package com.bcoss.mtrans.mapper;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.dto.ServiceOperatorsDto;
import com.bcoss.mtrans.jpa.ServiceOperators;

public class ServiceOperatorsMapper {
	public static ServiceOperatorsDto _toDto(ServiceOperators serviceOperators) {

		ModelMapper mapper = new ModelMapper();
		ServiceOperatorsDto dtoObject = mapper.map(serviceOperators, ServiceOperatorsDto.class);
		return dtoObject;
	}

	public static ServiceOperators _toJpa(ServiceOperatorsDto serviceOperatorsDto) {

		ModelMapper mapper = new ModelMapper();
		ServiceOperators jpaObject = mapper.map(serviceOperatorsDto, ServiceOperators.class);
		return jpaObject;
	}

}
