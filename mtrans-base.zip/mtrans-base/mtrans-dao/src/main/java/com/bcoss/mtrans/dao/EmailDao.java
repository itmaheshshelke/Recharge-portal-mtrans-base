package com.bcoss.mtrans.dao;

import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.jpa.sms.EmailInbox;
import com.bcoss.mtrans.jpa.sms.EmailSetting;

public interface EmailDao {

	public Boolean saveEmail(EmailInbox emailInbox) throws HelthwellExceptionHandler;;
	public EmailSetting getEmailSettingById(Integer emailSettingId)throws HelthwellExceptionHandler;
}
