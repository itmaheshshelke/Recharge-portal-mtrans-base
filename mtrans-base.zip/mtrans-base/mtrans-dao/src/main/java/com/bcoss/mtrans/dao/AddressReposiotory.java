package com.bcoss.mtrans.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bcoss.mtrans.Address;

public interface AddressReposiotory  extends JpaRepository<Address, Integer>{
	@Query("select u from Address u where u.delFlag = 'N'")
	public List<Address> findAllActive();

}
