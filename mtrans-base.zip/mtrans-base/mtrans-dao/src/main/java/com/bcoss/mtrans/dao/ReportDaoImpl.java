package com.bcoss.mtrans.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.bcoss.mtrans.dto.DashbordDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.MoneyTransferResponse;
import com.bcoss.mtrans.jpa.ServiceResponse;
import com.bcoss.mtrans.jpa.WalletTransaction;
import com.bcoss.mtrans.repository.ServiceResponseRepository;
import com.bcoss.mtrans.util.CalendarUtil;

@Repository
@Transactional
public class ReportDaoImpl implements ReportDao{

	private final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(ReportDaoImpl.class);

	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	private com.bcoss.mtrans.repository.MoneyTransferResponseRepo moneyTransferResponseRepo;
	
	@Autowired
	private ServiceResponseRepository serviceResponseRepository;
	@Override
	public Page<ServiceResponse> showRechargeReportByDate(Integer serviceId, Date startDate, Date endDate,Integer companyId,Pageable pageable)
			throws HelthwellExceptionHandler {
		Page<ServiceResponse> serviceResponseList = null;
		try {

			java.sql.Date startSqlDate=new java.sql.Date(startDate.getTime());
			java.sql.Date endSqlDate=new java.sql.Date(endDate.getTime());

			if(companyId==1) {
			serviceResponseList=serviceResponseRepository.showRechargeReportByDate(serviceId,startSqlDate,endSqlDate,pageable);
			}else {
				serviceResponseList=serviceResponseRepository.showRechargeReportByDate(serviceId,startSqlDate,endSqlDate,companyId,pageable);

			}
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportDaoImpl - > getBillingHistoryByDate ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportDaoImpl - > getBillingHistoryByDate ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return serviceResponseList;
	}
	@Override
	public List<WalletTransaction> showAllTransactionReport(Integer companyType) throws HelthwellExceptionHandler {
		List<WalletTransaction> walletTransactionList = new ArrayList<WalletTransaction>();
		try {
			walletTransactionList=serviceResponseRepository.showAllTransactionReport(companyType);
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportDaoImpl - > showAllTransactionReport ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportDaoImpl - > showAllTransactionReport ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return walletTransactionList;
	}
	@Override
	public Page<ServiceResponse> showRechargeHistory(Integer companyId,Pageable pageable) throws HelthwellExceptionHandler {
		Page<ServiceResponse> serviceResponseList = null;
		try {
			serviceResponseList=serviceResponseRepository.findAll(companyId,pageable);
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportDaoImpl - > showRechargeHistory ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportDaoImpl - > showRechargeHistory ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return serviceResponseList;
	}
	@Override
	public Page<ServiceResponse> showReportByServiceId(Integer serviceId,Integer companyId,Pageable pageable) throws HelthwellExceptionHandler {
		Page<ServiceResponse> serviceResponseList = null;
		try {
			Date curDate1=CalendarUtil.getISTDate();
			java.sql.Date curDate=new java.sql.Date(curDate1.getTime());
			
				if(companyId != 1){
				serviceResponseList=serviceResponseRepository.showReportByServiceId(serviceId,companyId,pageable,curDate);
				}else {
					serviceResponseList=serviceResponseRepository.showReportByServiceId(serviceId,pageable,curDate);
	
				}
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportDaoImpl - > showReportByServiceId ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportDaoImpl - > showReportByServiceId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return serviceResponseList;
	}
	@Override
	public List<ServiceResponse> getPendingTransaction() throws HelthwellExceptionHandler {
		List<ServiceResponse> serviceResponseList = new ArrayList<ServiceResponse>();
		try {
			serviceResponseList=serviceResponseRepository.findAllPendingTransaction();
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportDaoImpl - > showRechargeHistory ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportDaoImpl - > showRechargeHistory ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return serviceResponseList;
	}
	@Override
	public void changeStatus(ServiceResponse serviceResponse) throws HelthwellExceptionHandler {
		try {
			
			serviceResponseRepository.save(serviceResponse);
			
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportDaoImpl - > changeStatus() ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportDaoImpl - > changeStatus() ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		
	}
	@Override
	public Page<ServiceResponse> getLiveReport(Date startDate, Date endDate,Integer companyId,Pageable pageable) throws HelthwellExceptionHandler {
		Page<ServiceResponse> serviceResponseList = null;
		try {
			Date curDate1=CalendarUtil.getISTDate();
			java.sql.Date curDate=new java.sql.Date(curDate1.getTime());
			if(companyId==1 && startDate==null &&  endDate==null) {
			serviceResponseList=serviceResponseRepository.findAll(pageable,curDate);
			}
			else if(companyId==1 && startDate!=null &&  endDate!=null) {
				java.sql.Date startSqlDate=new java.sql.Date(startDate.getTime());
				java.sql.Date endSqlDate=new java.sql.Date(endDate.getTime());
				serviceResponseList=serviceResponseRepository.getLiveReport(startSqlDate,endSqlDate,pageable);
			}
			else if(companyId!=1 && startDate!=null &&  endDate!=null) {
				java.sql.Date startSqlDate=new java.sql.Date(startDate.getTime());
				java.sql.Date endSqlDate=new java.sql.Date(endDate.getTime());
				serviceResponseList=serviceResponseRepository.getLiveReportByDate(startSqlDate,endSqlDate,companyId,pageable);
			}
			
			else {
				serviceResponseList=serviceResponseRepository.findAllBycompanyId(companyId,pageable,curDate);
		
			}
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportDaoImpl - > getLiveReport ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportDaoImpl - > getLiveReport ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return serviceResponseList;

	}
	
	@Override
	public Page<MoneyTransferResponse> showMoneyTransferHistory(Integer companyId,Pageable pageable) throws HelthwellExceptionHandler {
		Page<MoneyTransferResponse> paymentList=null;
		try {
			
			Date curDate1=new Date();
			java.sql.Date curDate=new java.sql.Date(curDate1.getTime());
			if(companyId!=1) {
				paymentList=moneyTransferResponseRepo.findAllByCompanyId(companyId,pageable, curDate);
			}else {
				paymentList=moneyTransferResponseRepo.findAllMoneyTransferReport(pageable,curDate);
			}
			
			return paymentList;
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportDaoImpl - > showMoneyTransferHistory() ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportDaoImpl - > showMoneyTransferHistory() ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		
	}
	@Override
	public Page<MoneyTransferResponse> showMoneyTransferHistoryByDate(Integer companyId,Date startDate, Date endDate,Pageable pageable) throws HelthwellExceptionHandler {
		Page<MoneyTransferResponse> paymentList=null;
		try {
			java.sql.Date startSqlDate=new java.sql.Date(startDate.getTime());
			java.sql.Date endSqlDate=new java.sql.Date(endDate.getTime());
			if(companyId!=1) {
				paymentList=moneyTransferResponseRepo.showMoneyTransferHistoryByDateAndCompanyId(companyId,startSqlDate,endSqlDate,pageable);
			}else {
				paymentList=moneyTransferResponseRepo.showMoneyTransferHistoryByDate(startSqlDate,endSqlDate,pageable);
				
			}
			
			return paymentList;
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportDaoImpl - > showMoneyTransferHistory() ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportDaoImpl - > showMoneyTransferHistory() ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}
	@Override
	public List<ServiceResponse> showAllReportByServiceId(Integer serviceId, Integer companyId)
			throws HelthwellExceptionHandler {
		List<ServiceResponse> serviceResponseList = null;
		try {
				if(companyId != 1){
				serviceResponseList=serviceResponseRepository.showAllReportByServiceId(serviceId,companyId);
				}else {
					serviceResponseList=serviceResponseRepository.showAllReportByServiceId(serviceId);
	
				}
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportDaoImpl - > showAllReportByServiceId ",
					he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportDaoImpl - > showAllReportByServiceId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return serviceResponseList;
	}
	@Override
	public List<ServiceResponse> getAllLiveReport(Integer companyId) throws HelthwellExceptionHandler {
		List<ServiceResponse> serviceResponseList = null;
		try {
			Date date = CalendarUtil.getISTDate();

			if (companyId == 1) {
				serviceResponseList = serviceResponseRepository.findAll();
			}
			else {
				serviceResponseList = serviceResponseRepository.findAllBycompanyId(companyId);
			}

		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportDaoImpl - > getLiveReport ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportDaoImpl - > getLiveReport ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return serviceResponseList;
	}
	@Override
	public List<MoneyTransferResponse> showAllMoneyTransferHistory(Integer companyId) throws HelthwellExceptionHandler {
		List<MoneyTransferResponse> paymentList=null;
		try {
			
			if(companyId!=1) {
				paymentList=moneyTransferResponseRepo.findAllByCompanyId(companyId);
			}else {
				paymentList=moneyTransferResponseRepo.findAll();
			}
			
			return paymentList;
			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportDaoImpl - > showMoneyTransferHistory() ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportDaoImpl - > showMoneyTransferHistory() ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}
	@Override
	public DashbordDto getDashbordData(Integer companyId) throws HelthwellExceptionHandler {
		DashbordDto dashbordDto=new DashbordDto();
		Object obj = new Object();
		try {
			Date curDate1=CalendarUtil.getISTDate();
			java.sql.Date curDate=new java.sql.Date(curDate1.getTime());
			if(companyId==1) {
				Query query = entityManager.createQuery("SELECT SUM(amount) from ServiceResponse where DATE(time)= :curDate ");
				query.setParameter("curDate", curDate);
				obj=query.getSingleResult();
				if(obj!=null)
				dashbordDto.setRechargeAmount(Double.valueOf(obj.toString()));
				
				query = entityManager.createNativeQuery("select sum(margine) from service_response where Date(time)= :curDate");
				query.setParameter("curDate", curDate);
				obj=query.getSingleResult();
				if(obj!=null)
				dashbordDto.setRechargeMargin(Double.valueOf(obj.toString()));
				
				query = entityManager.createNativeQuery("select sum(surcharge) from service_response where Date(time)= :curDate ");
				query.setParameter("curDate", curDate);
				obj=query.getSingleResult();
				if(obj!=null)
				dashbordDto.setRechargeSurcharge(Double.valueOf(obj.toString()));
				
				query = entityManager.createNativeQuery("select sum(final_amount) from service_response where Date(time)= :curDate ");
				query.setParameter("curDate", curDate);
				obj=query.getSingleResult();
				if(obj!=null)
				dashbordDto.setRechargeTotal(Double.valueOf(obj.toString()));
				
				query = entityManager.createNativeQuery("select sum(amount) from money_transfer_response where Date(created_on)= :curDate ");
				query.setParameter("curDate", curDate);
				obj=query.getSingleResult();
				if(obj!=null)
				dashbordDto.setMoneyTransferAmount(Double.valueOf(obj.toString()));
				
				query = entityManager.createNativeQuery("select sum(charged_amt) from money_transfer_response where Date(created_on)= :curDate ");
				query.setParameter("curDate", curDate);
				obj=query.getSingleResult();
				if(obj!=null)
				dashbordDto.setMoneyTransferSurcharge(Double.valueOf(obj.toString()));
			

			
			}else {
				Query query = entityManager.createNativeQuery("select sum(amount) from service_response where Date(time)= :curDate and company_id= :companyId");
				query.setParameter("curDate", curDate);
				query.setParameter("companyId", companyId);
				Object result=query.getSingleResult();
				if(result!=null)
				dashbordDto.setRechargeAmount(Double.valueOf(result.toString()));
				
				query = entityManager.createNativeQuery("select sum(margine) from service_response where Date(time)= :curDate and company_id= :companyId");
				query.setParameter("curDate", curDate);
				query.setParameter("companyId", companyId);
				result=query.getSingleResult();
				if(result!=null)
				dashbordDto.setRechargeMargin(Double.valueOf(result.toString()));
				
				query = entityManager.createNativeQuery("select sum(surcharge) from service_response where Date(time)= :curDate  and company_id= :companyId");
				query.setParameter("curDate", curDate);
				query.setParameter("companyId", companyId);
				result=query.getSingleResult();
				if(result!=null)
				dashbordDto.setRechargeSurcharge(Double.valueOf(result.toString()));
				
				query = entityManager.createNativeQuery("select sum(final_amount) from service_response where Date(time)= :curDate and company_id= :companyId");
				query.setParameter("curDate", curDate);
				query.setParameter("companyId", companyId);
				result=query.getSingleResult();
				if(result!=null)
				dashbordDto.setRechargeTotal(Double.valueOf(result.toString()));
				
				query = entityManager.createNativeQuery("select sum(amount) from money_transfer_response where Date(created_on)= :curDate and company_id= :companyId");
				query.setParameter("curDate", curDate);
				query.setParameter("companyId", companyId);
				result=query.getSingleResult();
				if(result!=null)
				dashbordDto.setMoneyTransferAmount(Double.valueOf(result.toString()));
				
				query = entityManager.createNativeQuery("select sum(charged_amt) from money_transfer_response where Date(created_on)= :curDate and company_id= :companyId");
				query.setParameter("curDate", curDate);
				query.setParameter("companyId", companyId);
				result=query.getSingleResult();
				if(result!=null)
				dashbordDto.setMoneyTransferSurcharge(Double.valueOf(result.toString()));
			
			
			}
			return dashbordDto;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ReportDaoImpl - > getDashbordData() ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ReportDaoImpl - > getDashbordData() ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}
	
	}


