package com.bcoss.mtrans.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bcoss.mtrans.jpa.CompanyMargine;

public interface CompanyMargineRepository extends JpaRepository<CompanyMargine, Integer> {

	@Query("select u from CompanyMargine u where  u.planId= :planId")
	public List<CompanyMargine> findAllByPlanId(@Param("planId") Integer planId);
	
	@Query("select u from CompanyMargine u where  u.companyId= :companyId and u.operatorId= :operatorId")
	public List<CompanyMargine> findAllByOperatorAndComopanyId(@Param("companyId") Integer companyId,@Param("operatorId") Integer operatorId);

	@Query("select u from CompanyMargine u where  u.serviceId= :serviceId")
	public List<CompanyMargine> findAll(@Param("serviceId")Integer serviceId);

	@Query("select u from CompanyMargine u where  u.companyId= :companyId")
	public List<CompanyMargine> findAllByCompanyId(@Param("companyId")Integer companyId);

	@Query("select u from CompanyMargine u where  u.margineType= :margineType")
	public List<CompanyMargine> getAllCompanyMargineByMargineType(@Param("margineType")Integer margineType);
	
	@Query("select u from CompanyMargine u where  u.margineType= :margineType and u.companyId= :companyId and u.serviceId= :serviceId")
	public List<CompanyMargine> getMargineData(@Param("margineType")Integer margineType, @Param("companyId")Integer companyId,@Param("serviceId") Integer serviceId);
	
	@Query("SELECT u FROM CompanyMargine u where  u.operatorId= :operatorId and u.companyId= :companyId and u.serviceId= :serviceId and u.margineType= :margineType")
	public List<CompanyMargine> checkExist(@Param("companyId")Integer companyId, @Param("serviceId")Integer serviceId, @Param("operatorId")Integer operatorId,@Param("margineType") Integer margineType);

	@Query("SELECT u FROM CompanyMargine u where   u.companyId= :companyId and u.margineType= :margineType")
	public List<CompanyMargine> getDefaultMargine(@Param("companyId")Integer companyId,@Param("margineType") Integer margineType);

}
