/*
 * Copyright Currencies Direct Ltd 2013-2015. All rights reserved worldwide.
 * Currencies Direct Ltd PROPRIETARY/CONFIDENTIAL.
 */
package com.bcoss.mtrans.util;

// TODO: Auto-generated Javadoc
/**
 * The Interface WebAppConstants.
 */
public interface WebAppConstants {

	public String DEFAULT_VALUE = "SpinPortal";
	
	/*public String APP_NAME = "/admin-portal";*/
	
	public String APP_NAME = "";

	public String APP_PATH="";
	/** The error code. */
	public String ERROR_CODE = "errorCode";

	/** The view name. */
	public String VIEW_NAME = "viewName";

	/** The flowdata. */
	public String FLOWDATA = "flowData";

	/** The islogedin. */
	public String ISLOGEDIN = "isLoggedIn";

	public String URL_SEPERATOR = "/";

	public String APP_CONTENT_TYPE = "application/json";

	public String USERNAME = "userName";
	
	public String employeeId ="employeeId";

	public String PASSWORD = "password";

	public String LW_SUCESS_ADD = "LW_SUCESS_ADD";
	
	public String LW_SUCESS_ASSIGN = "LW_SUCESS_ASSIGN";

	public String LW_SUCESS_GETALL = "LW_SUCESS_GETALL";

	public String LW_SUCESS_EDIT = "LW_SUCESS_EDIT";

	public String LW_SUCESS_DELETE = "LW_SUCESS_DELETE";

	public String SUCESS_MESSAGE = "sucessMessage";

	public String USER = "user";

	public String ROLEID = "roleId";

	public String EMPID = "empId";

	public String ORG_ID = "orgId";

	public String ALREADYCLOCKEDIN = "alreadyClockedIn";

	public String EP_PASSWORD_CHANGE_SUCCESS = "EP_PASSWORD_CHANGE_SUCCESS";

	public String EP_PASSWORD_CHANGE_FAIL = " EP_PASSWORD_CHANGE_FAIL";

	public String EMPUSER = "empUser";

	public String VENDORUSER = "vendorUser";

	public String USERID = "userId";

	public String FIRSTNAME = "firstName";
	
	public String EMAIL_ID = "emailId";
	
	public String IMAGE_SERVER_URL = "image_server_url";

	public String PURCHASEDATA = "purchaseData";

	public String VENDORID = "vendorId";
	
	public String EMPLOYEE = "employee";
	
	public String MARGINE = "margine";
	
	public String SERVICE_LIST = "service_list";
	
	public String PLAN_LIST = "plan_list";
	
	
	/*Sachin */
	public String PURCHASE="purchase";
	
	public String SITEID = "siteId";

	public String EMPLOYEEID = "employeeId";

	public String COMPANYID = "companyId";

	public String PLANID = "planId";

	public String CIRCLECODE = "circleCode";

	public String WALLETID = "walletId";

	public String COMPANYTYPE = "companyType";

	public Object LIST = "list";

	public String IS_READONLY = "isReadOnly";



}