package com.bcoss.mtrans.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bcoss.mtrans.dao.repository.PlansRepository;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.Plans;

@Repository
public class PlansDaoImpl implements PlansDao {
	private Logger logger = LoggerFactory.getLogger(PlansDaoImpl.class);

	@Autowired
	private PlansRepository plansRepository;

	@Override
	public List<Plans> getAllPlans() throws HelthwellExceptionHandler {
		List<Plans> plansList = new ArrayList<Plans>();
		try {

			plansList = plansRepository.findAll();

		} catch (HibernateException he) {
			logger.error("HibernateException Error in PlansDaoImpl - > getAllPlans ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PlansDaoImpl - > getAllPlans ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return plansList;
	}

	@Override
	public Plans getPlansById(Integer plansId) throws HelthwellExceptionHandler {
		Plans plans = new Plans();
		try {

			plans = plansRepository.findOne(plansId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in PlansDaoImpl - > getPlansById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in PlansDaoImpl - > getPlansById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

		return plans;
	}
}
