package com.bcoss.mtrans.mapper;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.dto.CategoryDto;
import com.bcoss.mtrans.jpa.Category;

public class CategoryMapper {

	public static CategoryDto _toDto(Category category) {

		ModelMapper mapper = new ModelMapper();
		CategoryDto dtoObject = mapper.map(category, CategoryDto.class);
		return dtoObject;
	}

	public static Category _toJpa(CategoryDto categoryDto) {

		ModelMapper mapper = new ModelMapper();
		Category jpaObject = mapper.map(categoryDto, Category.class);
		return jpaObject;
	}
}
