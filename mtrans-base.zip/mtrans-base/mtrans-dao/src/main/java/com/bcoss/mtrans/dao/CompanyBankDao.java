package com.bcoss.mtrans.dao;

public interface CompanyBankDao {

}
