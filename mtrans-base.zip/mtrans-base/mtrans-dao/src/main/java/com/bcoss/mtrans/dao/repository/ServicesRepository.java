package com.bcoss.mtrans.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bcoss.mtrans.jpa.Services;

public interface ServicesRepository extends JpaRepository<Services, Integer>{

	@Query("select u from Services u where  u.planId= :planId")
	public List<Services> findAllByPlanId(@Param("planId") Integer planId);
}
