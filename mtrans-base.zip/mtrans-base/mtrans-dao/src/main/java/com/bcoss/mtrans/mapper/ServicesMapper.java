package com.bcoss.mtrans.mapper;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.dto.ServicesDto;
import com.bcoss.mtrans.jpa.Services;

public class ServicesMapper {

	public static ServicesDto _toDto(Services services) {

		ModelMapper mapper = new ModelMapper();
		ServicesDto dtoObject = mapper.map(services, ServicesDto.class);
		return dtoObject;
	}

	public static Services _toJpa(ServicesDto servicesDto) {

		ModelMapper mapper = new ModelMapper();
		Services jpaObject = mapper.map(servicesDto, Services.class);
		return jpaObject;
	}

}
