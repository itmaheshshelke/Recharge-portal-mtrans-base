package com.bcoss.mtrans.util;

import com.bcoss.mtrans.email.EmailMessage;

public interface EmailLogic {

	public void send(EmailMessage message);
}
