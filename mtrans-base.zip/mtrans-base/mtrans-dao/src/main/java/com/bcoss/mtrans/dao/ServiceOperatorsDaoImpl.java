package com.bcoss.mtrans.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bcoss.mtrans.dao.repository.ServiceOperatorsRepository;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.ServiceOperators;

@Repository
@Transactional
public class ServiceOperatorsDaoImpl implements ServiceOperatorsDao {
	private Logger logger = LoggerFactory.getLogger(ServiceOperatorsDaoImpl.class);

	@Autowired
	private ServiceOperatorsRepository serviceOperatorsRepository;

	@Override
	public List<ServiceOperators> getAllServiceOperators() throws HelthwellExceptionHandler {

		List<ServiceOperators> serviceOperatorsList = new ArrayList<ServiceOperators>();
		try {
			serviceOperatorsList = serviceOperatorsRepository.findAll();
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServiceOperatorsDaoImpl - > getAllServiceOperators ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServiceOperatorsDaoImpl - > getAllServiceOperators ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return serviceOperatorsList;
	}

	@Override
	public ServiceOperators getServiceOperatorsById(Integer serviceId) throws HelthwellExceptionHandler {

		ServiceOperators serviceOperators = new ServiceOperators();
		try {
			serviceOperators = serviceOperatorsRepository.findOne(serviceId);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServiceOperatorsDaoImpl - > getServiceOperatorsById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServiceOperatorsDaoImpl - > getServiceOperatorsById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return serviceOperators;

	}

	@Override
	public Boolean saveServiceOperators(ServiceOperators serviceOperators) throws HelthwellExceptionHandler {

		Boolean result = false;
		try {
			serviceOperatorsRepository.save(serviceOperators);
			result = true;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServiceOperatorsDaoImpl - > getServiceOperatorsById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {

			logger.error("Exception Error in ServiceOperatorsDaoImpl - > getServiceOperatorsById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public Boolean deleteServiceOperators(Integer serviceId) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			ServiceOperators serviceOperators = serviceOperatorsRepository.findOne(serviceId);
			serviceOperatorsRepository.delete(serviceOperators);
			result = true;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServiceOperatorsDaoImpl - > getServiceOperatorsById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {

			logger.error("Exception Error in ServiceOperatorsDaoImpl - > getServiceOperatorsById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public List<ServiceOperators> getOperatorByServiceId(Integer serviceId) throws HelthwellExceptionHandler {
		List<ServiceOperators> serviceOperatorsList = new ArrayList<ServiceOperators>();
		try {
			serviceOperatorsList = serviceOperatorsRepository.getOperatorByServiceId(serviceId);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServiceOperatorsDaoImpl - > getOperatorByServiceId ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServiceOperatorsDaoImpl - > getOperatorByServiceId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return serviceOperatorsList;
	}

	@Override
	public ServiceOperators getServiceOperatorsByOperaterId(Integer operatorId) throws HelthwellExceptionHandler {
		ServiceOperators serviceOperators = new ServiceOperators();
		try {
			serviceOperators = serviceOperatorsRepository.findOne(operatorId);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServiceOperatorsDaoImpl - > getServiceOperatorsByOperaterId ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServiceOperatorsDaoImpl - > getServiceOperatorsByOperaterId ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return serviceOperators;
	}

}
