package com.bcoss.mtrans.dao;

import com.bcoss.mtrans.dto.PaymentDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface paymentDao {

	Boolean payment(PaymentDto paymentDto)throws HelthwellExceptionHandler;

}
