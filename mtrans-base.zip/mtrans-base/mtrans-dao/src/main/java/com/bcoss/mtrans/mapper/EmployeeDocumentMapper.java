package com.bcoss.mtrans.mapper;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.dto.EmployeeDocumentDto;
import com.bcoss.mtrans.jpa.EmployeeDocument;

public class EmployeeDocumentMapper {

	
	
	public static EmployeeDocumentDto _toDto(EmployeeDocument employeeDocument) {

		ModelMapper mapper = new ModelMapper();
		EmployeeDocumentDto dtoObject = mapper.map(employeeDocument, EmployeeDocumentDto.class);

		return dtoObject;
	}
	
	
	
	public static EmployeeDocument _toJpa(EmployeeDocumentDto employeeDocumentDto) {

		ModelMapper mapper = new ModelMapper();
		EmployeeDocument jpaObject = mapper.map(employeeDocumentDto, EmployeeDocument.class);

		return jpaObject;
	}
}
