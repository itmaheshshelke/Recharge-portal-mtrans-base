package com.bcoss.mtrans.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bcoss.mtrans.jpa.Category;

public interface CategoryRepository extends JpaRepository<Category, Integer>{

	@Query("select u from Category u where u.applicationTypeId= :applicationTypeId ")
	List<Category> getCategoryByApplicationTypeId(@Param("applicationTypeId")Integer applicationTypeId);

}
