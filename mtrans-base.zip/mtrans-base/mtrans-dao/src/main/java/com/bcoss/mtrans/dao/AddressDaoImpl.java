package com.bcoss.mtrans.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bcoss.mtrans.Address;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;


@Repository
public class AddressDaoImpl  implements AddressDao {
	
	private Logger logger = LoggerFactory.getLogger(AddressDaoImpl.class);

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	AddressReposiotory reposiotory;
	
	public List<Address> getAllAddress() throws HelthwellExceptionHandler {

		List<Address> addressList = new ArrayList<Address>();

		try {
			addressList=reposiotory.findAllActive();
			if (addressList != null && addressList.size() > 0) {
				return addressList;
			} else {
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.NO_ADDRESS_FOUND);
			}
		} catch (HelthwellExceptionHandler ex) {
			throw ex;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in AddressDaoImpl - > getAddresss ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in AddressDaoImpl - > getAddresss ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}
	}

	public Address getAddressById(int addressId) throws HelthwellExceptionHandler {

		try {
			Address address = reposiotory.findOne(addressId);
			return address;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in AddressDaoImpl - > getAddressById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in AddressDaoImpl - > getAddressById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public boolean addAddress(Address address) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			address.setDelFlag('N');
			reposiotory.save(address);
			
			if(address.getAddressId()!=null) {
				result=true;				
			}else {
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.ADDRESS_ALREADY_EXIST);
			}
			return result;
		} catch (HelthwellExceptionHandler ex) {
			throw ex;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in AddressDaoImpl - > addAddress ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in AddressDaoImpl - > addAddress ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public boolean updateAddress(Address address) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			reposiotory.save(address);
			result = true;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in AddressDaoImpl - > updateAddress ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in AddressDaoImpl - > updateAddress ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;

	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public boolean deleteAddress(int addressId) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			Query query = entityManager.createQuery("UPDATE Address SET  delFlag = 'Y' WHERE addressId = :id");
			query.setParameter("id", addressId);
			int updateResult = query.executeUpdate();

			if (updateResult != 0) {
				result = true;
			} else {
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.NO_ADDRESS_FOUND);
			}
			return result;
		} catch (HelthwellExceptionHandler ex) {
			throw ex;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in AddressDaoImpl - > deleteAddress ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in AddressDaoImpl - > deleteAddress ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

	}


}
