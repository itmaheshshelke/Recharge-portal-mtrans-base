package com.bcoss.mtrans.util;

public class MoneyTransferUtil {
	
	

}
