package com.bcoss.mtrans.dao;

import java.util.List;

import com.bcoss.mtrans.dto.MargineDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.jpa.CompanyMargine;

public interface CompanyMargineDao {
	List<CompanyMargine> getAllCompanyMargine(Integer serviceId)throws HelthwellExceptionHandler;

	CompanyMargine getCompanyMargineById(Integer companyMargineId)throws HelthwellExceptionHandler;
	
	public CompanyMargine getCompanyMargineByCompanyAndOperatorId(Integer companyId ,Integer operatorId)throws HelthwellExceptionHandler;

	Boolean saveCompanyMargine(CompanyMargine companyMargine)throws HelthwellExceptionHandler;

	List<CompanyMargine> getMarginByPlanId(Integer planId)throws HelthwellExceptionHandler;

	List<CompanyMargine> getAllCompanyMargineBycompanyId(Integer companyId)throws HelthwellExceptionHandler;

	List<CompanyMargine> getAllCompanyMargineByMargineType(Integer margineType, Integer companyId, Integer serviceId)throws HelthwellExceptionHandler;

	List<MargineDto> getMargineData(Integer margineType, Integer serviceId)throws HelthwellExceptionHandler;


}
