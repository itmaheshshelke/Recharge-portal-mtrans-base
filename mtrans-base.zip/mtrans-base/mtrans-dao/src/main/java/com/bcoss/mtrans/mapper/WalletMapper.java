package com.bcoss.mtrans.mapper;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.dto.WalletDto;
import com.bcoss.mtrans.jpa.Wallet;

public class WalletMapper {
	
	public static WalletDto _toDto(Wallet wallet) {

		ModelMapper mapper = new ModelMapper();
		WalletDto dtoObject = mapper.map(wallet, WalletDto.class);
		return dtoObject;
	}

	public static Wallet _toJpa(WalletDto walletDto) {

		ModelMapper mapper = new ModelMapper();
		Wallet jpaObject = mapper.map(walletDto, Wallet.class);
		return jpaObject;
	}

}
