package com.bcoss.mtrans.mapper;


import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.Employee;
import com.bcoss.mtrans.EmployeeDto;

public class EmployeeMapper {
	
	
	public static EmployeeDto _toDto(Employee employee) {

		ModelMapper mapper = new ModelMapper();
		EmployeeDto dtoObject = mapper.map(employee, EmployeeDto.class);
		return dtoObject;
	}

	public static Employee _toJpa(EmployeeDto employeeDto) {

		ModelMapper mapper = new ModelMapper();
		Employee jpaObject = mapper.map(employeeDto, Employee.class);
		return jpaObject;
	}

}
