package com.bcoss.mtrans.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.sms.SmsInbox;
import com.bcoss.mtrans.jpa.sms.SmsProviderSetting;
import com.bcoss.mtrans.jpa.sms.Template;

@Repository
@Transactional
public class SmsDaoImpl implements SmsDao {

	@PersistenceContext
	private  EntityManager entityManager;
	Logger logger = LoggerFactory.getLogger(SmsDaoImpl.class);

	@Override
	public SmsProviderSetting getSmsConfig(int smsProviderSettingId) throws HelthwellExceptionHandler {
		TypedQuery<SmsProviderSetting> customerQuery;
		List<SmsProviderSetting> smsProviderSettingList = new ArrayList<SmsProviderSetting>();
		try {
			customerQuery = entityManager.createQuery("SELECT s FROM SmsProviderSetting s where smsProviderSettingId=:smsProviderSettingId ", SmsProviderSetting.class);
			customerQuery.setParameter("smsProviderSettingId", smsProviderSettingId);
			smsProviderSettingList = customerQuery.getResultList();
			if (smsProviderSettingList.size() == 0) {
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.SMS_CONFIG_NOT_FOUND);
			}
			return smsProviderSettingList.get(0);

		} catch (HelthwellExceptionHandler exception) {
			throw exception;
		} catch (Exception e) {
			logger.error("Exception Error in SmsDaoImpl - > getSmsConfig ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public boolean saveSms(String mobileNo, String service, String mode, String messageId, int templateId,Integer clinicId)
			throws HelthwellExceptionHandler {

		boolean Result = false;
		try {
			SmsInbox smsInboxJpa = new SmsInbox();
			
			smsInboxJpa.setSmsTemplateType("NEW_COMPANY");
			smsInboxJpa.setSmsTransactionId(messageId);
			smsInboxJpa.setService(service);
			smsInboxJpa.setCompanyId(clinicId);
			smsInboxJpa.setStatus(1);
			entityManager.persist(smsInboxJpa);
			entityManager.flush();
			Result = true;
			
			return Result;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in SmsDaoImpl - > saveSms", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in SmsDaoImpl - > saveSms ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public String getDeliveryReport(String mobileNo, String messageId, String status) throws HelthwellExceptionHandler {
		String result = "";
		// TypedQuery<SmsInbox> query;
		try {

			Query query1 = entityManager
					.createQuery("UPDATE SmsInbox SET  status = :status WHERE smsTransactionId = :messageId");
			query1.setParameter("status", status);

			query1.setParameter("messageId", messageId);
			int res = query1.executeUpdate();
			if (res != 0) {
				result = status;
			}

			
		} catch (HibernateException he) {
			logger.error("HibernateException Error in SmsDaoImpl - > getDeliveryReport", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in SmsDaoImpl - > getDeliveryReport ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}
		return result;
	}

	@Override
	public Template getSmsTempalte(Integer templateId) throws HelthwellExceptionHandler {
		TypedQuery<Template> customerQuery;
		List<Template> smsTemplateJpa = new ArrayList<Template>();
		try {
			customerQuery = entityManager.createQuery("SELECT s FROM Template s where templateId=:templateId ", Template.class);
			customerQuery.setParameter("templateId", templateId);
			smsTemplateJpa = customerQuery.getResultList();
			if (smsTemplateJpa.size() == 0) {
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.SMS_CONFIG_NOT_FOUND);
			}
			return smsTemplateJpa.get(0);

		} catch (HelthwellExceptionHandler exception) {
			throw exception;
		} catch (Exception e) {
			logger.error("Exception Error in SmsDaoImpl - > getSmsConfig ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}
	}
}
