package com.bcoss.mtrans.dao;

import java.util.List;

import com.bcoss.mtrans.Address;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface AddressDao {

	List<Address> getAllAddress() throws HelthwellExceptionHandler;
	Address getAddressById(int id) throws HelthwellExceptionHandler;
	boolean addAddress(Address address) throws HelthwellExceptionHandler;
	boolean updateAddress(Address address) throws HelthwellExceptionHandler;
	boolean deleteAddress(int id) throws HelthwellExceptionHandler;
    
}
