package com.bcoss.mtrans.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bcoss.mtrans.CompanyDetails;
import com.bcoss.mtrans.jpa.WalletTransaction;

public interface WalletTransactionRepository extends JpaRepository<WalletTransaction, Integer> {
	
	@Query("select r from WalletTransaction r where r.walletId= :walletId ORDER BY r.transDate DESC" )
	List<WalletTransaction> getAllCompanyTransaction(@Param("walletId") Integer walletId);

	@Query("select r from WalletTransaction r where r.parentId= :login_companyId and r.transStatus='PENDING' ORDER BY r.transDate DESC" )
	List<WalletTransaction> getAllRequestRecharge(@Param("login_companyId")Integer login_companyId);

	@Query("select r from WalletTransaction r where r.transNumber= :transNumber" )
	WalletTransaction findWalletTransactionByWalletId(@Param("transNumber") String transNumber);

}
