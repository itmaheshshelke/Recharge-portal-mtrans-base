package com.bcoss.mtrans.constant;

public class SmsSettingsConstant {

	public static final String USERNAME = "henx";
	public static final String PASSWORD = "HenxServer@17";
	public static final String SENDER_ID = "GRENRY";
	public static final String STATUS = "1";
	public static final String URL = "https://aikonsms.co.in/control/smsapi.php?";
	
}
