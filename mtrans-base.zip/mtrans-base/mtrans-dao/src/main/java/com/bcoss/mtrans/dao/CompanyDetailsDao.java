package com.bcoss.mtrans.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bcoss.mtrans.CompanyDetails;
import com.bcoss.mtrans.Employee;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface CompanyDetailsDao {
	
	List<CompanyDetails> getAllCompanyDetails(Integer companyId) throws HelthwellExceptionHandler;
	CompanyDetails getCompanyDetailsById(int id) throws HelthwellExceptionHandler;
	Employee addCompanyDetails(CompanyDetails companyDetails) throws HelthwellExceptionHandler;
	boolean updateCompanyDetails(CompanyDetails companyDetails) throws HelthwellExceptionHandler;
	boolean deleteCompanyDetails(int id) throws HelthwellExceptionHandler;
	List<CompanyDetails> searchCompanyDetails(Integer companyId, String qString) throws HelthwellExceptionHandler;
	Page<CompanyDetails> getAllDistributors(Pageable pageable, Integer companyId, String searchTerm)throws HelthwellExceptionHandler;
	Page<CompanyDetails> getAllRetailers(Integer id, Pageable pageable, String searchTerm)throws HelthwellExceptionHandler;
	Boolean isMobileNoExits(String mobileNo)throws HelthwellExceptionHandler;

}
