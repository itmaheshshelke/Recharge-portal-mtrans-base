package com.bcoss.mtrans.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bcoss.mtrans.State;

public interface StateRepository extends JpaRepository<State, Integer> {

	
	

}

