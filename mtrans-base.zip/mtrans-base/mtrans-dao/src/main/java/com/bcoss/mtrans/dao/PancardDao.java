package com.bcoss.mtrans.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bcoss.mtrans.PanCardDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.jpa.Category;
import com.bcoss.mtrans.jpa.PanCard;

public interface PancardDao {

	Integer saveNewPancard(PanCardDto panCardDto)throws HelthwellExceptionHandler;

	Page<PanCard> getAllPancardRequest(Integer companyId, Integer appType, Pageable pageable)throws HelthwellExceptionHandler;

	void UpdatePancard(PanCardDto panCardDto)throws HelthwellExceptionHandler;

	PanCard getPanCardById(Integer panId)throws HelthwellExceptionHandler;

	List<Category> getCategoryByApplicationTypeId(Integer applicationTypeId)throws HelthwellExceptionHandler;;

}
