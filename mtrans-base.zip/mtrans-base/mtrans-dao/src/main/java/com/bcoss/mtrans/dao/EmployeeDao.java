package com.bcoss.mtrans.dao;

import java.util.List;

import com.bcoss.mtrans.Employee;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface EmployeeDao {

	List<Employee> getAllEmployee(Integer companyId)throws HelthwellExceptionHandler;

	Employee getEmployeeById(Integer employeeId)throws HelthwellExceptionHandler;

	Boolean updateEmployee(Employee employee)throws HelthwellExceptionHandler;

	Boolean saveEmployee(Employee employee)throws HelthwellExceptionHandler;

	Boolean deleteEmployee(Integer employeeId)throws HelthwellExceptionHandler;

}
