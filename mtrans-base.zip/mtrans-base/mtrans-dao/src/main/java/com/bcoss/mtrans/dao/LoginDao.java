package com.bcoss.mtrans.dao;

import com.bcoss.mtrans.ChangePasswordDto;
import com.bcoss.mtrans.Employee;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface LoginDao {

	Employee login(String userName, String password)throws HelthwellExceptionHandler;

	Employee sendOtp(String mobNo)throws HelthwellExceptionHandler;

	Boolean saveChangePassword(ChangePasswordDto changePasswordDto)throws HelthwellExceptionHandler;

}
