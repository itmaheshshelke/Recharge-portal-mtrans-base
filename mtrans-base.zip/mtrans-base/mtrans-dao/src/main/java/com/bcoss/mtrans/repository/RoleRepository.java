package com.bcoss.mtrans.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bcoss.mtrans.Role;

public interface RoleRepository extends JpaRepository<Role, Integer> {


	@Query("select r from Role r where r.delFlag = 'N' and r.isSysAdmin= 'N'" )
	public List<Role> findAll();
	
	
	@Query("select r from Role r where r.delFlag = 'N' and r.isSysAdmin= 'N' and r.roleId= :roleId" )
	public Role findOne(@Param("roleId")  Integer roleId);
	

}
