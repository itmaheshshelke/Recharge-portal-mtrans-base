package com.bcoss.mtrans.util;

public enum MessageStatus {
	
	PROCESSING ,
	SENT,
	FAILED,
	DND,
	DELIVERED,
	ASYNC
}
