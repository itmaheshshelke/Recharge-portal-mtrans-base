package com.bcoss.mtrans.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bcoss.mtrans.dto.DashbordDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.jpa.MoneyTransferResponse;
import com.bcoss.mtrans.jpa.ServiceResponse;
import com.bcoss.mtrans.jpa.WalletTransaction;

public interface ReportDao {

	public Page<ServiceResponse> showRechargeReportByDate(Integer serviceId, Date startDate, Date endDate, Integer companyId, Pageable pageable)throws HelthwellExceptionHandler;

	public List<WalletTransaction> showAllTransactionReport(Integer companyType)throws HelthwellExceptionHandler;

	public Page<ServiceResponse> showRechargeHistory(Integer companyId, Pageable pageable)throws HelthwellExceptionHandler;

	public Page<ServiceResponse> showReportByServiceId(Integer serviceId, Integer companyId, Pageable pageable)throws HelthwellExceptionHandler;

	public List<ServiceResponse> getPendingTransaction()throws HelthwellExceptionHandler;

	public void changeStatus(ServiceResponse serviceResponse)throws HelthwellExceptionHandler;

	public Page<ServiceResponse> getLiveReport(Date startDate, Date endDate, Integer companyId, Pageable pageable)throws HelthwellExceptionHandler;

	public Page<MoneyTransferResponse> showMoneyTransferHistory(Integer companyId, Pageable pageable)throws HelthwellExceptionHandler;

	public Page<MoneyTransferResponse> showMoneyTransferHistoryByDate(Integer companyId, Date startDate, Date endDate, Pageable pageable)throws HelthwellExceptionHandler;

	public List<ServiceResponse> showAllReportByServiceId(Integer serviceId, Integer companyId)throws HelthwellExceptionHandler;

	public List<ServiceResponse> getAllLiveReport(Integer companyId)throws HelthwellExceptionHandler;

	public List<MoneyTransferResponse> showAllMoneyTransferHistory(Integer companyId)throws HelthwellExceptionHandler;

	public DashbordDto getDashbordData(Integer companyId)throws HelthwellExceptionHandler;



}
