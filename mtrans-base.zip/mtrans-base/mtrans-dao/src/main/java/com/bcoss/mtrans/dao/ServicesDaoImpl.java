package com.bcoss.mtrans.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bcoss.mtrans.dao.repository.ServicesRepository;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.Services;

@Repository
@Transactional
public class ServicesDaoImpl implements ServicesDao {
	private Logger logger = LoggerFactory.getLogger(ServicesDaoImpl.class);

	@Autowired
	ServicesRepository servicesRepository;

	@Override
	public List<Services> getAllServices(Integer planId) throws HelthwellExceptionHandler {

		List<Services> servicesList = new ArrayList<Services>();
		try {
			servicesList = servicesRepository.findAllByPlanId(planId);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServicesDaoImpl - > getAllServices ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServicesDaoImpl - > getAllServices ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return servicesList;
	}

	@Override
	public Services getServicesById(Integer serviceId) throws HelthwellExceptionHandler {

		Services services = new Services();
		try {
			services = servicesRepository.findOne(serviceId);
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServicesDaoImpl - > getServicesById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in ServicesDaoImpl - > getServicesById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return services;

	}

	@Override
	public Boolean saveServices(Services services) throws HelthwellExceptionHandler {

		Boolean result = false;
		try {
			servicesRepository.save(services);
			result = true;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServicesDaoImpl - > getServicesById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {

			logger.error("Exception Error in ServicesDaoImpl - > getServicesById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public Boolean deleteServices(Integer serviceId) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			Services services = servicesRepository.findOne(serviceId);
			servicesRepository.delete(services);
			result = true;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in ServicesDaoImpl - > getServicesById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {

			logger.error("Exception Error in ServicesDaoImpl - > getServicesById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

}
