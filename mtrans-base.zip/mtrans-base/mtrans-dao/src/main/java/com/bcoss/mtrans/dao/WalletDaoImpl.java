package com.bcoss.mtrans.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bcoss.mtrans.CompanyDetails;
import com.bcoss.mtrans.CompanyDetailsDto;
import com.bcoss.mtrans.dto.WalletDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.Wallet;
import com.bcoss.mtrans.jpa.WalletTransaction;
import com.bcoss.mtrans.mapper.CompanyDetailsMapper;
import com.bcoss.mtrans.mapper.WalletMapper;
import com.bcoss.mtrans.repository.WalletRepository;
import com.bcoss.mtrans.repository.WalletTransactionRepository;
import com.bcoss.mtrans.util.CalendarUtil;

@Repository
@Transactional
public class WalletDaoImpl implements WalletDao {

	private Logger logger = LoggerFactory.getLogger(WalletDaoImpl.class);

	@Autowired
	WalletRepository walletRepository;

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	CompanyDetailsRepository companyDetailsRepository;

	@Autowired
	WalletTransactionRepository walletTransactionRepository;

	@Override
	public Wallet getwalletById(Integer walletId) throws HelthwellExceptionHandler {

		Wallet wallet = new Wallet();
		try {

			wallet = walletRepository.findOne(walletId);

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletDaoImpl - > getwalletById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalletDaoImpl - > getwalletById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return wallet;
	}

	@Override
	public List<CompanyDetailsDto> getAllCompanyWallateBalance(Integer companyId) throws HelthwellExceptionHandler {
		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<CompanyDetailsDto>();
		List<Object> objectList = new ArrayList<Object>();

		try {

			Query companyQuery = entityManager.createNativeQuery(
					"SELECT c.company_id,c.company_name, c.company_type, w.balance, c.is_active,c.wallet_id,c.contact_person_name,c.contact_no from company_details c INNER JOIN company_wallet w ON c.wallet_id=w.wallet_id\r\n"
							+ "WHERE c.created_by= :companyId and  c.del_flag = 'N' and c.is_active='1'");

			companyQuery.setParameter("companyId", companyId);

			objectList = companyQuery.getResultList();

			if (objectList != null && objectList.size() > 0) {

				Iterator itr = objectList.iterator();

				while (itr.hasNext()) {
					CompanyDetailsDto companyDetailsDto = new CompanyDetailsDto();

					Object[] element = (Object[]) itr.next();
					companyDetailsDto.setCompanyId(Integer.parseInt((element[0].toString())));
					companyDetailsDto.setCompanyName(element[1].toString());
					companyDetailsDto.setCompanyType(Integer.parseInt((element[2].toString())));
					companyDetailsDto.setBalance(Double.parseDouble(element[3].toString()));
					companyDetailsDto.setIsActive(Integer.parseInt((element[4].toString())));
					companyDetailsDto.setWalletId(Integer.parseInt((element[5].toString())));
					companyDetailsDto.setContactPersonName(element[6].toString());
					companyDetailsDto.setContactNo(element[7].toString());
					companyDetailsDtoList.add(companyDetailsDto);

				}
			} else {
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
			}
			return companyDetailsDtoList;

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletDaoImpl - > getAllCompanyWallateBalance ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalletDaoImpl - > getAllCompanyWallateBalance ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}

	@Override
	public List<CompanyDetails> companyRecharge(Integer companyId) throws HelthwellExceptionHandler {
		List<CompanyDetails> companyDetailsList = new ArrayList<CompanyDetails>();

		try {
			companyDetailsList = companyDetailsRepository.getAllRecharchCompany(companyId);

			return companyDetailsList;

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > getCompanyDetailss ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > getCompanyDetailss ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}

	@Override
	public List<WalletTransaction> getAllCompanyTransaction(Integer companyId) throws HelthwellExceptionHandler {
		List<WalletTransaction> walletTransactionList=new ArrayList<>();
		try {

			CompanyDetails companyDetails = companyDetailsRepository.findOne(companyId);
			Integer walletId = companyDetails.getWalletId();

			walletTransactionList= walletTransactionRepository.getAllCompanyTransaction(walletId);
			 

			return walletTransactionList;

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletDaoImpl - > getAllCompanyWallateBalance ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalletDaoImpl - > getAllCompanyWallateBalance ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}

	public Boolean updateWallet(WalletDto walletDto) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			Wallet wallet = WalletMapper._toJpa(walletDto);

			walletRepository.save(wallet);

			result = true;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletDaoImpl - > updateWallet ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalletDaoImpl - > updateWallet ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public Boolean saveRechargeWallet(WalletDto walletDto, Integer companyId, Double rechargeamount,Character type)
			throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			
			Long randomPass = Math.round(Math.random() * 1000000);
			String transactionId = "rkss" + String.valueOf(randomPass);
			if(companyId!=1) {
			CompanyDetails parentCompany=companyDetailsRepository.findOne(companyId);
			Wallet parentWallet= walletRepository.findOne(parentCompany.getWalletId());
			if(type=='C')
			parentWallet.setBalance(parentWallet.getBalance()-rechargeamount);
			else
			parentWallet.setBalance(parentWallet.getBalance()+rechargeamount);
			walletRepository.save(parentWallet);
			}
			
			WalletTransaction walletTransactionParent = new WalletTransaction();
			walletTransactionParent.setCreatedBy(companyId);
			walletTransactionParent.setCreatedOn(CalendarUtil.getISTDate());
			walletTransactionParent.setTransAmount(rechargeamount);
			walletTransactionParent.setTransDate(CalendarUtil.getISTDate());
			walletTransactionParent.setTransNumber(transactionId);
			walletTransactionParent.setTransType(type);
			walletTransactionParent.setWalletId(walletDto.getWalletId());
			walletTransactionParent.setTransStatus("success");
			walletTransactionRepository.save(walletTransactionParent);

			
			Wallet wallet = WalletMapper._toJpa(walletDto);
			walletRepository.save(wallet);

			
			result = true;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletDaoImpl - > saveRechargeWallet ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public Boolean addRequestRecharge(WalletTransaction walletTransaction) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			Long randomPass = Math.round(Math.random() * 1000000);
			String transactionId = "rkss" + String.valueOf(randomPass);
			walletTransaction.setTransNumber(transactionId);
			walletTransaction.setCreatedOn(CalendarUtil.getISTDate());

			walletTransactionRepository.save(walletTransaction);

			result = true;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletDaoImpl - > addRequestRecharge ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;

	}

	@Override
	public List<CompanyDetailsDto> getRequestRecharge(Integer login_companyId) throws HelthwellExceptionHandler {
		List<WalletTransaction> WalletTransactionList = new ArrayList<WalletTransaction>();
		List<CompanyDetailsDto> companyDetailsDtoList = new ArrayList<CompanyDetailsDto>();
		CompanyDetailsDto companyDetailsDto=null;
		try {
			WalletTransactionList = walletTransactionRepository.getAllRequestRecharge(login_companyId);
			
			for (WalletTransaction walletTransaction : WalletTransactionList) {
				companyDetailsDto=new CompanyDetailsDto();
				CompanyDetails companyDetails=companyDetailsRepository.getcompanyByWalletid(walletTransaction.getWalletId());
				companyDetailsDto=CompanyDetailsMapper._toDto(companyDetails);
				companyDetailsDto.setBalance(walletTransaction.getTransAmount());
				companyDetailsDto.setTransNumber(walletTransaction.getTransNumber());
				companyDetailsDtoList.add(companyDetailsDto);
			}

			return companyDetailsDtoList;

		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > getRequestRecharge ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > getRequestRecharge ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
	}

	@Override
	@Transactional
	public Boolean approveRequest(String transNumber,Integer login_walletId,Integer login_companyId) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			WalletTransaction walletTransaction = walletTransactionRepository.findWalletTransactionByWalletId(transNumber);
			Wallet wallet=walletRepository.findOne(walletTransaction.getWalletId());
			Double addBalance=walletTransaction.getTransAmount()+wallet.getBalance();
			Double deductBalance=wallet.getBalance()-walletTransaction.getTransAmount();	
			
			
			//add balance in request company
			Query query = entityManager.createQuery(
					"UPDATE Wallet SET  balance = :balance WHERE walletId = :walletId");
			query.setParameter("balance", addBalance);
			query.setParameter("walletId",walletTransaction.getWalletId());
			query.executeUpdate();
			
			
			Query walletTransactionQuery = entityManager.createQuery(
					"UPDATE WalletTransaction SET  transStatus = :transStatus WHERE walletTransactionId = :walletTransactionId");
			walletTransactionQuery.setParameter("walletTransactionId",walletTransaction.getWalletTransactionId());
			walletTransactionQuery.setParameter("transStatus","sucess");
			walletTransactionQuery.executeUpdate();
			
			
			
			//deduct balance in parent company
			Query deductBalanceLoginCopmany = entityManager.createQuery(
					"UPDATE Wallet SET  balance = :balance WHERE walletId = :walletId");
			deductBalanceLoginCopmany.setParameter("balance", deductBalance);
			deductBalanceLoginCopmany.setParameter("walletId",login_walletId);
			deductBalanceLoginCopmany.executeUpdate();
			
			
			Long randomPass = Math.round(Math.random() * 1000000);
			String transactionId = "rkss" + String.valueOf(randomPass);
			
			WalletTransaction walletTransactionP_copmany = new WalletTransaction();
			walletTransactionP_copmany.setCreatedBy(login_companyId);
			walletTransactionP_copmany.setCreatedOn(CalendarUtil.getISTDate());
			walletTransactionP_copmany.setTransAmount(walletTransaction.getTransAmount());
			walletTransactionP_copmany.setTransDate(CalendarUtil.getISTDate());
			walletTransactionP_copmany.setTransNumber(transactionId);
			walletTransactionP_copmany.setTransType('D');
			walletTransactionP_copmany.setWalletId(login_walletId);
			walletTransactionP_copmany.setTransStatus("success");

			walletTransactionRepository.save(walletTransaction);
			
			
			
			result = true;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletDaoImpl - > approveRequest ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}
	
	@Transactional
	@Override
	public Boolean activeDeactiveCompany(Integer compnayId,Integer isActive) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {
			
			Query deductBalanceLoginCopmany = entityManager.createQuery(
					"UPDATE CompanyDetails SET  isActive = :isActive WHERE companyId = :compnayId");
			deductBalanceLoginCopmany.setParameter("isActive", isActive);
			deductBalanceLoginCopmany.setParameter("compnayId",compnayId);
			deductBalanceLoginCopmany.executeUpdate();
			result=true;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > activeDeactiveCompany ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > activeDeactiveCompany ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

	@Override
	public Wallet getTotalWalletRecharge(Integer login_companyId) throws HelthwellExceptionHandler {
		Object object = new Object();
		Wallet wallet=new Wallet();
		try {

			Query companyQuery = entityManager.createNativeQuery(
					"SELECT sum(balance) from company_wallet where wallet_id in (SELECT wallet_id from company_details where parent_id= :companyId)");

			companyQuery.setParameter("companyId", login_companyId);
			object = companyQuery.getSingleResult();
			wallet.setBalance(Double.parseDouble(object.toString()));
		return wallet;

		} catch (HibernateException he) {
			logger.error("HibernateException Error in WalletDaoImpl - > getTotalWalletRecharge ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in WalletDaoImpl - > getTotalWalletRecharge ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

	}
	
	@Transactional
	@Override
	public Boolean readWriteCompany(Integer compnayId, Character isReadOnly) throws HelthwellExceptionHandler {
		Boolean result=false;
		try {
			
			Query deductBalanceLoginCopmany = entityManager.createQuery(
					"UPDATE CompanyDetails SET  isReadOnly = :isReadOnly WHERE companyId = :compnayId");
			deductBalanceLoginCopmany.setParameter("isReadOnly", isReadOnly);
			deductBalanceLoginCopmany.setParameter("compnayId",compnayId);
			deductBalanceLoginCopmany.executeUpdate();
			result=true;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > readWriteCompany ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > readWriteCompany ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;
	}

}
