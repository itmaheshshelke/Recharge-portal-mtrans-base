package com.bcoss.mtrans.mapper;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.dto.WalletTransactionDto;
import com.bcoss.mtrans.jpa.WalletTransaction;

public class WalletTransactionMapper {
	public static WalletTransactionDto _toDto(WalletTransaction jpaObject) {

		ModelMapper mapper = new ModelMapper();
		WalletTransactionDto dtoObject = mapper.map(jpaObject, WalletTransactionDto.class);

		return dtoObject;
	}

	public static WalletTransaction _toJpa(WalletTransactionDto dtoObject) {

		ModelMapper mapper = new ModelMapper();
		WalletTransaction jpaObject = mapper.map(dtoObject, WalletTransaction.class);

		return jpaObject;
	}


}
