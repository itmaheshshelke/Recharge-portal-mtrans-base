package com.bcoss.mtrans.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.bcoss.mtrans.constant.RechargeSettingConstant;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;

public class RechargeStatusUtil {
	
	
	public static String rechargeStatus(String transactionId) throws HelthwellExceptionHandler{
		String result = "";
		//http://crowdfinchapi.com/api/rechargestatus.aspx?memberid=CF101775&pin=BEBD1B8E5D&transid=rkss293056
		//http://crowdfinchapi.com/api/rechargestatus.aspx?memberid=CF101775&pin=BEBD1B8E5D&usertx=rkss293056
		try {
			StringBuilder sb = new StringBuilder(RechargeSettingConstant.URLSTATUS);
			sb.append("memberid=");
			sb.append(RechargeSettingConstant.MEMBERID);
			sb.append("&pin=");
			sb.append(RechargeSettingConstant.PIN);
			sb.append("&transid=");
			sb.append(transactionId);
			URL obj = new URL(sb.toString().replace(" ", ""));
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();

			con.setRequestMethod("GET");
			BufferedReader in = new BufferedReader(new InputStreamReader(
					con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			result = response.toString();
			
		} catch (Exception e) {
			throw new HelthwellExceptionHandler(
					HelthwellServiceErrors.SMS_SENDING_FAIL);
		}

		return result;
	}
	
	
	public static String transactionResponse(String response) {
		String status="Pending";
		try {
			//txid,status,error_code,operator_ref,time
			//3110317,SUCCESS,,Transaction successful.Amount Debited,05-07-2013 16:07:36
		
			 status=response.split(",")[0];
			return status;
		} catch (Exception e) {
			
		}
		return status;		
	}

	
}
