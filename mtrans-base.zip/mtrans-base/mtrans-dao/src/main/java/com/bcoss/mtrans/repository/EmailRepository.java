package com.bcoss.mtrans.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bcoss.mtrans.jpa.sms.EmailSetting;

public interface EmailRepository extends JpaRepository<EmailSetting, Integer>{

}
