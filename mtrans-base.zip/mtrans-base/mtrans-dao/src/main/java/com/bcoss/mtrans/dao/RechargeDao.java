package com.bcoss.mtrans.dao;

import com.bcoss.mtrans.dto.ServiceResponseDto;
import com.bcoss.mtrans.dto.provider.response.SendMoneyResponseDto;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface RechargeDao {

	Boolean saveRechargeResponse(ServiceResponseDto serviceResponseDto)throws HelthwellExceptionHandler;
	
	public Boolean saveMoneyTransferResponse(SendMoneyResponseDto sendMoneyResponseDto,String benificiaryId,Integer companyId) throws HelthwellExceptionHandler;

}
