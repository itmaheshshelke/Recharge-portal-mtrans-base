package com.bcoss.mtrans.dao;

import java.util.List;

import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.jpa.ServiceOperators;

public interface ServiceOperatorsDao {
	
	List<ServiceOperators> getAllServiceOperators()throws HelthwellExceptionHandler;

	ServiceOperators getServiceOperatorsById(Integer serviceId)throws HelthwellExceptionHandler;

	Boolean saveServiceOperators(ServiceOperators serviceOperators)throws HelthwellExceptionHandler;

	Boolean deleteServiceOperators(Integer serviceId)throws HelthwellExceptionHandler;

	List<ServiceOperators> getOperatorByServiceId(Integer serviceId)throws HelthwellExceptionHandler;

	ServiceOperators getServiceOperatorsByOperaterId(Integer operatorId)throws HelthwellExceptionHandler;

}
