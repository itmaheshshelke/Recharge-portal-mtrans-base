package com.bcoss.mtrans.dao;

import java.util.List;

import com.bcoss.mtrans.Role;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;

public interface RoleDao {

 
	List<Role> getAllRole() throws HelthwellExceptionHandler;

	Role getRoleById(Integer roleId)throws HelthwellExceptionHandler;


	
	

}
