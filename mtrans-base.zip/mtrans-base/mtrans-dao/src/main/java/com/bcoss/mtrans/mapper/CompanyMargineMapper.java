package com.bcoss.mtrans.mapper;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.dto.CompanyMargineDto;
import com.bcoss.mtrans.jpa.CompanyMargine;

public class CompanyMargineMapper {
	public static CompanyMargineDto _toDto(CompanyMargine companyMargine) {

		ModelMapper mapper = new ModelMapper();
		CompanyMargineDto dtoObject = mapper.map(companyMargine, CompanyMargineDto.class);
		return dtoObject;
	}

	public static CompanyMargine _toJpa(CompanyMargineDto companyMargineDto) {

		ModelMapper mapper = new ModelMapper();
		CompanyMargine jpaObject = mapper.map(companyMargineDto, CompanyMargine.class);
		return jpaObject;
	}
}
