 package com.bcoss.mtrans.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class CalendarUtil {
	
	 public static Date getISTDate() throws ParseException {		

			Date serverCurrentDate = new Date();
			System.out.println("Server Date : - "+serverCurrentDate);
			DateFormat formatterIST = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			formatterIST.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata")); 
			String dateStr = formatterIST.format(serverCurrentDate);
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			
			Date date = formatter.parse(dateStr);
			System.out.println("Converted UTC date "+date);
			return date;
		
		}

}
