package com.bcoss.mtrans.schedular;

public class Test {

	public static void main(String[] args) {
		
		Test test=new Test();
		Double charge=test.calculateSuracharge("2001");
		System.out.println("Charged Amount="+charge);
	}

public Double calculateSuracharge(String amount) {
		
		Double total=Double.valueOf(amount);
		Double charge=0.0;
		if(total>=1 && total <=9) {
			charge=5.0;
		}else if(total>=10   && total <=1000) {
			charge=10.0;
		}else if(total>=1001 && total <=2000) {
			charge=15.0;
		}else if(total>=2001 && total <=3000) {
			charge=20.0;
		}else if(total>=3001 && total <=4000) {
			charge=30.0;
		}else {
			charge=40.0;
		}
		
		return charge;
}
}