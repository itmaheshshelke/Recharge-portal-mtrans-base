package com.bcoss.mtrans.mapper;

import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.dto.ServiceResponseDto;
import com.bcoss.mtrans.jpa.ServiceResponse;

public class ServiceResponseMapper {
	
	public static ServiceResponseDto _toDto(ServiceResponse serviceResponse) {

		ModelMapper mapper = new ModelMapper();
		ServiceResponseDto dtoObject = mapper.map(serviceResponse, ServiceResponseDto.class);
		return dtoObject;
	}

	public static ServiceResponse _toJpa(ServiceResponseDto serviceResponseDto) {

		ModelMapper mapper = new ModelMapper();
		ServiceResponse jpaObject = mapper.map(serviceResponseDto, ServiceResponse.class);
		return jpaObject;
	}


}
