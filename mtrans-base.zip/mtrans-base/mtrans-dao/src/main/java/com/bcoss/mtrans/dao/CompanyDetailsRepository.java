package com.bcoss.mtrans.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bcoss.mtrans.CompanyDetails;

public interface CompanyDetailsRepository extends JpaRepository<CompanyDetails, Integer>{
	@Query("select u from CompanyDetails u where u.delFlag = 'N' and u.parentId= :companyId")
	public List<CompanyDetails> findAllActive(@Param("companyId")Integer companyId);

	@Query("select u from CompanyDetails u where u.delFlag = 'N' and u.createdBy= :companyId")
	public List<CompanyDetails> getAllRecharchCompany(@Param("companyId")Integer companyId);

	@Query("select u from CompanyDetails u where u.delFlag = 'N' and u.walletId= :walletId")
	public CompanyDetails getcompanyByWalletid(@Param("walletId")Integer walletId);

	@Query("select u from CompanyDetails u where u.delFlag = 'N' and u.companyId= :companyId and u.isActive='1'")
	public CompanyDetails isActive(@Param("companyId")Integer companyId);

	
	@Query("select p from CompanyDetails p where  p.delFlag = 'N' and p.parentId = :companyId and (p.companyName LIKE %:qString% OR p.contactNo LIKE %:qString% OR p.contactPersonName LIKE %:qString%)")
	public List<CompanyDetails> searchCompanyDetails(@Param("companyId")Integer companyId,@Param("qString") String qString);

	@Query("select u from CompanyDetails u where u.delFlag = 'N'  and u.companyType='3'")
	public Page<CompanyDetails> getAllDistributors(Pageable pageable);
	
	@Query("select u from CompanyDetails u where u.delFlag = 'N'  and u.companyType='3' and (u.companyName LIKE %:searchTerm% OR u.contactNo LIKE %:searchTerm% OR u.contactPersonName LIKE %:searchTerm%)")
	public Page<CompanyDetails> getAllDistributors(Pageable pageable,@Param("searchTerm") String searchTerm);


	@Query("select u from CompanyDetails u where u.delFlag = 'N' and u.companyType='4' and u.parentId= :companyId and (u.companyName LIKE %:searchTerm% OR u.contactNo LIKE %:searchTerm% OR u.contactPersonName LIKE %:searchTerm%)")
	public Page<CompanyDetails> getAllRetailers(@Param("companyId")Integer id, Pageable pageable, @Param("searchTerm")String searchTerm);

	@Query("select u from CompanyDetails u where u.delFlag = 'N'  and u.parentId= :companyId")
	public Page<CompanyDetails> getAllDistributorsByparentId(Pageable pageable, @Param("companyId")Integer companyId);

	@Query("select u from CompanyDetails u where u.delFlag = 'N' and u.companyId= :companyId and u.isActive='1'")
	public Page<CompanyDetails> getcompany(@Param("companyId")Integer companyId,Pageable pageable);

	
	@Query("select u from CompanyDetails u where u.delFlag = 'N' and u.companyId= :companyId and u.isActive='1'  and (u.companyName LIKE %:searchTerm% OR u.contactNo LIKE %:searchTerm% OR u.contactPersonName LIKE %:searchTerm%)")
	public Page<CompanyDetails> getcompany(@Param("companyId")Integer companyId, Pageable pageable, @Param("searchTerm") String searchTerm);

	@Query("select u from CompanyDetails u where u.delFlag = 'N' and u.contactNo= :mobileNo")
	public List<CompanyDetails> isMobileNoExits(@Param("mobileNo") String mobileNo);

	
	@Query("select u from CompanyDetails u where u.parentId= :companyDetailsId")
	public List<CompanyDetails> getAllRetailersUnderDistributor(@Param("companyDetailsId")int companyDetailsId);


	
}
