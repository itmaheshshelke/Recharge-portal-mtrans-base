package com.bcoss.mtrans.mapper;


import org.modelmapper.ModelMapper;

import com.bcoss.mtrans.District;
import com.bcoss.mtrans.DistrictDto;

public class DistrictMapper {

	public static DistrictDto _toDto(District district) {
		
		ModelMapper mapper=new ModelMapper();
		DistrictDto dtoObject = mapper.map(district, DistrictDto.class);
		return dtoObject;
	}
	
	public static District _toJpa(DistrictDto districtDto) {
		ModelMapper mapper = new ModelMapper();
		District jpaObject = mapper.map(districtDto, District.class);
		return jpaObject;
	}
}
