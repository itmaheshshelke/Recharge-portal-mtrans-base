package com.bcoss.mtrans.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.HibernateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bcoss.mtrans.dao.repository.CompanyBankRepository;
import com.bcoss.mtrans.exception.HelthwellExceptionHandler;
import com.bcoss.mtrans.exception.HelthwellServiceErrors;
import com.bcoss.mtrans.jpa.CompanyBank;

public class CompanyBankDaoImpl implements CompanyBankDao {

	private Logger logger = LoggerFactory.getLogger(CompanyBankDaoImpl.class);

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	CompanyBankRepository reposiotory;
	
	public List<CompanyBank> getAllCompanyDetails() throws HelthwellExceptionHandler {

		List<CompanyBank> companyDetailsList = new ArrayList<CompanyBank>();

		try {
			companyDetailsList=reposiotory.findAll();
			
			if (companyDetailsList != null && companyDetailsList.size() > 0) {
				return companyDetailsList;
			} else {
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.NO_ADDRESS_FOUND);
			}
		} catch (HelthwellExceptionHandler ex) {
			throw ex;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > getCompanyDetailss ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > getCompanyDetailss ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}
	}

	public CompanyBank getCompanyDetailsById(int companyDetailsId) throws HelthwellExceptionHandler {

		try {
			CompanyBank companyDetails = reposiotory.findOne(companyDetailsId);
			return companyDetails;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > getCompanyDetailsById ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > getCompanyDetailsById ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		} finally {
			entityManager.close();
		}
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public boolean addCompanyDetails(CompanyBank companyDetails) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			//companyDetails.setDelFlag('N');
			reposiotory.save(companyDetails);
			
			if(companyDetails.getCompanyId()!=null) {
				result=true;				
			}else {
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.ADDRESS_ALREADY_EXIST);
			}
			return result;
		} catch (HelthwellExceptionHandler ex) {
			throw ex;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > addCompanyDetails ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > addCompanyDetails ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public boolean updateCompanyDetails(CompanyBank companyDetails) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			reposiotory.save(companyDetails);
			result = true;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > updateCompanyDetails ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > updateCompanyDetails ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}
		return result;

	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public boolean deleteCompanyDetails(int companyDetailsId) throws HelthwellExceptionHandler {
		Boolean result = false;
		try {
			Query query = entityManager.createQuery("UPDATE CompanyBank SET  delFlag = 'Y' WHERE companyId = :id");
			query.setParameter("id", companyDetailsId);
			int updateResult = query.executeUpdate();

			if (updateResult != 0) {
				result = true;
			} else {
				throw new HelthwellExceptionHandler(HelthwellServiceErrors.NO_ADDRESS_FOUND);
			}
			return result;
		} catch (HelthwellExceptionHandler ex) {
			throw ex;
		} catch (HibernateException he) {
			logger.error("HibernateException Error in CompanyDetailsDaoImpl - > deleteCompanyDetails ", he);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION_HIBERNATE);
		} catch (Exception e) {
			logger.error("Exception Error in CompanyDetailsDaoImpl - > deleteCompanyDetails ", e);
			throw new HelthwellExceptionHandler(HelthwellServiceErrors.GENERIC_EXCEPTION);
		}

	}

}
