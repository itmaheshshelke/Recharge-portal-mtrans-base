package com.bcoss.mtrans.constant;

public class EmailConstant {

	public static final String TEMPLET_PATH="C:\\imp\\email_templates\\";
	public static final String USER_NAME ="flyonpaperless@gmail.com";
	public static final String USER_PASSWORD ="henx@1234";
	public static final String HOST ="smtp.gmail.com";
	public static final String PORT ="587";
	
	
	
	public static final String NEW_COMPANY="NEW_COMPANY";
	public static final String TRANS="TRANS";
	public static final Integer SENT=1;
	public static final Integer FAILED=2;
	
	public static final String emailTemplate="<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\"> \r\n" + 
			"<html xmlns=\"http://www.w3.org/1999/xhtml\">\r\n" + 
			"<head>\r\n" + 
			"	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\r\n" + 
			"	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"/>\r\n" + 
			"	<title>Welcome To Drline</title>\r\n" + 
			"	<style type=\"text/css\">\r\n" + 
			"		/* Client-specific Styles */\r\n" + 
			"		#outlook a {padding:0;} /* Force Outlook to provide a \"view in browser\" menu link. */\r\n" + 
			"		/* Prevent Webkit and Windows Mobile platforms from changing default font sizes.*/ \r\n" + 
			"		.ExternalClass {width:100%;} /* Force Hotmail to display emails at full width */  \r\n" + 
			"		.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {line-height: 100%;}\r\n" + 
			"		/* Forces Hotmail to display normal line spacing.  More on that: http://www.emailonacid.com/forum/viewthread/43/ */ \r\n" + 
			"		#backgroundTable {margin:0; padding:0; width:100% !important; line-height: 100% !important;}\r\n" + 
			"		/* End reset */\r\n" + 
			"		table td {border-collapse: collapse;}\r\n" + 
			"\r\n" + 
			"		/* Mobile styles */\r\n" + 
			"		@media only screen and (min-device-width: 320px) and (max-device-width: 480px) {\r\n" + 
			"			table.wrapper-table {\r\n" + 
			"				width: 90% !important;\r\n" + 
			"			}\r\n" + 
			"			td.cellBlock {\r\n" + 
			"				display: inline-block;\r\n" + 
			"				width: auto !important;\r\n" + 
			"			}\r\n" + 
			"		}\r\n" + 
			"\r\n" + 
			"	</style>\r\n" + 
			"</head>\r\n" + 
			"<body style=\"width:100% !important; -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; margin:0; padding:0;\">\r\n" + 
			"\r\n" + 
			"<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" id=\"backgroundTable\" bgcolor=\"#888B8D\">\r\n" + 
			"	<tr>\r\n" + 
			"		<td valign=\"top\">\r\n" + 
			"		<!-- Tables are the most common way to format your email consistently. Set your table widths inside cells and in most cases reset cellpadding, cellspacing, and border to zero. Use nested tables as a way to space effectively in your message. -->\r\n" + 
			"			<table class=\"wrapper-table\" align=\"center\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"640\" style=\"border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;\">\r\n" + 
			"				<tbody>\r\n" + 
			"					<tr>\r\n" + 
			"						<!-- <td style=\"font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 11px; line-height: 15px; color: #ffffff; text-align: right;\" class=\"webview\" height=\"25\"><span style=\"color: #888B8D\">Your account is now ready for you to start trading.....</span></td> -->\r\n" + 
			"					</tr>\r\n" + 
			"					<tr>\r\n" + 
			"						\r\n" + 
			"\r\n" + 
			"					</tr>\r\n" + 
			"					<tr>\r\n" + 
			"						<td bgcolor=\"#ffffff\">\r\n" + 
			"							<table class=\"outer-table\" border=\"0\" cellpadding=\"30\" cellspacing=\"0\" width=\"100%\" style=\"border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt;\">\r\n" + 
			"								<tbody>\r\n" + 
			"									<tr>\r\n" + 
			"										<td style=\"font-family: Arial, Helvetica, sans-serif; font-size: 12px; line-height: 18px; color: #191919; text-align: left;\" class=\"main-content\">\r\n" + 
			"											\r\n" + 
			"										\r\n" + 
			"\r\n" + 
			"\r\n" + 
			"		\r\n" + 
			"											<p style=\"margin: 10px 0 10px 0; font-size: 13px;\"> Dear ###1,</p>\r\n" + 
			"											<p style=\"margin: 10px 0 10px 0; font-size: 13px;\"> <b> </b></p>\r\n" + 
			"											<p style=\"margin: 10px 0 10px 0; #191919; font-size: 13px;\">Subject : ###2.</p>\r\n" + 
			"											<p style=\"margin: 10px 0 10px 0; #191919; font-size: 13px;\">Customer Name  :  ###3</p>\r\n" + 
			"											<p style=\"margin: 10px 0 10px 0; #191919; font-size: 13px;\">Contact No  :  ###4</p>\r\n" + 
			"											<p style=\"margin: 10px 0 10px 0; #191919; font-size: 13px;\">Message  :<br></p><p>  ###5</p>\r\n" + 
			"											\r\n" + 
			"											<p style=\"margin: 10px 0 10px 0; #191919; font-size: 13px;\"><br/><b>Best regards,</b></p>\r\n" + 
			"											 <p style=\"margin: 10px 0 10px 0; #191919; font-size: 13px;\">###1</p>\r\n" + 
			"											 \r\n" + 
			"											 \r\n" + 
			"										</td>\r\n" + 
			"									</tr>\r\n" + 
			"								</tbody>\r\n" + 
			"							</table>\r\n" + 
			"							<hr />\r\n" + 
			"								<table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"10\" style=\"border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; font-family: Arial, Helvetica, sans-serif; color: #757575; font-size: 10px;\">\r\n" + 
			"								<tbody>\r\n" + 
			"									<tr>\r\n" + 
			"									<td style=\"color: #191919;\" class=\"cellBlock\">\r\n" + 
			"											\r\n" + 
			"										</td>\r\n" + 
			"										<td align=\"right\" valign=\"top\" class=\"cellBlock\">\r\n" + 
			"											<table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"1\" style=\"border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; font-family: Arial, Helvetica, sans-serif; color: #757575; font-size: 10px; float: right;\">\r\n" + 
			"												<tbody>\r\n" + 
			"													<tr>\r\n" + 
			"														\r\n" + 
			"														<td valign=\"top\">\r\n" + 
			"															<a href=\"https://www.facebook.com/\" style=\"text-decoration: none;\">\r\n" + 
			"																<img title=\"facebook_40.png\" alt=\"facebook_40.png\" height=\"30\" width=\"30\" src=\"http://drline.in/template_images/facebook.png\" style=\"vertical-align: top; display:block; border: none; outline:none; text-decoration:none; -ms-interpolation-mode: bicubic;\" class=\"image_fix\" />\r\n" + 
			"															</a>\r\n" + 
			"														</td>\r\n" + 
			"														<td valign=\"top\">\r\n" + 
			"															<a href=\"https://twitter.com/\" style=\"text-decoration: none;\">\r\n" + 
			"																<img title=\"twitter_40.png\" alt=\"twitter_40.png\" height=\"30\" width=\"30\" src=\"http://drline.in/template_images/twitter.png\" style=\"vertical-align: top; display:block; border: none; outline:none; text-decoration:none; -ms-interpolation-mode: bicubic;\" class=\"image_fix\" />\r\n" + 
			"															</a>\r\n" + 
			"														</td>\r\n" + 
			"														<td valign=\"top\">\r\n" + 
			"															<a href=\"http://www.linkedin.com/\" style=\"text-decoration: none;\">\r\n" + 
			"																<img title=\"linkedin_40.png\" alt=\"linkedin_40.png\" height=\"30\" width=\"30\" src=\"http://drline.in/template_images/linkedin.png\" style=\"vertical-align: top; display:block; border: none; outline:none; text-decoration:none; -ms-interpolation-mode: bicubic;\" class=\"image_fix\" />\r\n" + 
			"															</a>\r\n" + 
			"														</td>\r\n" + 
			"														<td valign=\"top\">\r\n" + 
			"															<a href=\"https://plus.google.com/\" style=\"text-decoration: none;\">\r\n" + 
			"																<img title=\"googleplus_40.png\" alt=\"googleplus_40.png\" height=\"30\" width=\"30\" src=\"http://drline.in/template_images/google-plus.png\" style=\"vertical-align: top; display:block; border: none; outline:none; text-decoration:none; -ms-interpolation-mode: bicubic;\" class=\"image_fix\" />\r\n" + 
			"															</a>\r\n" + 
			"														</td>\r\n" + 
			"														<td valign=\"top\">\r\n" + 
			"															<a href=\"http://www.youtube.com/\" style=\"text-decoration: none;\">\r\n" + 
			"																<img title=\"youtube_40.png\" alt=\"youtube_40.png\" height=\"30\" width=\"30\" src=\"http://drline.in/template_images/youtube.png\" style=\"vertical-align: top; display:block; border: none; outline:none; text-decoration:none; -ms-interpolation-mode: bicubic;\" class=\"image_fix\" />\r\n" + 
			"															</a>\r\n" + 
			"														</td>\r\n" + 
			"														<td valign=\"top\">\r\n" + 
			"															<a href=\"http://pinterest.com/\" style=\"text-decoration: none;\">\r\n" + 
			"																<img title=\"pinterest_40.png\" alt=\"pinterest_40.png\" height=\"30\" width=\"30\" src=\"http://drline.in/template_images/pinterest.png\" style=\"vertical-align: top; display:block; border: none; outline:none; text-decoration:none; -ms-interpolation-mode: bicubic;\" class=\"image_fix\" />\r\n" + 
			"															</a>\r\n" + 
			"														</td>\r\n" + 
			"													</tr>\r\n" + 
			"												</tbody>\r\n" + 
			"											</table>\r\n" + 
			"										</td>\r\n" + 
			"									</tr>\r\n" + 
			"								</tbody>\r\n" + 
			"							</table>\r\n" + 
			"							<table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"10\" style=\"border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; font-family: Arial, Helvetica, sans-serif; color: #191919; font-size: 10px;\">\r\n" + 
			"								<tbody>\r\n" + 
			"									<tr>\r\n" + 
			"										<!-- <td>&copy;Currencies Direct Ltd 2000-2014. All rights reserved worldwide. Authorised by the Financial Conduct Authority for provision of payment services. We do not sell, rent or trade your personal information to third parties for marketing purposes without your express consent. Read more about our <a href=\"http://www.currenciesdirect.com/legals\" style=\"color: #e57200;\">terms</a> or <a href=\"http://www.currenciesdirect.com/privacy-policy/\" style=\"color: #e57200;\">privacy policy</a>. -->\r\n" + 
			"										</td>\r\n" + 
			"									</tr>\r\n" + 
			"								</tbody>\r\n" + 
			"							</table>\r\n" + 
			"						</td>\r\n" + 
			"					</tr>\r\n" + 
			"				</tbody>\r\n" + 
			"			</table>\r\n" + 
			"		</td>\r\n" + 
			"	</tr>\r\n" + 
			"</table>  \r\n" + 
			"<!-- End of wrapper table -->\r\n" + 
			"</body>\r\n" + 
			"</html>\r\n" + 
			"\r\n" + 
			"";
}


