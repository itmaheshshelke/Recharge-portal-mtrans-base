package com.bcoss.mtrans.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bcoss.mtrans.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	
	

	@Query("select u from Employee u where u.delFlag = 'N' and u.contactNo= :contactNo1 and u.password= :password")
	public Employee getEmployee(@Param("contactNo1") String contactNo1,@Param("password") String password);
	
	
	@Query("select u from Employee u where u.delFlag = 'N' and u.companyId= :compnayId")
	public List<Employee> findAll(@Param("compnayId") Integer compnayId);


	
	@Query("select u from Employee u where u.delFlag = 'N' and u.employeeId= :employeeId")
	public Employee findOne(@Param("employeeId") Integer employeeId);


	@Query("select u from Employee u where u.delFlag = 'N' and u.contactNo= :mobNo")
	public Employee isExistingContact(@Param("mobNo") String mobNo);

	@Query("select e from Employee e where e.companyId= :companyId and e.employeeId= :employeeId and password= :oldPassword")
	public Employee isExistingOldPassword(@Param("companyId") Integer companyId, @Param("employeeId") Integer employeeId,@Param("oldPassword") String oldPassword);



	
	
}
