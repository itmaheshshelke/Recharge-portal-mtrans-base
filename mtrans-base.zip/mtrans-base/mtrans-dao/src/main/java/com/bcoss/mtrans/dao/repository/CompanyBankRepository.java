package com.bcoss.mtrans.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bcoss.mtrans.jpa.CompanyBank;

public interface CompanyBankRepository extends JpaRepository<CompanyBank, Integer> {

}
