/*
SQLyog Enterprise - MySQL GUI v7.02 
MySQL - 5.1.72-community : Database - mtrans
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`mtrans` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `mtrans`;

/*Table structure for table `address` */

DROP TABLE IF EXISTS `address`;

CREATE TABLE `address` (
  `address_id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `district_id` int(5) unsigned NOT NULL,
  `address_line_1` varchar(200) DEFAULT NULL,
  `address_line_2` varchar(200) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `pin_code` int(6) DEFAULT NULL,
  `created_on` date NOT NULL,
  `created_by` int(5) DEFAULT NULL,
  `updated_by` int(5) DEFAULT NULL,
  `updated_on` date DEFAULT NULL,
  `del_flag` char(1) DEFAULT NULL,
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Table structure for table `company_details` */

DROP TABLE IF EXISTS `company_details`;

CREATE TABLE `company_details` (
  `company_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(30) NOT NULL,
  `address` varchar(100) DEFAULT NULL,
  `contact_person_name` varchar(30) NOT NULL,
  `company_type` varchar(30) DEFAULT NULL,
  `state_id` int(10) DEFAULT NULL,
  `district_id` int(10) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `plan_id` int(10) DEFAULT NULL,
  `contact_no` varchar(20) DEFAULT NULL,
  `email_id` varchar(100) NOT NULL,
  `pin_code` int(7) DEFAULT NULL,
  `created_by` int(10) DEFAULT NULL,
  `created_on` date DEFAULT NULL,
  `updated_by` int(10) DEFAULT NULL,
  `updated_on` date DEFAULT NULL,
  `del_flag` char(1) NOT NULL,
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

/*Table structure for table `company_margine` */

DROP TABLE IF EXISTS `company_margine`;

CREATE TABLE `company_margine` (
  `margine_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plan_id` int(10) DEFAULT NULL,
  `service_id` int(10) DEFAULT NULL,
  `operator_id` int(10) DEFAULT NULL,
  `company_id` int(10) DEFAULT NULL,
  `margine_type` varchar(30) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `value` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`margine_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `emp_user` */

DROP TABLE IF EXISTS `emp_user`;

CREATE TABLE `emp_user` (
  `emp_user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `emp_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`emp_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `employee` */

DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee` (
  `employee_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `email_id` varchar(30) DEFAULT NULL,
  `contact_no` varchar(12) DEFAULT NULL,
  `state_id` int(10) DEFAULT NULL,
  `district_id` int(10) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `role_id` int(10) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `company_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `operator` */

DROP TABLE IF EXISTS `operator`;

CREATE TABLE `operator` (
  `operator_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `service_id` int(10) DEFAULT NULL,
  `operator` varchar(30) DEFAULT NULL,
  `delflag` char(1) DEFAULT NULL,
  PRIMARY KEY (`operator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `plan` */

DROP TABLE IF EXISTS `plan`;

CREATE TABLE `plan` (
  `plan_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setup_fee` varchar(30) DEFAULT NULL,
  `plan` varchar(30) DEFAULT NULL,
  `delflag` char(1) DEFAULT NULL,
  PRIMARY KEY (`plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `role_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role` varchar(30) DEFAULT NULL,
  `system` char(1) DEFAULT NULL,
  `delflag` char(1) DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Table structure for table `service` */

DROP TABLE IF EXISTS `service`;

CREATE TABLE `service` (
  `service_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `service` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
