package com.bcoss.mtrans.dto.provider.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Remitter {

	@JsonProperty("id")
	private String id;

	@JsonProperty("name")
	private String name;
	
	@JsonProperty("mobile")
	private String mobile;
	
	@JsonProperty("address")
	private String address;
	
	@JsonProperty("pincode")
	private String pincode;
	
	@JsonProperty("city")
	private String city;
	
	@JsonProperty("state")
	private String state;
	
	@JsonProperty("kycstatus")
	private String kycstatus;
	
	@JsonProperty("consumedlimit")
	private String consumedlimit;
	
	@JsonProperty("remaininglimit")
	private String remaininglimit;
	
	@JsonProperty("kycdocs")
	private String kycdocs;
	
	@JsonProperty("perm_txn_limit")
	private String perm_txn_limit;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getKycstatus() {
		return kycstatus;
	}

	public void setKycstatus(String kycstatus) {
		this.kycstatus = kycstatus;
	}

	public String getConsumedlimit() {
		return consumedlimit;
	}

	public void setConsumedlimit(String consumedlimit) {
		this.consumedlimit = consumedlimit;
	}

	public String getRemaininglimit() {
		return remaininglimit;
	}

	public void setRemaininglimit(String remaininglimit) {
		this.remaininglimit = remaininglimit;
	}

	public String getKycdocs() {
		return kycdocs;
	}

	public void setKycdocs(String kycdocs) {
		this.kycdocs = kycdocs;
	}

	public String getPerm_txn_limit() {
		return perm_txn_limit;
	}

	public void setPerm_txn_limit(String perm_txn_limit) {
		this.perm_txn_limit = perm_txn_limit;
	}
	
	
}
