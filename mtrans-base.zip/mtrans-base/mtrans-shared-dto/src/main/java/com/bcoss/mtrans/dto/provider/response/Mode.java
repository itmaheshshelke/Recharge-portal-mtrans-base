package com.bcoss.mtrans.dto.provider.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Mode {

	@JsonProperty("imps")
	private String imps;


	@JsonProperty("neft")
	private String neft;


	public String getImps() {
		return imps;
	}


	public void setImps(String imps) {
		this.imps = imps;
	}


	public String getNeft() {
		return neft;
	}


	public void setNeft(String neft) {
		this.neft = neft;
	}
	
	
	
}
