package com.bcoss.mtrans;

import java.io.Serializable;
import java.util.Date;

import javax.management.loading.PrivateClassLoader;
	public class CompanyDetailsDto implements Serializable{

		
		/**
		 * 
		 */
		private static final long serialVersionUID = -4905404304622938420L;

		private Integer companyId;
		
		private Integer walletId;
		
		private Integer parentId;

		private String companyName;
		
		private String contactPersonName;
		
		private String address;
		
		private Double setupFee;
		
		private String city;
		
		private Integer companyType;
		
		private String emailId;
		
		private Integer planId;
		
		private Integer stateId;
		
		private Integer districtId;
		
		private String contactNo;
		
		private Integer pinCode;
		
		private Integer createdBy;
		
		private Date createdOn;
		
		private Integer updatedBy;
		
		private Date updatedOn;
		
		private Character delFlag;
		
		private Double balance;
		
		private String transNumber;
		
		private Integer isActive;
		
		private Character isReadOnly;
		

		public Integer getCompanyId() {
			return companyId;
		}

		public void setCompanyId(Integer companyId) {
			this.companyId = companyId;
		}

		public Integer getWalletId() {
			return walletId;
		}

		public void setWalletId(Integer walletId) {
			this.walletId = walletId;
		}

		public String getCompanyName() {
			return companyName;
		}

		public void setCompanyName(String companyName) {
			this.companyName = companyName;
		}

		public String getContactPersonName() {
			return contactPersonName;
		}

		public void setContactPersonName(String contactPersonName) {
			this.contactPersonName = contactPersonName;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public Double getSetupFee() {
			return setupFee;
		}

		public void setSetupFee(Double setupFee) {
			this.setupFee = setupFee;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		

		public Integer getCompanyType() {
			return companyType;
		}

		public void setCompanyType(Integer companyType) {
			this.companyType = companyType;
		}

		public String getEmailId() {
			return emailId;
		}

		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}

		public Integer getPlanId() {
			return planId;
		}

		public void setPlanId(Integer planId) {
			this.planId = planId;
		}

		public Integer getStateId() {
			return stateId;
		}

		public void setStateId(Integer stateId) {
			this.stateId = stateId;
		}

		public Integer getDistrictId() {
			return districtId;
		}

		public void setDistrictId(Integer districtId) {
			this.districtId = districtId;
		}

		public String getContactNo() {
			return contactNo;
		}

		public void setContactNo(String contactNo) {
			this.contactNo = contactNo;
		}

		public Integer getPinCode() {
			return pinCode;
		}

		public void setPinCode(Integer pinCode) {
			this.pinCode = pinCode;
		}

		public Integer getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(Integer createdBy) {
			this.createdBy = createdBy;
		}

		public Date getCreatedOn() {
			return createdOn;
		}

		public void setCreatedOn(Date createdOn) {
			this.createdOn = createdOn;
		}

		public Integer getUpdatedBy() {
			return updatedBy;
		}

		public void setUpdatedBy(Integer updatedBy) {
			this.updatedBy = updatedBy;
		}

		public Date getUpdatedOn() {
			return updatedOn;
		}

		public void setUpdatedOn(Date updatedOn) {
			this.updatedOn = updatedOn;
		}

		public Character getDelFlag() {
			return delFlag;
		}

		public void setDelFlag(Character delFlag) {
			this.delFlag = delFlag;
		}

		public Double getBalance() {
			return balance;
		}

		public void setBalance(Double balance) {
			this.balance = balance;
		}

		public Integer getParentId() {
			return parentId;
		}

		public void setParentId(Integer parentId) {
			this.parentId = parentId;
		}

		public String getTransNumber() {
			return transNumber;
		}

		public void setTransNumber(String transNumber) {
			this.transNumber = transNumber;
		}

		public Integer getIsActive() {
			return isActive;
		}

		public void setIsActive(Integer isActive) {
			this.isActive = isActive;
		}

		public Character getIsReadOnly() {
			return isReadOnly;
		}

		public void setIsReadOnly(Character isReadOnly) {
			this.isReadOnly = isReadOnly;
		}

		

		


}

