package com.bcoss.mtrans.dto;


import java.io.Serializable;

public class EmployeeDocumentDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5080542186759149749L;

	private Integer documentId;
	
	private Integer companyId;
	
	private String documentName;
	
	private String uri;
	
	private String extension;

	private byte[] data;
	
	private Character delflag;

	
	
	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public Integer getDocumentId() {
		return documentId;
	}

	public void setDocumentId(Integer documentId) {
		this.documentId = documentId;
	}

	
	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public Character getDelflag() {
		return delflag;
	}

	public void setDelflag(Character delflag) {
		this.delflag = delflag;
	}

	
}
