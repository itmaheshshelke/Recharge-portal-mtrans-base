package com.bcoss.mtrans.dto.provider.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SendMoneyResponseDto {

	@JsonProperty("ERROR")
	private String error;
	
	@JsonProperty("STATUS")
	private String status;
	
	@JsonProperty("TRNXNO")
	private String trnxNo;
	
	@JsonProperty("MESSAGE")
	private String  message;
	
	@JsonProperty("DATA")
	private DMResponseData data;

	private Double walletBalance;
	
	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTrnxNo() {
		return trnxNo;
	}

	public void setTrnxNo(String trnxNo) {
		this.trnxNo = trnxNo;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public DMResponseData getData() {
		return data;
	}

	public void setData(DMResponseData data) {
		this.data = data;
	}

	public Double getWalletBalance() {
		return walletBalance;
	}

	public void setWalletBalance(Double walletBalance) {
		this.walletBalance = walletBalance;
	}
	
	
}
