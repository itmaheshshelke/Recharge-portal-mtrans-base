package com.bcoss.mtrans;

import java.util.Date;

public class PancardRegisterDto extends AuditFlagsDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer pancardId;
	
	private String categoryOfAppointment;
	
	private String aplFirstName;
	
	private String aplMiddleName;
	
	private String aplLastName;
	
	private Date dob;
	
	private String emailId;
	
	private String contactNo;
	
	private String aplFatherFirstName;
	
	private String aplFatherMiddleName;
	
	private String aplFatherLastName;
	

	
	
}

