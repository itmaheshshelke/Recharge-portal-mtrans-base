package com.bcoss.mtrans.dto.provider.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DMRData {
	
	@JsonProperty("remitter")
	private Remitter remitter;
	
	@JsonProperty("beneficiary")
	private List<Beneficiary> beneficiary;
	
	@JsonProperty("remitter_limit")
	private List<RemitterLimit> remitterLimit;

	public Remitter getRemitter() {
		return remitter;
	}

	public void setRemitter(Remitter remitter) {
		this.remitter = remitter;
	}

	public List<Beneficiary> getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(List<Beneficiary> beneficiary) {
		this.beneficiary = beneficiary;
	}

	public List<RemitterLimit> getRemitterLimit() {
		return remitterLimit;
	}

	public void setRemitterLimit(List<RemitterLimit> remitterLimit) {
		this.remitterLimit = remitterLimit;
	}
	
}
