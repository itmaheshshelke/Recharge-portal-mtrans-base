package com.bcoss.mtrans.dto;

import java.io.Serializable;

public class EmailSettingDto implements Serializable {
	
	public EmailSettingDto() {
		super();
	}
	public EmailSettingDto(String emailId, String password, Integer port, String host) {
		super();
		this.emailId = emailId;
		this.password = password;
		this.port = port;
		this.host = host;
	}
	private static final long serialVersionUID = 1L;
	
	private Integer clinicEmailSettingId;
	private Integer clinicId;
	private String emailId;
	private String provider;
	private String password;
	private Integer port;
	private String host;
	private String companyName;
	
	public Integer getClinicEmailSettingId() {
		return clinicEmailSettingId;
	}
	public void setClinicEmailSettingId(Integer clinicEmailSettingId) {
		this.clinicEmailSettingId = clinicEmailSettingId;
	}
	public Integer getClinicId() {
		return clinicId;
	}
	public void setClinicId(Integer clinicId) {
		this.clinicId = clinicId;
	}
	public String getProvider() {
		return provider;
	}
	public void setProvider(String provider) {
		this.provider = provider;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Integer getPort() {
		return port;
	}
	public void setPort(Integer port) {
		this.port = port;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	

}
