package com.bcoss.mtrans.dto;

import java.io.Serializable;
import java.util.Date;

public class LiveTransactionReportDto implements Serializable {

	/**
	* 
	*/
	private static final long serialVersionUID = -3486946162922984563L;

	private String copmanyName;
	
	private Integer copmanyType;
	
	private String serviseName;
	
	private Integer companyId;

	private Integer serviceId;

	private Integer operatorId;

	private String operaterName;

	private String mombileNumber;

	private String operatorCode;

	private Double amount;
	
	private Double surcharge;
	
	private String txId;

	private String status;

	private Date time;

	private Double margine;

	private Double finalAmount;

	private Integer marginType;

	public String getCopmanyName() {
		return copmanyName;
	}

	public void setCopmanyName(String copmanyName) {
		this.copmanyName = copmanyName;
	}

	public String getServiseName() {
		return serviseName;
	}

	public void setServiseName(String serviseName) {
		this.serviseName = serviseName;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public Integer getServiceId() {
		return serviceId;
	}

	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}

	public Integer getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(Integer operatorId) {
		this.operatorId = operatorId;
	}

	public String getOperaterName() {
		return operaterName;
	}

	public void setOperaterName(String operaterName) {
		this.operaterName = operaterName;
	}

	public String getMombileNumber() {
		return mombileNumber;
	}

	public void setMombileNumber(String mombileNumber) {
		this.mombileNumber = mombileNumber;
	}

	public String getOperatorCode() {
		return operatorCode;
	}

	public void setOperatorCode(String operatorCode) {
		this.operatorCode = operatorCode;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getTxId() {
		return txId;
	}

	public void setTxId(String txId) {
		this.txId = txId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public Double getMargine() {
		return margine;
	}

	public void setMargine(Double margine) {
		this.margine = margine;
	}

	public Double getFinalAmount() {
		return finalAmount;
	}

	public void setFinalAmount(Double finalAmount) {
		this.finalAmount = finalAmount;
	}

	public Integer getMarginType() {
		return marginType;
	}

	public void setMarginType(Integer marginType) {
		this.marginType = marginType;
	}

	public Integer getCopmanyType() {
		return copmanyType;
	}

	public void setCopmanyType(Integer copmanyType) {
		this.copmanyType = copmanyType;
	}

	public Double getSurcharge() {
		return surcharge;
	}

	public void setSurcharge(Double surcharge) {
		this.surcharge = surcharge;
	}
	
	
	

}
