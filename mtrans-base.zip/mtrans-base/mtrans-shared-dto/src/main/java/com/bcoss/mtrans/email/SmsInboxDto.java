package com.bcoss.mtrans.email;

import java.io.Serializable;
import java.sql.Date;

public class SmsInboxDto implements Serializable {

	/**
	 * 
	 */

	private static final long serialVersionUID = -9032902834294251178L;

	private Integer sms_inbox_id;
	private Integer clinicId;
	private String smsTemplateType;
	private String smsTransactionId;
	private Integer status;
	private Integer service;
	public Integer getSms_inbox_id() {
		return sms_inbox_id;
	}
	public void setSms_inbox_id(Integer sms_inbox_id) {
		this.sms_inbox_id = sms_inbox_id;
	}
	public Integer getClinicId() {
		return clinicId;
	}
	public void setClinicId(Integer clinicId) {
		this.clinicId = clinicId;
	}
	
	public String getSmsTemplateType() {
		return smsTemplateType;
	}
	public void setSmsTemplateType(String smsTemplateType) {
		this.smsTemplateType = smsTemplateType;
	}
	public String getSmsTransactionId() {
		return smsTransactionId;
	}
	public void setSmsTransactionId(String smsTransactionId) {
		this.smsTransactionId = smsTransactionId;
	}
	
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getService() {
		return service;
	}
	public void setService(Integer service) {
		this.service = service;
	}
	
}
