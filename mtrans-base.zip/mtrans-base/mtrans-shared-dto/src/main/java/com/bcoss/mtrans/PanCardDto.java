package com.bcoss.mtrans;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

public class PanCardDto extends AuditFlagsDto{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer panId;
	private Integer applicantCategoryId;
	private Integer categoryId;
	private String fName;
	private String mName;
	private String lName;
	private String nameOnCard;
	private String fatherFname;
	private String fatherMname;
	private String fatherLname;
	private String dobString;
	private Date dob;
	private String mobileNo;
	private String emailId;
	private String address;
	private String nameOnAadhar;
	private String identityUri;
	private String addressUri;
	private String dobUri;
	private String scanCopyUri;
	private Integer status;
	private Integer applicationType;
	private String panNo;
	private String oPanNo1;
	private String oPanNo2;
	private String oPanNo3;
	private String oPanNo4;
	private String stateId;
	private MultipartFile dobImage;
	private MultipartFile addressImage;
	private MultipartFile identityImage;
	private MultipartFile scanCopyImage;
	private byte[] data;
	private String ext;
	private String aadharNo;
	private String eidNo;
	
	private String companyName;
	private Integer companyType;
	private String catofapp;
	
	private String regNo;
	
	public Integer getPanId() {
		return panId;
	}
	public void setPanId(Integer panId) {
		this.panId = panId;
	}
	
	public Integer getApplicantCategoryId() {
		return applicantCategoryId;
	}
	public void setApplicantCategoryId(Integer applicantCategoryId) {
		this.applicantCategoryId = applicantCategoryId;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getNameOnCard() {
		return nameOnCard;
	}
	public void setNameOnCard(String nameOnCard) {
		this.nameOnCard = nameOnCard;
	}
	public String getFatherFname() {
		return fatherFname;
	}
	public void setFatherFname(String fatherFname) {
		this.fatherFname = fatherFname;
	}
	public String getFatherMname() {
		return fatherMname;
	}
	public void setFatherMname(String fatherMname) {
		this.fatherMname = fatherMname;
	}
	public String getFatherLname() {
		return fatherLname;
	}
	public void setFatherLname(String fatherLname) {
		this.fatherLname = fatherLname;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getNameOnAadhar() {
		return nameOnAadhar;
	}
	public void setNameOnAadhar(String nameOnAadhar) {
		this.nameOnAadhar = nameOnAadhar;
	}
	public String getIdentityUri() {
		return identityUri;
	}
	public void setIdentityUri(String identityUri) {
		this.identityUri = identityUri;
	}
	public String getAddressUri() {
		return addressUri;
	}
	public void setAddressUri(String addressUri) {
		this.addressUri = addressUri;
	}
	public String getDobUri() {
		return dobUri;
	}
	public void setDobUri(String dobUri) {
		this.dobUri = dobUri;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getApplicationType() {
		return applicationType;
	}
	public void setApplicationType(Integer applicationType) {
		this.applicationType = applicationType;
	}
	
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getoPanNo2() {
		return oPanNo2;
	}
	public void setoPanNo2(String oPanNo2) {
		this.oPanNo2 = oPanNo2;
	}
	public String getoPanNo3() {
		return oPanNo3;
	}
	public void setoPanNo3(String oPanNo3) {
		this.oPanNo3 = oPanNo3;
	}
	public String getoPanNo4() {
		return oPanNo4;
	}
	public void setoPanNo4(String oPanNo4) {
		this.oPanNo4 = oPanNo4;
	}
	
	public String getStateId() {
		return stateId;
	}
	public void setStateId(String stateId) {
		this.stateId = stateId;
	}
	public MultipartFile getDobImage() {
		return dobImage;
	}
	public void setDobImage(MultipartFile dobImage) {
		this.dobImage = dobImage;
	}
	public MultipartFile getAddressImage() {
		return addressImage;
	}
	public void setAddressImage(MultipartFile addressImage) {
		this.addressImage = addressImage;
	}
	public MultipartFile getIdentityImage() {
		return identityImage;
	}
	public void setIdentityImage(MultipartFile identityImage) {
		this.identityImage = identityImage;
	}
	public byte[] getData() {
		return data;
	}
	public void setData(byte[] data) {
		this.data = data;
	}
	public String getExt() {
		return ext;
	}
	public void setExt(String ext) {
		this.ext = ext;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getEidNo() {
		return eidNo;
	}
	public void setEidNo(String eidNo) {
		this.eidNo = eidNo;
	}
	public String getDobString() {
		return dobString;
	}
	public void setDobString(String dobString) {
		this.dobString = dobString;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public Integer getCompanyType() {
		return companyType;
	}
	public void setCompanyType(Integer companyType) {
		this.companyType = companyType;
	}
	public String getoPanNo1() {
		return oPanNo1;
	}
	public void setoPanNo1(String oPanNo1) {
		this.oPanNo1 = oPanNo1;
	}
	public String getCatofapp() {
		return catofapp;
	}
	public void setCatofapp(String catofapp) {
		this.catofapp = catofapp;
	}
	public String getRegNo() {
		return regNo;
	}
	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}
	
	public String getScanCopyUri() {
		return scanCopyUri;
	}
	public void setScanCopyUri(String scanCopyUri) {
		this.scanCopyUri = scanCopyUri;
	}
	public MultipartFile getScanCopyImage() {
		return scanCopyImage;
	}
	public void setScanCopyImage(MultipartFile scanCopyImage) {
		this.scanCopyImage = scanCopyImage;
	}
	public Integer getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}
	

	
	
}

