package com.bcoss.mtrans.dto;

import java.io.Serializable;

public class PlansDto implements  Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer planId;
	private String name;
	private Double setupFee;
	
	
	public Integer getPlanId() {
		return planId;
	}
	public void setPlanId(Integer planId) {
		this.planId = planId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getSetupFee() {
		return setupFee;
	}
	public void setSetupFee(Double setupFee) {
		this.setupFee = setupFee;
	}
	
	

}
