package com.bcoss.mtrans.dto.provider.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class QuickRechargeResponseDto {

	@JsonProperty("ERROR")
	private String error;
	
	@JsonProperty("BALANCE")
	private String balance;
	
	@JsonProperty("OPTXNID")
	private String optxnid;
	
	@JsonProperty("MEMBERREQID")
	private String memberreqid;
	
	@JsonProperty("STATUS")
	private String status;
	
	
	@JsonProperty("MESSAGE")
	private String message;
	
	@JsonProperty("dueamount")
	private String dueamount;
	
	@JsonProperty("duedate")
	private String duedate;
	
	@JsonProperty("customername")
	private String customername;
	
	@JsonProperty("billnumber")
	private String billnumber;
	
	@JsonProperty("billdate")
	private String billdate;
	
	@JsonProperty("billperiod")
	private String billperiod;
	
	@JsonProperty("ip")
	private String ip;
	
	private String response;
	

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getOptxnid() {
		return optxnid;
	}

	public void setOptxnid(String optxnid) {
		this.optxnid = optxnid;
	}

	public String getMemberreqid() {
		return memberreqid;
	}

	public void setMemberreqid(String memberreqid) {
		this.memberreqid = memberreqid;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getDueamount() {
		return dueamount;
	}

	public void setDueamount(String dueamount) {
		this.dueamount = dueamount;
	}

	public String getDuedate() {
		return duedate;
	}

	public void setDuedate(String duedate) {
		this.duedate = duedate;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getBillnumber() {
		return billnumber;
	}

	public void setBillnumber(String billnumber) {
		this.billnumber = billnumber;
	}

	public String getBilldate() {
		return billdate;
	}

	public void setBilldate(String billdate) {
		this.billdate = billdate;
	}

	public String getBillperiod() {
		return billperiod;
	}

	public void setBillperiod(String billperiod) {
		this.billperiod = billperiod;
	}
	
	
	
}
