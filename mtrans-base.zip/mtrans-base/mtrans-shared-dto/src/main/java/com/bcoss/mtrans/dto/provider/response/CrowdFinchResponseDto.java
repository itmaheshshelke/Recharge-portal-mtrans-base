package com.bcoss.mtrans.dto.provider.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CrowdFinchResponseDto {

	@JsonProperty("ResponseStatus")
	private String ResponseStatus;
	
	@JsonProperty("Status")
	private String Status;
	
	@JsonProperty("Remarks")
	private String Remarks;
	
	@JsonProperty("ErrorCode")
	private String ErrorCode;
	
	@JsonProperty("Data")
	private CrowdFinchData Data;
	
	private String jsonResponse;
	
	public String getResponseStatus() {
		return ResponseStatus;
	}
	public void setResponseStatus(String responseStatus) {
		ResponseStatus = responseStatus;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getRemarks() {
		return Remarks;
	}
	public void setRemarks(String remarks) {
		Remarks = remarks;
	}
	public String getErrorCode() {
		return ErrorCode;
	}
	public void setErrorCode(String errorCode) {
		ErrorCode = errorCode;
	}
	public CrowdFinchData getData() {
		return Data;
	}
	public void setData(CrowdFinchData data) {
		Data = data;
	}
	public String getJsonResponse() {
		return jsonResponse;
	}
	public void setJsonResponse(String jsonResponse) {
		this.jsonResponse = jsonResponse;
	}
	
	
	
}
