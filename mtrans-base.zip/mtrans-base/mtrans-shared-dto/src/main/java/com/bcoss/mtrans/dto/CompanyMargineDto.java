package com.bcoss.mtrans.dto;

import java.io.Serializable;

public class CompanyMargineDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer companyMargineId;

	private Integer planId;

	private Integer serviceId;

	private Integer operatorId;

	private Integer companyId;

	private Integer margineType;

	private Integer type;

	private Double value;
	
	
	private String operatorName;

	public Integer getCompanyMargineId() {
		return companyMargineId;
	}

	public void setCompanyMargineId(Integer companyMargineId) {
		this.companyMargineId = companyMargineId;
	}

	public Integer getPlanId() {
		return planId;
	}

	public void setPlanId(Integer planId) {
		this.planId = planId;
	}

	public Integer getServiceId() {
		return serviceId;
	}

	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}

	public Integer getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(Integer operatorId) {
		this.operatorId = operatorId;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public Integer getMargineType() {
		return margineType;
	}

	public void setMargineType(Integer margineType) {
		this.margineType = margineType;
	}

	
	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Double getValue() {
		return value;
	}

	public void setValue(Double value) {
		this.value = value;
	}

	public String getOperatorName() {
		return operatorName;
	}

	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}

	
	
	
}
