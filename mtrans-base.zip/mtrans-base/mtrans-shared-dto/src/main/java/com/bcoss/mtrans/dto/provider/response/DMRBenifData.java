package com.bcoss.mtrans.dto.provider.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DMRBenifData {

	@JsonProperty("remitter")
	private Remitter remitter;
	
	@JsonProperty("beneficiary")
	private Beneficiary beneficiary;

	public Remitter getRemitter() {
		return remitter;
	}

	public void setRemitter(Remitter remitter) {
		this.remitter = remitter;
	}

	public Beneficiary getBeneficiary() {
		return beneficiary;
	}

	public void setBeneficiary(Beneficiary beneficiary) {
		this.beneficiary = beneficiary;
	}
	
}
