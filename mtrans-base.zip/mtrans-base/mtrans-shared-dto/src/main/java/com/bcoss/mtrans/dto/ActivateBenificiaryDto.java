package com.bcoss.mtrans.dto;

public class ActivateBenificiaryDto {

	private String remitterId;
	private String otp;
	private String benificiaryId;
	private String parentMobileNumber;
	
	public String getRemitterId() {
		return remitterId;
	}
	public void setRemitterId(String remitterId) {
		this.remitterId = remitterId;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getBenificiaryId() {
		return benificiaryId;
	}
	public void setBenificiaryId(String benificiaryId) {
		this.benificiaryId = benificiaryId;
	}
	/**
	 * @return the parentMobileNumber
	 */
	public String getParentMobileNumber() {
		return parentMobileNumber;
	}
	/**
	 * @param parentMobileNumber the parentMobileNumber to set
	 */
	public void setParentMobileNumber(String parentMobileNumber) {
		this.parentMobileNumber = parentMobileNumber;
	}

}
