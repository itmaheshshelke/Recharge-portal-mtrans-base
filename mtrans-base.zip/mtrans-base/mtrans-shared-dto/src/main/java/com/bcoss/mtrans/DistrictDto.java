package com.bcoss.mtrans;

import java.io.Serializable;

public class DistrictDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer districtId;
	private Integer stateId;
	private String name;
	private Character delFlag;
	
	public Integer getDistrictId() {
		return districtId;
	}
	public void setDistrictId(Integer districtId) {
		this.districtId = districtId;
	}
	public Integer getStateId() {
		return stateId;
	}
	public void setStateId(Integer stateId) {
		this.stateId = stateId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Character getDelFlag() {
		return delFlag;
	}
	public void setDelFlag(Character delFlag) {
		this.delFlag = delFlag;
	}
	
	

}
