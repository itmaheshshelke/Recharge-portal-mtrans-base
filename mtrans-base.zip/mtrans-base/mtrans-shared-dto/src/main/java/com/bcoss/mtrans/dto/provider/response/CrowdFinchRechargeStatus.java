package com.bcoss.mtrans.dto.provider.response;

public class CrowdFinchRechargeStatus {

}
