package com.bcoss.mtrans.dto;

import java.io.Serializable;
import java.util.Date;

public class WalletDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7407963267033121392L;

	
	private Integer walletId;
	private String walletNumber;
	private Double balance;
	private Date createdOn;
	
	
	public Integer getWalletId() {
		return walletId;
	}
	public void setWalletId(Integer walletId) {
		this.walletId = walletId;
	}
	
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public String getWalletNumber() {
		return walletNumber;
	}
	public void setWalletNumber(String walletNumber) {
		this.walletNumber = walletNumber;
	}
	
	
	
}
