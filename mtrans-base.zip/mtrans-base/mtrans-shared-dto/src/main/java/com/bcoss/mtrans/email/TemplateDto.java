package com.bcoss.mtrans.email;

import java.io.Serializable;

public class TemplateDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -836012267023243925L;
	private int templateId;
	private String templateType;
	private String smsBody;

	public int getTemplateId() {
		return templateId;
	}

	public void setTemplateId(int templateId) {
		this.templateId = templateId;
	}

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}

	public String getSmsBody() {
		return smsBody;
	}

	public void setSmsBody(String smsBody) {
		this.smsBody = smsBody;
	}

}
