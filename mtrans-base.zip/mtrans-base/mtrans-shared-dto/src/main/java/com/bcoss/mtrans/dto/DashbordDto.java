package com.bcoss.mtrans.dto;

import java.io.Serializable;

public class DashbordDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Double rechargeAmount;
	private Double rechargeMargin;
	private Double rechargeSurcharge;
	private Double rechargeTotal;
	
	private Double moneyTransferAmount;
	private Double moneyTransferSurcharge;
	private Double moneyTransferTotal;
	
	public Double getRechargeTotal() {
		return rechargeTotal;
	}
	public void setRechargeTotal(Double rechargeTotal) {
		this.rechargeTotal = rechargeTotal;
	}
	public Double getMoneyTransferTotal() {
		return moneyTransferTotal;
	}
	public void setMoneyTransferTotal(Double moneyTransferTotal) {
		this.moneyTransferTotal = moneyTransferTotal;
	}
	public Double getRechargeAmount() {
		return rechargeAmount;
	}
	public void setRechargeAmount(Double rechargeAmount) {
		this.rechargeAmount = rechargeAmount;
	}
	public Double getRechargeMargin() {
		return rechargeMargin;
	}
	public void setRechargeMargin(Double rechargeMargin) {
		this.rechargeMargin = rechargeMargin;
	}
	public Double getRechargeSurcharge() {
		return rechargeSurcharge;
	}
	public void setRechargeSurcharge(Double rechargeSurcharge) {
		this.rechargeSurcharge = rechargeSurcharge;
	}
	public Double getMoneyTransferAmount() {
		return moneyTransferAmount;
	}
	public void setMoneyTransferAmount(Double moneyTransferAmount) {
		this.moneyTransferAmount = moneyTransferAmount;
	}
	public Double getMoneyTransferSurcharge() {
		return moneyTransferSurcharge;
	}
	public void setMoneyTransferSurcharge(Double moneyTransferSurcharge) {
		this.moneyTransferSurcharge = moneyTransferSurcharge;
	}
	
	
	

}
