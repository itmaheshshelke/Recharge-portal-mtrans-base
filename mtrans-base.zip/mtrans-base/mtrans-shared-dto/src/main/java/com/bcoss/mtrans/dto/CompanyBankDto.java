package com.bcoss.mtrans.dto;

import java.io.Serializable;
import java.util.Date;



public class CompanyBankDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6646012410218787858L;

	private Integer companyBankBetailsId;

	private Integer companyId;

	private String bankName;

	private String branchName;

	private String accountNumber;

	private String ifscCode;

	private Integer createdBy;

	private Date createdOn;
	
	private Integer updatedBy;

	private Date updatedOn;

	public Integer getCompanyBankBetailsId() {
		return companyBankBetailsId;
	}

	public void setCompanyBankBetailsId(Integer companyBankBetailsId) {
		this.companyBankBetailsId = companyBankBetailsId;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

}
