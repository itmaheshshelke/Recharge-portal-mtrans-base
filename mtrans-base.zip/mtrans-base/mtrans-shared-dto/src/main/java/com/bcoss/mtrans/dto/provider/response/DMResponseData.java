package com.bcoss.mtrans.dto.provider.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DMResponseData {

	@JsonProperty("ipay_id")
	private String ipay_id;
	
	@JsonProperty("ref_no")
	private String refNo;
	
	@JsonProperty("opr_id")
	private String oprId;
	
	@JsonProperty("name")
	private String name;
	
	@JsonProperty("amount")
	private String amount;
	
	@JsonProperty("charged_amt")
	private String chargedAmt;
	
	@JsonProperty("bank_alias")
	private String bankAlias;

	public String getIpay_id() {
		return ipay_id;
	}

	public void setIpay_id(String ipay_id) {
		this.ipay_id = ipay_id;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getOprId() {
		return oprId;
	}

	public void setOprId(String oprId) {
		this.oprId = oprId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getChargedAmt() {
		return chargedAmt;
	}

	public void setChargedAmt(String chargedAmt) {
		this.chargedAmt = chargedAmt;
	}

	public String getBankAlias() {
		return bankAlias;
	}

	public void setBankAlias(String bankAlias) {
		this.bankAlias = bankAlias;
	}
	
	
}
