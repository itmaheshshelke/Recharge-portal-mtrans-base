package com.bcoss.mtrans.dto;

import java.io.Serializable;

public class MargineDto implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String operatorName;
	private Integer type;
	private Double margineValue;
	public String getOperatorName() {
		return operatorName;
	}
	public void setOperatorName(String operatorName) {
		this.operatorName = operatorName;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Double getMargineValue() {
		return margineValue;
	}
	public void setMargineValue(Double margineValue) {
		this.margineValue = margineValue;
	}
	
	
	
}
