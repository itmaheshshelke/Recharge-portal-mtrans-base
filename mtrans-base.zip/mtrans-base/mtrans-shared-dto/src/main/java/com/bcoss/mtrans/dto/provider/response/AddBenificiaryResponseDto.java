package com.bcoss.mtrans.dto.provider.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AddBenificiaryResponseDto {

	@JsonProperty("ERROR")
	private String error;
	
	@JsonProperty("STATUS")
	private String status;
	
	@JsonProperty("ACCOUNTEXISTS")
	private String accountExists;
	
	@JsonProperty("MOBILENO")
	private String mobileNo;
	
	@JsonProperty("MESSAGE")
	private String  message;
	
	@JsonProperty("DATA")
	private DMRBenifData data;

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAccountExists() {
		return accountExists;
	}

	public void setAccountExists(String accountExists) {
		this.accountExists = accountExists;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public DMRBenifData getData() {
		return data;
	}

	public void setData(DMRBenifData data) {
		this.data = data;
	}
	
	
	
}
