package com.bcoss.mtrans.dto;

import java.io.Serializable;
import java.util.Date;

public class WalletTransactionDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6758162227685767678L;
	
	private Integer walletTransactionId;
	private Integer walletId;
	private Integer parentId;
	private String description;
	private String transNumber;
	private Date transDate;
	private Double transAmount;
	private Character transType;
	private Integer transMethod ;
	private Integer transRef;
	private String transStatus;
	private Integer createdBy;
	private Date createdOn;
	private String rechargeBy;
	
	
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	public Integer getWalletTransactionId() {
		return walletTransactionId;
	}
	public void setWalletTransactionId(Integer walletTransactionId) {
		this.walletTransactionId = walletTransactionId;
	}
	public Integer getWalletId() {
		return walletId;
	}
	public void setWalletId(Integer walletId) {
		this.walletId = walletId;
	}
	
	public String getTransNumber() {
		return transNumber;
	}
	public void setTransNumber(String transNumber) {
		this.transNumber = transNumber;
	}
	public Date getTransDate() {
		return transDate;
	}
	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}
	
	public Double getTransAmount() {
		return transAmount;
	}
	public void setTransAmount(Double transAmount) {
		this.transAmount = transAmount;
	}
	public Character getTransType() {
		return transType;
	}
	public void setTransType(Character transType) {
		this.transType = transType;
	}
	public Integer getTransMethod() {
		return transMethod;
	}
	public void setTransMethod(Integer transMethod) {
		this.transMethod = transMethod;
	}
	public Integer getTransRef() {
		return transRef;
	}
	public void setTransRef(Integer transRef) {
		this.transRef = transRef;
	}
	public String getTransStatus() {
		return transStatus;
	}
	public void setTransStatus(String transStatus) {
		this.transStatus = transStatus;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRechargeBy() {
		return rechargeBy;
	}
	public void setRechargeBy(String rechargeBy) {
		this.rechargeBy = rechargeBy;
	}
	
}
