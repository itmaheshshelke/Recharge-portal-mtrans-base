package com.bcoss.mtrans.dto;

public class MoneyTransferDto {

	private String mobileNo;
	private String beneficiaryCode;
	private String amount;
	private String transferType;
	private String memberReqId;
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getBeneficiaryCode() {
		return beneficiaryCode;
	}
	public void setBeneficiaryCode(String beneficiaryCode) {
		this.beneficiaryCode = beneficiaryCode;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getTransferType() {
		return transferType;
	}
	public void setTransferType(String transferType) {
		this.transferType = transferType;
	}
	public String getMemberReqId() {
		return memberReqId;
	}
	public void setMemberReqId(String memberReqId) {
		this.memberReqId = memberReqId;
	}
	
}
