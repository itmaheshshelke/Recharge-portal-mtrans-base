package com.bcoss.mtrans.dto;

import java.io.Serializable;


public class MoneyTransferResponseDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
    private Integer moneyTransferId;
	
	private Integer companyId;
	
	private String status;
	
	private String companyName;
	
	private Integer companyType;
	
	private String ipayId;
	
	private String refNo;
	
	private String oprId;
	
	private String amount;
	
	private String chargedAmt;
	
	private String bankAlias;
	
	private String beneficiaryCode;
	
	private String txnNumber;
	
	private Double walletBalance;
	
	private java.util.Date createdOn;

	public Integer getMoneyTransferId() {
		return moneyTransferId;
	}

	public void setMoneyTransferId(Integer moneyTransferId) {
		this.moneyTransferId = moneyTransferId;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getIpayId() {
		return ipayId;
	}

	public void setIpayId(String ipayId) {
		this.ipayId = ipayId;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getOprId() {
		return oprId;
	}

	public void setOprId(String oprId) {
		this.oprId = oprId;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getChargedAmt() {
		return chargedAmt;
	}

	public void setChargedAmt(String chargedAmt) {
		this.chargedAmt = chargedAmt;
	}

	public String getBankAlias() {
		return bankAlias;
	}

	public void setBankAlias(String bankAlias) {
		this.bankAlias = bankAlias;
	}

	public String getBeneficiaryCode() {
		return beneficiaryCode;
	}

	public void setBeneficiaryCode(String beneficiaryCode) {
		this.beneficiaryCode = beneficiaryCode;
	}

	public java.util.Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(java.util.Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getTxnNumber() {
		return txnNumber;
	}

	public void setTxnNumber(String txnNumber) {
		this.txnNumber = txnNumber;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Integer getCompanyType() {
		return companyType;
	}

	public void setCompanyType(Integer companyType) {
		this.companyType = companyType;
	}

	public Double getWalletBalance() {
		return walletBalance;
	}

	public void setWalletBalance(Double walletBalance) {
		this.walletBalance = walletBalance;
	}
	
	

}
