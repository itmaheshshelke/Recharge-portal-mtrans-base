package com.bcoss.mtrans.dto;

public class BenificiaryDto {

	private String name;
	
	private String mobile;
	
	private String ifscNumber;
	
	private String accountNumber;
	
	private String remitterId;
	
	private String parentMobileNumber;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getIfscNumber() {
		return ifscNumber;
	}

	public void setIfscNumber(String ifscNumber) {
		this.ifscNumber = ifscNumber;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * @return the remitterId
	 */
	public String getRemitterId() {
		return remitterId;
	}

	/**
	 * @param remitterId the remitterId to set
	 */
	public void setRemitterId(String remitterId) {
		this.remitterId = remitterId;
	}

	/**
	 * @return the parentMobileNumber
	 */
	public String getParentMobileNumber() {
		return parentMobileNumber;
	}

	/**
	 * @param parentMobileNumber the parentMobileNumber to set
	 */
	public void setParentMobileNumber(String parentMobileNumber) {
		this.parentMobileNumber = parentMobileNumber;
	}
	
	
}
