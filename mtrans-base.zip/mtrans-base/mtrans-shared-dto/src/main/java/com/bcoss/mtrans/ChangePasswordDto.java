package com.bcoss.mtrans;

import java.io.Serializable;

public class ChangePasswordDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2425230707344739110L;
	
	
		private String oldPassword;
	
		private String newPassword;
		
		private Integer employeeId;
		
		private Integer companyId;
		

		public String getOldPassword() {
			return oldPassword;
		}

		public void setOldPassword(String oldPassword) {
			this.oldPassword = oldPassword;
		}

		public String getNewPassword() {
			return newPassword;
		}

		public void setNewPassword(String newPassword) {
			this.newPassword = newPassword;
		}

		public Integer getEmployeeId() {
			return employeeId;
		}

		public void setEmployeeId(Integer employeeId) {
			this.employeeId = employeeId;
		}

		public Integer getCompanyId() {
			return companyId;
		}

		public void setCompanyId(Integer companyId) {
			this.companyId = companyId;
		}
	
	
	

}
