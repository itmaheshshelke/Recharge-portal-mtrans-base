package com.bcoss.mtrans.dto;

import java.io.Serializable;
import java.util.Date;

public class ServiceResponseDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6806665548300606170L;

	private Integer serviceResponseId;

	private Integer companyId;

	private Integer employeeId;

	private Integer serviceId;

	private Integer operatorId;

	private Integer rechargeBy;
	
	private String operaterName;
	
	private String companyName;
	
	private Integer companyType;

	private String mombileNumber;

	private String accountNumber;

	private String operatorCode;

	private Integer circleCode;

	private Double amount;

	private String txId;

	private String status;

	private String errorCode;

	private String operatorRef;

	private Date time;

	private Date createdOn;

	// newwly added fields

	private String responseStatus;

	private String remarks;

	private String dataStatus;

	private String oPTId;

	private String refId;
	
	private String responseJson;
	
	private String mode;
	
	private Double dueamount;
	
	private Date duedate;
	
	private String customername;
	
	private String billnumber;
	
	private Date billdate;
	
	private String billperiod;
	
	private String optional1;
	
	private Double margine;
	
	private Double finalAmount;
	
	private Integer marginType;
	
	private Double surcharge;
	
	private Double walletBalance;

	public Integer getServiceResponseId() {
		return serviceResponseId;
	}

	public void setServiceResponseId(Integer serviceResponseId) {
		this.serviceResponseId = serviceResponseId;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public Integer getServiceId() {
		return serviceId;
	}

	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}

	public Integer getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(Integer operatorId) {
		this.operatorId = operatorId;
	}

	public Integer getRechargeBy() {
		return rechargeBy;
	}

	public void setRechargeBy(Integer rechargeBy) {
		this.rechargeBy = rechargeBy;
	}

	public String getMombileNumber() {
		return mombileNumber;
	}

	public void setMombileNumber(String mombileNumber) {
		this.mombileNumber = mombileNumber;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getOperatorCode() {
		return operatorCode;
	}

	public void setOperatorCode(String operatorCode) {
		this.operatorCode = operatorCode;
	}

	public Integer getCircleCode() {
		return circleCode;
	}

	public void setCircleCode(Integer circleCode) {
		this.circleCode = circleCode;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getTxId() {
		return txId;
	}

	public void setTxId(String txId) {
		this.txId = txId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getOperatorRef() {
		return operatorRef;
	}

	public void setOperatorRef(String operatorRef) {
		this.operatorRef = operatorRef;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getDataStatus() {
		return dataStatus;
	}

	public void setDataStatus(String dataStatus) {
		this.dataStatus = dataStatus;
	}

	public String getoPTId() {
		return oPTId;
	}

	public void setoPTId(String oPTId) {
		this.oPTId = oPTId;
	}

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public String getResponseJson() {
		return responseJson;
	}

	public void setResponseJson(String responseJson) {
		this.responseJson = responseJson;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public Double getDueamount() {
		return dueamount;
	}

	public void setDueamount(Double dueamount) {
		this.dueamount = dueamount;
	}

	public Date getDuedate() {
		return duedate;
	}

	public void setDuedate(Date duedate) {
		this.duedate = duedate;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getBillnumber() {
		return billnumber;
	}

	public void setBillnumber(String billnumber) {
		this.billnumber = billnumber;
	}

	public Date getBilldate() {
		return billdate;
	}

	public void setBilldate(Date billdate) {
		this.billdate = billdate;
	}

	public String getBillperiod() {
		return billperiod;
	}

	public void setBillperiod(String billperiod) {
		this.billperiod = billperiod;
	}

	public String getOptional1() {
		return optional1;
	}

	public void setOptional1(String optional1) {
		this.optional1 = optional1;
	}

	

	public Double getMargine() {
		return margine;
	}

	public void setMargine(Double margine) {
		this.margine = margine;
	}

	public Double getFinalAmount() {
		return finalAmount;
	}

	public void setFinalAmount(Double finalAmount) {
		this.finalAmount = finalAmount;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @return the marginType
	 */
	public Integer getMarginType() {
		return marginType;
	}

	/**
	 * @param marginType the marginType to set
	 */
	public void setMarginType(Integer marginType) {
		this.marginType = marginType;
	}

	public String getOperaterName() {
		return operaterName;
	}

	public void setOperaterName(String operaterName) {
		this.operaterName = operaterName;
	}

	public Double getSurcharge() {
		return surcharge;
	}

	public void setSurcharge(Double surcharge) {
		this.surcharge = surcharge;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Integer getCompanyType() {
		return companyType;
	}

	public void setCompanyType(Integer companyType) {
		this.companyType = companyType;
	}

	public Double getWalletBalance() {
		return walletBalance;
	}

	public void setWalletBalance(Double walletBalance) {
		this.walletBalance = walletBalance;
	}

	

}
