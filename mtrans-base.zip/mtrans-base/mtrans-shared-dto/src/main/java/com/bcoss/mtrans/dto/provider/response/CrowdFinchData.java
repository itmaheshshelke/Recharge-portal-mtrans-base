package com.bcoss.mtrans.dto.provider.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CrowdFinchData {

	@JsonProperty("Status")
	private String Status;
	
	@JsonProperty("Date")
	private String Date;
	
	@JsonProperty("Number")
	private String Number;
	
	@JsonProperty("Amount")
	private Double Amount;
	
	@JsonProperty("Balance")
	private Double Balance;
	
	@JsonProperty("TranId")
	private String TranId;
	
	@JsonProperty("OPTId")
	private String OPTId;
	
	@JsonProperty("RefId")
	private String RefId;
	
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public String getNumber() {
		return Number;
	}
	public void setNumber(String number) {
		Number = number;
	}
	public Double getAmount() {
		return Amount;
	}
	public void setAmount(Double amount) {
		Amount = amount;
	}
	public Double getBalance() {
		return Balance;
	}
	public void setBalance(Double balance) {
		Balance = balance;
	}
	public String getTranId() {
		return TranId;
	}
	public void setTranId(String tranId) {
		TranId = tranId;
	}
	public String getOPTId() {
		return OPTId;
	}
	public void setOPTId(String oPTId) {
		OPTId = oPTId;
	}
	public String getRefId() {
		return RefId;
	}
	public void setRefId(String refId) {
		RefId = refId;
	}
	
	
}
