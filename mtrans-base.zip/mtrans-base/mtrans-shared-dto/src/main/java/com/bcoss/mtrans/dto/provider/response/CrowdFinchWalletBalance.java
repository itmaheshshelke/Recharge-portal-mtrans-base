package com.bcoss.mtrans.dto.provider.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CrowdFinchWalletBalance {

	@JsonProperty("ResponseStatus")
	private String ResponseStatus;
	@JsonProperty("Status")
	private String Status;
	@JsonProperty("Remarks")
	private String Remarks;
	@JsonProperty("ErrorCode")
	private String ErrorCode;
	@JsonProperty("Data")
	private Data Data;

	public String getResponseStatus() {
		return ResponseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		ResponseStatus = responseStatus;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getRemarks() {
		return Remarks;
	}

	public void setRemarks(String remarks) {
		Remarks = remarks;
	}

	public String getErrorCode() {
		return ErrorCode;
	}

	public void setErrorCode(String errorCode) {
		ErrorCode = errorCode;
	}

	public Data getData() {
		return Data;
	}

	public void setData(Data data) {
		Data = data;
	}

	

}
