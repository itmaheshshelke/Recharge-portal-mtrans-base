package com.bcoss.mtrans.jpa.sms;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sms_inbox")
public class SmsInbox implements Serializable {

	/**
	 * 
	 */

	private static final long serialVersionUID = -9032902834294251178L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sms_inbox_id")
	private int sms_inbox_id;

	@Column(name = "company_id")
	private Integer companyId;

	@Column(name = "sms_template_type")
	private String smsTemplateType;

	@Column(name = "service")
	private String service;

	@Column(name = "sms_transaction_id")
	private String smsTransactionId;

	@Column(name = "status")
	private Integer status;

	public int getSms_inbox_id() {
		return sms_inbox_id;
	}

	public void setSms_inbox_id(int sms_inbox_id) {
		this.sms_inbox_id = sms_inbox_id;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getSmsTemplateType() {
		return smsTemplateType;
	}

	public void setSmsTemplateType(String smsTemplateType) {
		this.smsTemplateType = smsTemplateType;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getSmsTransactionId() {
		return smsTransactionId;
	}

	public void setSmsTransactionId(String smsTransactionId) {
		this.smsTransactionId = smsTransactionId;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	

}
