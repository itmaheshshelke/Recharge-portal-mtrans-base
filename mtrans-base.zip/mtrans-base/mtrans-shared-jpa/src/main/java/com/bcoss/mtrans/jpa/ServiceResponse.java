package com.bcoss.mtrans.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="service_response")
public class ServiceResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3935959642945259928L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "service_response_id")
	private Integer serviceResponseId;

	@Column(name = "company_id")
	private Integer companyId;

	@Column(name = "service_id")
	private Integer serviceId;

	@Column(name = "operator_id")
	private Integer operatorId;

	@Column(name = "recharge_by")
	private Integer rechargeBy;

	@Column(name = "mombile_number")
	private String mombileNumber;

	@Column(name = "account_number")
	private String accountNumber;

	@Column(name = "operator_code")
	private String operatorCode;

	@Column(name = "circle_code")
	private Integer circleCode;

	@Column(name = "amount")
	private Double amount;

	@Column(name = "txid")
	private String txId;

	@Column(name = "status")
	private String status;

	@Column(name = "error_code")
	private String errorCode;

	@Column(name = "operator_ref")
	private String operatorRef;

	@Column(name = "time")
	private Date time;

	@Column(name="created_on")
	private java.util.Date createdOn;
	
	@Column(name = "response_status")
	private String responseStatus;

	@Column(name = "remarks")
	private String remarks;

	@Column(name = "data_status")
	private String dataStatus;

	@Column(name = "oPTId")
	private String oPTId;

	@Column(name = "ref_id")
	private String refId;
	
	@Column(name = "response_json")
	private String responseJson;
	
	@Column(name = "dueamount")
	private Double dueamount;
	
	@Column(name = "duedate")
	private Date duedate;
	
	@Column(name = "customername")
	private String customername;
	
	@Column(name = "billnumber")
	private String billnumber;
	
	@Column(name = "billdate")
	private Date billdate;
	
	@Column(name = "billperiod")
	private String billperiod;
	
	@Column(name = "margine")
	private Double margine;
	
	@Column(name = "surcharge")
	private Double surcharge;
	
	@Column(name = "final_amount")
	private Double finalAmount;
	
	@Column(name = "wallet_balance")
	private Double walletBalance;
	
	
	public Integer getServiceResponseId() {
		return serviceResponseId;
	}

	public void setServiceResponseId(Integer serviceResponseId) {
		this.serviceResponseId = serviceResponseId;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public Integer getServiceId() {
		return serviceId;
	}

	public void setServiceId(Integer serviceId) {
		this.serviceId = serviceId;
	}

	public Integer getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(Integer operatorId) {
		this.operatorId = operatorId;
	}

	public Integer getRechargeBy() {
		return rechargeBy;
	}

	public void setRechargeBy(Integer rechargeBy) {
		this.rechargeBy = rechargeBy;
	}

	public String getMombileNumber() {
		return mombileNumber;
	}

	public void setMombileNumber(String mombileNumber) {
		this.mombileNumber = mombileNumber;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getOperatorCode() {
		return operatorCode;
	}

	public void setOperatorCode(String operatorCode) {
		this.operatorCode = operatorCode;
	}

	public Integer getCircleCode() {
		return circleCode;
	}

	public void setCircleCode(Integer circleCode) {
		this.circleCode = circleCode;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getTxId() {
		return txId;
	}

	public void setTxId(String txId) {
		this.txId = txId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getOperatorRef() {
		return operatorRef;
	}

	public void setOperatorRef(String operatorRef) {
		this.operatorRef = operatorRef;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public java.util.Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(java.util.Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getDataStatus() {
		return dataStatus;
	}

	public void setDataStatus(String dataStatus) {
		this.dataStatus = dataStatus;
	}

	public String getoPTId() {
		return oPTId;
	}

	public void setoPTId(String oPTId) {
		this.oPTId = oPTId;
	}

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public String getResponseJson() {
		return responseJson;
	}

	public void setResponseJson(String responseJson) {
		this.responseJson = responseJson;
	}

	public Double getDueamount() {
		return dueamount;
	}

	public void setDueamount(Double dueamount) {
		this.dueamount = dueamount;
	}

	public Date getDuedate() {
		return duedate;
	}

	public void setDuedate(Date duedate) {
		this.duedate = duedate;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getBillnumber() {
		return billnumber;
	}

	public void setBillnumber(String billnumber) {
		this.billnumber = billnumber;
	}

	public Date getBilldate() {
		return billdate;
	}

	public void setBilldate(Date billdate) {
		this.billdate = billdate;
	}

	public String getBillperiod() {
		return billperiod;
	}

	public void setBillperiod(String billperiod) {
		this.billperiod = billperiod;
	}

	public Double getMargine() {
		return margine;
	}

	public void setMargine(Double margine) {
		this.margine = margine;
	}

	public Double getFinalAmount() {
		return finalAmount;
	}

	public void setFinalAmount(Double finalAmount) {
		this.finalAmount = finalAmount;
	}

	public Double getSurcharge() {
		return surcharge;
	}

	public void setSurcharge(Double surcharge) {
		this.surcharge = surcharge;
	}

	public Double getWalletBalance() {
		return walletBalance;
	}

	public void setWalletBalance(Double walletBalance) {
		this.walletBalance = walletBalance;
	}
	
	

}
