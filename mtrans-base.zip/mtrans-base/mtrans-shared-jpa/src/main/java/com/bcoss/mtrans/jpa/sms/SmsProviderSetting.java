package com.bcoss.mtrans.jpa.sms;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="sms_provider_setting")
public class SmsProviderSetting implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="sms_provider_setting_id")
	private Integer smsProviderSettingId;
	
	@Column(name="provider_name")
	private String providerName;
	
	@Column(name="base_url")
	private String baseUrl;
	
	@Column(name="user_name")
	private String userName;
	
	@Column(name="password")
	private String password;
	
	@Column(name="sendor_id")
	private String sendorId;
	
	public Integer getSmsProviderSettingId() {
		return smsProviderSettingId;
	}
	public void setSmsProviderSettingId(Integer smsProviderSettingId) {
		this.smsProviderSettingId = smsProviderSettingId;
	}
	public String getProviderName() {
		return providerName;
	}
	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}
	public String getBaseUrl() {
		return baseUrl;
	}
	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSendorId() {
		return sendorId;
	}
	public void setSendorId(String sendorId) {
		this.sendorId = sendorId;
	}
	
	
}
