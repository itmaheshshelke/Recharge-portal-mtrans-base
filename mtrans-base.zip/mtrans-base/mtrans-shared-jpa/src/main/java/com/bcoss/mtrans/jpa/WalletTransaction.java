package com.bcoss.mtrans.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="company_wallet_transaction")
public class WalletTransaction implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1190620087443151635L;
	
	
	 @Id
     @GeneratedValue(strategy=GenerationType.IDENTITY)
     @Column (name="wallet_transaction_id")
	 private Integer walletTransactionId;
	
	 @Column (name="wallet_id")
	 private Integer walletId;
	 
	 @Column (name="parent_id")
	 private Integer parentId;
	 
	 @Column (name="description") 
	private String description;
	
	 @Column (name="trans_number")
	 private String transNumber;
	
	 @Column (name="trans_date")
	 private Date transDate;
	
	 @Column (name="trans_amount")
	 private Double transAmount;
	 
	/* @Column (name="prev_balance")
	 private Double prevBalance;*/
	
	 @Column (name="trans_type")
	 private Character transType;
	
	 @Column (name="trans_method")
	 private Integer transMethod ;
	
	 @Column (name="trans_ref")
	 private Integer transRef;
	
	 @Column (name="trans_status")
	 private String transStatus;
	
	 @Column (name="created_by")
	 private Integer createdBy;
	
	 @Column (name="created_on")
	 private Date createdOn;

	public Integer getWalletTransactionId() {
		return walletTransactionId;
	}

	public void setWalletTransactionId(Integer walletTransactionId) {
		this.walletTransactionId = walletTransactionId;
	}

	
	
	public Integer getWalletId() {
		return walletId;
	}

	public void setWalletId(Integer walletId) {
		this.walletId = walletId;
	}

	public String getTransNumber() {
		return transNumber;
	}

	public void setTransNumber(String transNumber) {
		this.transNumber = transNumber;
	}

	public Date getTransDate() {
		return transDate;
	}

	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}

	public Double getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(Double transAmount) {
		this.transAmount = transAmount;
	}

	public Character getTransType() {
		return transType;
	}

	public void setTransType(Character transType) {
		this.transType = transType;
	}

	public Integer getTransMethod() {
		return transMethod;
	}

	public void setTransMethod(Integer transMethod) {
		this.transMethod = transMethod;
	}

	public Integer getTransRef() {
		return transRef;
	}

	public void setTransRef(Integer transRef) {
		this.transRef = transRef;
	}

	public String getTransStatus() {
		return transStatus;
	}

	public void setTransStatus(String transStatus) {
		this.transStatus = transStatus;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	/*public Double getPrevBalance() {
		return prevBalance;
	}

	public void setPrevBalance(Double prevBalance) {
		this.prevBalance = prevBalance;
	}*/
	
	 
}
