package com.bcoss.mtrans.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="pan_card")
public class PanCard implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "pan_id")
	private Integer panId;
	@Column(name = "applicant_category_id")
	private Integer applicantCategoryId;
	
	@Column(name = "category_id")
	private Integer categoryId;
	
	@Column(name = "f_name")
	private String fName;
	@Column(name = "m_name")
	private String mName;
	@Column(name = "l_name")
	private String lName;
	@Column(name = "name_on_card")
	private String nameOnCard;
	@Column(name = "father_f_name")
	private String fatherFname;
	@Column(name = "father_m_name")
	private String fatherMname;
	@Column(name = "father_l_name")
	private String fatherLname;
	@Column(name = "dob")
	private Date dob;
	@Column(name = "mobile_no")
	private String mobileNo;
	@Column(name = "email_id")
	private String emailId;
	@Column(name = "address")
	private String address;
	@Column(name = "name_on_aadhar")
	private String nameOnAadhar;
	@Column(name = "identity_uri")
	private String identityUri;
	@Column(name = "address_uri")
	private String addressUri;
	@Column(name = "dob_uri")
	private String dobUri;
	@Column(name = "scan_copy_uri")
	private String scanCopyUri;
	@Column(name = "status")
	private Integer status;
	@Column(name = "application_type")
	private Integer applicationType;
	@Column(name = "pan_no")
	private String panNo;
	@Column(name = "o_pan_no1")
	private String oPanNo1;
	@Column(name = "o_pan_no2")
	private String oPanNo2;
	@Column(name = "o_pan_no3")
	private String oPanNo3;
	@Column(name = "o_pan_no4")
	private String oPanNo4;
	@Column(name = "state_id")
	private String stateId;
	@Column(name = "created_on")
	private Date createdOn;
	@Column(name = "created_by")
	private Integer createdBy;
	@Column(name = "updated_on")
	private Date updatedOn;
	@Column(name = "updated_by")
	private Integer updatedBy;
	@Column(name = "del_flag")
	private Character delFlag;
	
	@Column(name = "aadhar_no")
	private String aadharNo;
	@Column(name = "eid_no")
	private String eidNo;
	
	@Column(name = "cat_of_app")
	private String catofapp;
	
	@Column(name = "reg_no")
	private String regNo;
	public Integer getPanId() {
		return panId;
	}
	public void setPanId(Integer panId) {
		this.panId = panId;
	}
	
	public Integer getApplicantCategoryId() {
		return applicantCategoryId;
	}
	public void setApplicantCategoryId(Integer applicantCategoryId) {
		this.applicantCategoryId = applicantCategoryId;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getNameOnCard() {
		return nameOnCard;
	}
	public void setNameOnCard(String nameOnCard) {
		this.nameOnCard = nameOnCard;
	}
	public String getFatherFname() {
		return fatherFname;
	}
	public void setFatherFname(String fatherFname) {
		this.fatherFname = fatherFname;
	}
	public String getFatherMname() {
		return fatherMname;
	}
	public void setFatherMname(String fatherMname) {
		this.fatherMname = fatherMname;
	}
	public String getFatherLname() {
		return fatherLname;
	}
	public void setFatherLname(String fatherLname) {
		this.fatherLname = fatherLname;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getNameOnAadhar() {
		return nameOnAadhar;
	}
	public void setNameOnAadhar(String nameOnAadhar) {
		this.nameOnAadhar = nameOnAadhar;
	}
	public String getIdentityUri() {
		return identityUri;
	}
	public void setIdentityUri(String identityUri) {
		this.identityUri = identityUri;
	}
	public String getAddressUri() {
		return addressUri;
	}
	public void setAddressUri(String addressUri) {
		this.addressUri = addressUri;
	}
	public String getDobUri() {
		return dobUri;
	}
	public void setDobUri(String dobUri) {
		this.dobUri = dobUri;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getApplicationType() {
		return applicationType;
	}
	public void setApplicationType(Integer applicationType) {
		this.applicationType = applicationType;
	}
	
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getoPanNo1() {
		return oPanNo1;
	}
	public void setoPanNo1(String oPanNo1) {
		this.oPanNo1 = oPanNo1;
	}
	public String getoPanNo2() {
		return oPanNo2;
	}
	public void setoPanNo2(String oPanNo2) {
		this.oPanNo2 = oPanNo2;
	}
	public String getoPanNo3() {
		return oPanNo3;
	}
	public void setoPanNo3(String oPanNo3) {
		this.oPanNo3 = oPanNo3;
	}
	public String getoPanNo4() {
		return oPanNo4;
	}
	public void setoPanNo4(String oPanNo4) {
		this.oPanNo4 = oPanNo4;
	}
	
	public String getStateId() {
		return stateId;
	}
	public void setStateId(String stateId) {
		this.stateId = stateId;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Date getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	public Integer getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Character getDelFlag() {
		return delFlag;
	}
	public void setDelFlag(Character delFlag) {
		this.delFlag = delFlag;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getEidNo() {
		return eidNo;
	}
	public void setEidNo(String eidNo) {
		this.eidNo = eidNo;
	}
	public String getCatofapp() {
		return catofapp;
	}
	public void setCatofapp(String catofapp) {
		this.catofapp = catofapp;
	}
	public String getRegNo() {
		return regNo;
	}
	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}
	public String getScanCopyUri() {
		return scanCopyUri;
	}
	public void setScanCopyUri(String scanCopyUri) {
		this.scanCopyUri = scanCopyUri;
	}
	public Integer getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}
	
}
