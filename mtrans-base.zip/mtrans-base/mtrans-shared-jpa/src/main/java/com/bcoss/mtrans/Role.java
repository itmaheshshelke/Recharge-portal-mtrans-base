package com.bcoss.mtrans;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="role")
public class Role  implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="role_id")
	private Integer roleId;
	
	@Column(name="name")
	private String name;
	
	@Column(name="description")
	private String description;
	
	@Column(name="is_sys_admin")
	private String isSysAdmin;
	
	
	@Column(name="del_flag")
	private Character delFlag;


	public Integer getRoleId() {
		return roleId;
	}


	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getIsSysAdmin() {
		return isSysAdmin;
	}


	public void setIsSysAdmin(String isSysAdmin) {
		this.isSysAdmin = isSysAdmin;
	}


	public Character getDelFlag() {
		return delFlag;
	}


	public void setDelFlag(Character delFlag) {
		this.delFlag = delFlag;
	}

			
}
