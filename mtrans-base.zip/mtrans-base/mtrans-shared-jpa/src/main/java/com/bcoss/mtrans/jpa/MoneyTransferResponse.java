package com.bcoss.mtrans.jpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="money_transfer_response")
public class MoneyTransferResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4011746531297871645L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "money_transfer_id")
	private Integer moneyTransferId;
	
	@Column(name = "company_id")
	private Integer companyId;
	
	@Column(name = "status")
	private String status;
	
	@Column(name = "ipay_id")
	private String ipayId;
	
	@Column(name = "ref_no")
	private String refNo;
	
	@Column(name = "opr_id")
	private String oprId;
	
	@Column(name = "amount")
	private String amount;
	
	@Column(name = "charged_amt")
	private String chargedAmt;
	
	@Column(name = "bank_alias")
	private String bankAlias;
	
	@Column(name = "beneficiary_code")
	private String beneficiaryCode;
	
	@Column(name = "txn_number")
	private String txnNumber;
	
	@Column(name = "created_on")
	private java.util.Date createdOn;

	@Column(name = "wallet_balance")
	private Double walletBalance;
	
	public Integer getMoneyTransferId() {
		return moneyTransferId;
	}

	public void setMoneyTransferId(Integer moneyTransferId) {
		this.moneyTransferId = moneyTransferId;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getIpayId() {
		return ipayId;
	}

	public void setIpayId(String ipayId) {
		this.ipayId = ipayId;
	}

	public String getRefNo() {
		return refNo;
	}

	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}

	public String getOprId() {
		return oprId;
	}

	public void setOprId(String oprId) {
		this.oprId = oprId;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getChargedAmt() {
		return chargedAmt;
	}

	public void setChargedAmt(String chargedAmt) {
		this.chargedAmt = chargedAmt;
	}

	public String getBankAlias() {
		return bankAlias;
	}

	public void setBankAlias(String bankAlias) {
		this.bankAlias = bankAlias;
	}

	public String getBeneficiaryCode() {
		return beneficiaryCode;
	}

	public void setBeneficiaryCode(String beneficiaryCode) {
		this.beneficiaryCode = beneficiaryCode;
	}

	public java.util.Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(java.util.Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getTxnNumber() {
		return txnNumber;
	}

	public void setTxnNumber(String txnNumber) {
		this.txnNumber = txnNumber;
	}

	public Double getWalletBalance() {
		return walletBalance;
	}

	public void setWalletBalance(Double walletBalance) {
		this.walletBalance = walletBalance;
	}
	
	
	
}
