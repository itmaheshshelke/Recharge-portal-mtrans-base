package com.bcoss.mtrans.jpa.sms;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="email_setting")
public class EmailSetting implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="email_setting_id")
	private Integer emailSettingId;
	
	@Column(name="company_id")
	private Integer companyId;
	
	@Column(name="company_name")
    private String companyName;
	
	@Column(name="email_id")
    private String emailId;
	
	@Column(name="provider")
    private String provider;
	
	@Column(name="password")
    private String password;
	
	@Column(name="port")
    private Integer port;

	public Integer getEmailSettingId() {
		return emailSettingId;
	}

	public void setEmailSettingId(Integer emailSettingId) {
		this.emailSettingId = emailSettingId;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public String getProvider() {
		return provider;
	}

	public void setProvider(String provider) {
		this.provider = provider;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getPort() {
		return port;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	
	
	
}
