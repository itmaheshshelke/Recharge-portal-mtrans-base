package com.bcoss.mtrans.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="company_wallet")
public class Wallet implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6646012410218787858L;
	
	 @Id
     @GeneratedValue(strategy=GenerationType.IDENTITY)
     @Column (name="wallet_id")
	 private Integer walletId;
	
	 
	 @Column(name="wallet_number",insertable= true, updatable=false)
	 private String walletNumber;
	
	 @Column(name="balance")
	 private Double balance;
	
	 @Column(name="created_on", insertable=true,updatable=false)
	 private Date createdOn;

	public Integer getWalletId() {
		return walletId;
	}

	public void setWalletId(Integer walletId) {
		this.walletId = walletId;
	}

	
	public String getWalletNumber() {
		return walletNumber;
	}

	public void setWalletNumber(String walletNumber) {
		this.walletNumber = walletNumber;
	}

	public Double getBalance() {
		return balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	 
	 
}
