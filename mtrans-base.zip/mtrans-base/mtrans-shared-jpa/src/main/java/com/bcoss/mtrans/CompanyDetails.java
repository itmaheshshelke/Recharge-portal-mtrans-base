package com.bcoss.mtrans;

import java.io.Serializable;
import java.util.Date;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "company_details")
public class CompanyDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4905404304622938420L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "company_id")
	private Integer companyId;
	
	@Column(name = "wallet_id")
	private Integer walletId;
	
	@Column(name = "parent_id")
	private Integer parentId;
	
	@Column(name = "company_name")
	private String companyName;
	
	@Column(name = "contact_person_name")
	private String contactPersonName;
	
	@Column(name = "address")
	private String address;
	
	@Column(name = "city")
	private String city;
	
	@Column(name = "company_type")
	private Integer companyType;
	
	@Column(name = "email_id")
	private String emailId;
	
	@Column(name = "plan_id")
	private Integer planId;
	
	@Column(name="setup_fee")
	private Double setupFee;
	
	
	@Column(name = "state_id")
	private Integer stateId;
	
	@Column(name = "district_id")
	private Integer districtId;
	
	@Column(name = "contact_no")
	private String contactNo;
	
	@Column(name = "pin_code")
	private Integer pinCode;

	
	@Column(name = "created_by",insertable=true, updatable=false)
	private Integer createdBy;

	@Column(name = "created_on",insertable=true,updatable=false)
	private Date createdOn;

	@Column(name = "updated_by")
	private Integer updatedBy;

	@Column(name = "updated_on")
	private Date updatedOn;

	@Column(name = "del_flag")
	private Character delFlag;
	
	
	@Column(name = "is_active")
	private Integer isActive;
	
	
	
	@Column(name = "is_read_only")
	private Character isReadOnly;

	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	public Integer getWalletId() {
		return walletId;
	}

	public void setWalletId(Integer walletId) {
		this.walletId = walletId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	

	public Integer getCompanyType() {
		return companyType;
	}

	public void setCompanyType(Integer companyType) {
		this.companyType = companyType;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Integer getPlanId() {
		return planId;
	}

	public void setPlanId(Integer planId) {
		this.planId = planId;
	}

	public Double getSetupFee() {
		return setupFee;
	}

	public void setSetupFee(Double setupFee) {
		this.setupFee = setupFee;
	}

	public Integer getStateId() {
		return stateId;
	}

	public void setStateId(Integer stateId) {
		this.stateId = stateId;
	}

	public Integer getDistrictId() {
		return districtId;
	}

	public void setDistrictId(Integer districtId) {
		this.districtId = districtId;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public Integer getPinCode() {
		return pinCode;
	}

	public void setPinCode(Integer pinCode) {
		this.pinCode = pinCode;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Character getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(Character delFlag) {
		this.delFlag = delFlag;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public Character getIsReadOnly() {
		return isReadOnly;
	}

	public void setIsReadOnly(Character isReadOnly) {
		this.isReadOnly = isReadOnly;
	}

	

}
