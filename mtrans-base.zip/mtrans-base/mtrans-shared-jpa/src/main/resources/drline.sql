/*
SQLyog Professional v12.09 (64 bit)
MySQL - 5.1.72-community : Database - drline
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`drline` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `drline`;

/*Table structure for table `address` */

DROP TABLE IF EXISTS `address`;

CREATE TABLE `address` (
  `address_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `address_line_1` varchar(200) DEFAULT NULL,
  `address_line_2` varchar(200) DEFAULT NULL,
  `area_name` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `pincode` int(6) DEFAULT NULL,
  `created_on` date NOT NULL,
  `created_by` int(10) DEFAULT NULL,
  `updated_by` int(10) DEFAULT NULL,
  `updated_on` date DEFAULT NULL,
  `del_flag` char(1) DEFAULT NULL,
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `address` */

insert  into `address`(`address_id`,`address_line_1`,`address_line_2`,`area_name`,`city`,`pincode`,`created_on`,`created_by`,`updated_by`,`updated_on`,`del_flag`) values (1,'Pune 123','Pune','Karve nagar','Pune',411041,'2018-02-17',1,1,'2018-02-17','N'),(2,'Pune 123','Pune','Karve nagar','Pune',411041,'2018-02-17',1,1,'2018-02-17','N'),(3,'Pune 123','Pune','Karve nagar','Pune',411041,'2018-02-17',1,1,'2018-02-17','Y');

/*Table structure for table `certificate` */

DROP TABLE IF EXISTS `certificate`;

CREATE TABLE `certificate` (
  `certificate_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template_id` int(10) unsigned DEFAULT NULL,
  `certificate_name` varchar(200) DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `complaint` varchar(200) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `attend_dutiese_date` date DEFAULT NULL,
  `doctor_name` varchar(100) DEFAULT NULL,
  `created_by` int(10) NOT NULL,
  `created_on` date NOT NULL,
  `del_flag` char(1) DEFAULT 'N',
  PRIMARY KEY (`certificate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `certificate` */

/*Table structure for table `doctor_details` */

DROP TABLE IF EXISTS `doctor_details`;

CREATE TABLE `doctor_details` (
  `doctor_details_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) NOT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `doctor_name` varchar(100) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `contact_no` varchar(50) NOT NULL,
  `clinic_name` varchar(200) DEFAULT NULL,
  `qualification` varchar(200) DEFAULT NULL,
  `speciality` varchar(200) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `created_by` int(10) NOT NULL,
  `created_on` date NOT NULL,
  `updated_by` int(10) DEFAULT NULL,
  `updated_on` date DEFAULT NULL,
  `del_flag` char(1) DEFAULT NULL,
  PRIMARY KEY (`doctor_details_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `doctor_details` */

insert  into `doctor_details`(`doctor_details_id`,`role_id`,`parent_id`,`doctor_name`,`gender`,`email_id`,`contact_no`,`clinic_name`,`qualification`,`speciality`,`date_of_birth`,`created_by`,`created_on`,`updated_by`,`updated_on`,`del_flag`) values (1,1,1,'Mahesh M Shelke','Male','it.maheshshelke@gmail.com','9922861410','Shraddha Clinic','MCA','IT','1993-11-07',1,'2018-02-17',NULL,NULL,'N'),(2,1,2,'Mahesh Shelke','Male','it.maheshshelke@gmail.com','9922861410','Shraddha Clinic','MCA','IT','1993-11-07',1,'2018-02-17',NULL,NULL,'Y');

/*Table structure for table `patient` */

DROP TABLE IF EXISTS `patient`;

CREATE TABLE `patient` (
  `patient_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `patient_name` varchar(30) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `service` varchar(300) DEFAULT NULL,
  `appiontment_date` date DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `contact_no` varchar(15) DEFAULT NULL,
  `note` varchar(300) DEFAULT NULL,
  `created_by` int(10) NOT NULL,
  `created_on` date NOT NULL,
  `updated_by` int(10) DEFAULT NULL,
  `updated_on` date DEFAULT NULL,
  `del_flag` char(1) DEFAULT NULL,
  PRIMARY KEY (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `patient` */

insert  into `patient`(`patient_id`,`patient_name`,`date_of_birth`,`gender`,`service`,`appiontment_date`,`email_id`,`contact_no`,`note`,`created_by`,`created_on`,`updated_by`,`updated_on`,`del_flag`) values (1,'Mahesh Shelke','1993-09-07','Male','Service','2018-02-13','it.maheshshelke@gmail.com','9922861410','No note',1,'2018-02-13',NULL,NULL,'N'),(2,'Ram Shelke','1993-09-07','Male','Service','2018-02-13','it.maheshshelke@gmail.com','9922861410','No note',2,'2018-02-13',NULL,NULL,'Y');

/*Table structure for table `patient_user` */

DROP TABLE IF EXISTS `patient_user`;

CREATE TABLE `patient_user` (
  `patient_user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `patient_id` int(10) NOT NULL,
  PRIMARY KEY (`patient_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `patient_user` */

/*Table structure for table `prescription` */

DROP TABLE IF EXISTS `prescription`;

CREATE TABLE `prescription` (
  `prescripton_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `medicine_name` varchar(100) NOT NULL,
  `dose` varchar(10) NOT NULL,
  `timing` varchar(50) NOT NULL,
  `days` int(20) NOT NULL,
  `quantity` int(20) NOT NULL,
  `amount` int(20) NOT NULL,
  `created_on` date NOT NULL,
  `created_by` int(10) NOT NULL,
  `del_flag` char(1) DEFAULT 'N',
  PRIMARY KEY (`prescripton_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `prescription` */

insert  into `prescription`(`prescripton_id`,`medicine_name`,`dose`,`timing`,`days`,`quantity`,`amount`,`created_on`,`created_by`,`del_flag`) values (1,'Viks medicine','3','1',3,6,100,'2018-02-17',1,'N'),(2,'Viks ','3','1',3,6,100,'2018-02-17',1,'Y');

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `role_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `description` varchar(30) DEFAULT NULL,
  `created_by` int(10) NOT NULL,
  `created_on` date NOT NULL,
  `updated_by` int(10) DEFAULT NULL,
  `updated_on` date DEFAULT NULL,
  `del_flag` char(1) DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `role` */

insert  into `role`(`role_id`,`user_id`,`name`,`description`,`created_by`,`created_on`,`updated_by`,`updated_on`,`del_flag`) values (1,1,'Admin','Admin',1,'2018-02-17',NULL,NULL,'N'),(2,2,'Staff','Staff',1,'2018-02-17',NULL,NULL,'Y');

/*Table structure for table `staff` */

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `staff_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `address_id` int(10) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `contact_no` varchar(15) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `created_on` date NOT NULL,
  `created_by` int(10) DEFAULT NULL,
  `updated_by` int(10) DEFAULT NULL,
  `updated_on` date DEFAULT NULL,
  `del_flag` char(1) DEFAULT NULL,
  PRIMARY KEY (`staff_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `staff` */

insert  into `staff`(`staff_id`,`address_id`,`name`,`email_id`,`contact_no`,`date_of_birth`,`gender`,`qualification`,`created_on`,`created_by`,`updated_by`,`updated_on`,`del_flag`) values (1,1,'Mahesh','mahesh@gmail.com','9922861410','2018-02-17','Male','MCA','2018-02-17',1,NULL,NULL,'N'),(2,1,'Mahesh Shelke','mahesh@gmail.com','9922861410','2018-02-17','Male','MCA','2018-02-17',1,NULL,NULL,'Y');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) NOT NULL,
  `user_name` varchar(30) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `salt_password` varchar(100) DEFAULT NULL,
  `status` int(10) DEFAULT NULL,
  `failed_attemt` int(10) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `user` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
